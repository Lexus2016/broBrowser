CheckURL = 'http://195.154.31.71/?token=skjdh8b38bx82b&tz=';
