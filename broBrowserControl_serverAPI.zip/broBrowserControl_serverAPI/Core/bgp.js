'use strict';

let ipMismatchAlert = false;

let globalIP = '0.0.0.0';
let globalLang = '';
let globalLangs = {};
let globalTimeZone = '';
let globalTimeShift = '';

let startTimer = new Date().getTime();
let endTimer = startTimer * 10;
let fetchPeriod = 1000; //msec

let goodJob = true;

chrome.webRequest.onBeforeSendHeaders.addListener(
    function (details) {

        for (let i = 0; i < details.requestHeaders.length; ++i) {
            if (Profile.global.isChangeUA === true && details.requestHeaders[i].name.toLocaleLowerCase() === 'user-agent') {
                details.requestHeaders[i].value = Profile.navigator.userAgent;
            } else if (Profile.global.isChangeLang === true && details.requestHeaders[i].name.toLocaleLowerCase() === 'accept-language') {
                details.requestHeaders[i].value = Languages.langs.join(',') + ';q=0.9';
            } else if (details.requestHeaders[i].name.toLocaleLowerCase() === 'dnt') {
                details.requestHeaders[i].value = '1';
            }
        }

        return {
            requestHeaders: details.requestHeaders
        };
    }, {
        urls: ['<all_urls>']
    }, ['requestHeaders', 'extraHeaders', 'blocking']
);

function getConfig() {
    return new Promise((resolve, reject) => {
        if ((endTimer - startTimer) < fetchPeriod) {
            endTimer = new Date().getTime();
            resolve();
            return;
        }

        startTimer = new Date().getTime();
        endTimer = new Date().getTime();

        resolve(getLocales());
    });
}

function getLocales() {
    return Promise.all([
        fetch(CheckURL + new Date().getTime())
    ]).then(data => Promise.all(data.map(el => el.text()))).then(arr => {

        let resultObj = {};

        let jsONARR = JSON.parse(arr[0]);
        let ip = jsONARR[0];
        let timeZoneV = jsONARR[1];
        let newTimeOffset = parseInt(jsONARR[2]) / 100 * 60;
        let langsT = jsONARR[3].split(',', 2);
        let langs = Array.from(new Set(langsT));

        Languages.lang = langs[0];
        Languages.langs = langs;

        TimeSettings.newTimeOffset = newTimeOffset;
        TimeSettings.timeZoneV = timeZoneV;

        resultObj = {
            'IP': ip,
            'timeZoneV': timeZoneV,
            'newTimeOffset': newTimeOffset,
            'lang': langs[0],
            //'lang': langs[0].split('-')[0],
            'langs': langs
        };

        chrome.storage.local.set({
            'fkConfig': resultObj
        });

        if (globalIP !== ip && globalIP !== '0.0.0.0') {
            console.debug("WARNING! IP changed!\n\nIP: " + globalIP + ' => ' + ip + "\nTimeZone: " + globalTimeZone + ' => ' + timeZoneV + "\nTimeOffset: " + globalTimeShift + ' => ' + newTimeOffset + "\nLanguage: " + globalLang + ' => ' + langs[0]);
            if (ipMismatchAlert) {
                alert("WARNING! IP changed!\n\nIP: " + globalIP + ' => ' + ip + "\nTimeZone: " + globalTimeZone + ' => ' + timeZoneV + "\nTimeOffset: " + globalTimeShift + ' => ' + newTimeOffset + "\nLanguage: " + globalLang + ' => ' + langs[0]);
            }

            goodJob = false;
        } else {
            goodJob = true;
        }

        if (globalIP === '0.0.0.0') {
            globalIP = ip;
            globalTimeZone = timeZoneV;
            globalTimeShift = newTimeOffset;
            globalLang = langs[0];
            globalLangs = langs;
        }

    });
}

chrome.webRequest.onBeforeRequest.addListener(
    function (details) {

        // IP no change?
        if (!goodJob) {
            if ((new URL(details.url).hostname) !== (new URL(CheckURL).hostname)) {
                return {
                    cancel: true
                };
            }
        }

    }, {
        urls: ['<all_urls>']
    }, ['blocking']
);


const onTabs = ({
                    frameId,
                    url,
                    tabId
                }) => {
    getConfig();
};

chrome.tabs.onActivated.addListener(onTabs);
chrome.tabs.onUpdated.addListener(onTabs);
chrome.tabs.onCreated.addListener(onTabs);

const onCreateNewWindow = ({
                               windows
                           }) => {
    getConfig();
};

chrome.windows.onCreated.addListener(onCreateNewWindow);

getLocales();

setInterval(async function () {
    await getLocales();
}, 10000);
