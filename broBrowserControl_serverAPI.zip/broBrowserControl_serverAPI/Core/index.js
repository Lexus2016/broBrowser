var isShowInfoPopup = true;

// Get Config from LocalStorage
function getConfig() {
    return new Promise(function(resolve, reject) {
        chrome.storage.local.get(['fkConfig'], function(items) {
            if (chrome.runtime.lastError) {
                console.error(chrome.runtime.lastError.message);
                reject(chrome.runtime.lastError.message);
            } else {
                resolve(items['fkConfig']);
            }
        });
    });
}

function SetFkbrConfig(config) {
    document.documentElement.dataset.IP = config['ip'];
    document.documentElement.dataset.Country = config['country'];
    document.documentElement.dataset.cc = config['countryCode'];
    document.documentElement.dataset.timeZoneV = config['timeZoneV'];
    document.documentElement.dataset.newTimeOffset = config['newTimeOffset'];
    document.documentElement.dataset.lang = config['lang'];
    document.documentElement.dataset.DC = config['isDC'];
    document.documentElement.dataset.PRX = config['isProxy'];
    document.documentElement.dataset.MLW = config['isMalware'];
    document.documentElement.dataset.CRW = config['isCrawler'];
    document.documentElement.dataset.ct = config['connectionType'];
    document.documentElement.dataset.langs = JSON.stringify(config['langs']);
    document.documentElement.dataset.Browser = JSON.stringify(Profile);
}

// Change IP
chrome.storage.onChanged.addListener(function(changes, namespace) {
    getConfig().then(function(config) {
        SetFkbrConfig(config);
    });
});

// Inject to page
getConfig().then(function(config) {
    SetFkbrConfig(config);

    // This is function injected to Page
    const inject = function() {
        console.log('.');

        // Disable WebRTC
        navigator.mediaDevices.getUserMedia = navigator.webkitGetUserMedia = navigator.mozGetUserMedia = navigator.getUserMedia = webkitRTCPeerConnection = RTCPeerConnection = MediaStreamTrack = undefined;

        // Fake canvas math
        let shift = localStorage.getItem('fkbrCanvas');

        if (!shift) {
            shift = {
                'r': Math.floor(Math.random() * 10) - 5,
                'g': Math.floor(Math.random() * 10) - 5,
                'b': Math.floor(Math.random() * 10) - 5,
                'a': Math.floor(Math.random() * 10) - 5
            };

            localStorage.setItem('fkbrCanvas', JSON.stringify(shift));
        } else {
            shift = JSON.parse(shift);
        }

        // Config Start
        const Browser = JSON.parse(document.documentElement.dataset.Browser);

        var Languages = Languages || {};
        var TimeSettings = TimeSettings || {};

        Languages.lang = document.documentElement.dataset.lang;
        Languages.langs = JSON.parse(document.documentElement.dataset.langs);

        TimeSettings.newTimeOffset = document.documentElement.dataset.newTimeOffset;
        TimeSettings.timeZoneV = document.documentElement.dataset.timeZoneV;
        // Config End

        // Lib functions
        // Start
        const defineProp = function(obj, prop, val) {
            Object.defineProperty(obj, prop, {
                enumerable: true,
                configurable: true,
                value: val
            });
        };

        const defineNavigatorGetter = function(obj, val) {
            navigator.__defineGetter__(obj, function() {
                return val;
            });
        };
        // Lib functions
        // End

        // Canvas Faker
        const overwriteBlob = function(name) {
            const OLD = HTMLCanvasElement.prototype[name];

            defineProp(HTMLCanvasElement.prototype, name, function() {

                const width = this.width,
                    height = this.height,
                    context = this.getContext("2d");
                if (context === null) {
                    return OLD.apply(this, arguments);
                }

                const imageData = context.getImageData(0, 0, width, height);
                for (let i = 0; i < height; i++) {
                    for (let j = 0; j < width; j++) {
                        let n = ((i * (width * 4)) + (j * 4));
                        imageData.data[n] = imageData.data[n] + shift.r;
                        imageData.data[n + 1] = imageData.data[n + 1] + shift.g;
                        imageData.data[n + 2] = imageData.data[n + 2] + shift.b;
                        imageData.data[n + 3] = imageData.data[n + 3] + shift.a;
                    }
                }
                context.putImageData(imageData, 0, 0);
                return OLD.apply(this, arguments);
            });
        };

        // Change functions
        overwriteBlob('toBlob');
        overwriteBlob('toDataURL');

        // Window Objects faker
        if (typeof Browser.window.devicePixelRatio === 'undefined') {
            Browser.window.devicePixelRatio = 2;
        } else if (Browser.window.devicePixelRatio === '') {
            Browser.window.devicePixelRatio = 24;
        }

        if (typeof Browser.window.pixelDepth === 'undefined') {
            Browser.window.pixelDepth = 24;
        } else if (Browser.window.pixelDepth === '') {
            Browser.window.pixelDepth = 24;
        }

        if (typeof Browser.window.colorDepth === 'undefined') {
            Browser.window.colorDepth = 24;
        } else if (Browser.window.colorDepth === '') {
            Browser.window.colorDepth = 24;
        }

        if (typeof Browser.window.innerWidth === 'undefined' || typeof Browser.window.innerHeight === 'undefined') {
            Browser.window.innerWidth = Browser.window.width - Math.floor(Math.random() * Browser.window.height * 0.05)
            Browser.window.innerHeight = Browser.window.height - Math.floor(Math.random() * Browser.window.height * 0.05);
        } else if (Browser.window.innerWidth === '' || Browser.window.innerHeight === '') {
            Browser.window.innerWidth = Browser.window.width - Math.floor(Math.random() * Browser.window.height * 0.05)
            Browser.window.innerHeight = Browser.window.height - Math.floor(Math.random() * Browser.window.height * 0.05);
        }

        if (typeof Browser.window.outerWidth === 'undefined' || typeof Browser.window.outerHeight === 'undefined') {
            Browser.window.outerWidth = Browser.window.width;
            Browser.window.outerHeight = Browser.window.height;
        } else if (Browser.window.outerWidth === '' || Browser.window.outerHeight === '') {
            Browser.window.outerWidth = Browser.window.width;
            Browser.window.outerHeight = Browser.window.height;
        }

        if (typeof Browser.window.clientWidth === 'undefined' || typeof Browser.window.clientHeight === 'undefined') {
            Browser.window.clientWidth = Browser.window.innerWidth - Math.floor(Math.random() * Browser.window.innerWidth * 0.05);
            Browser.window.clientHeight = Browser.window.innerHeight;
        } else if (Browser.window.clientWidth === '' || Browser.window.clientHeight === '') {
            Browser.window.clientWidth = Browser.window.innerWidth - Math.floor(Math.random() * Browser.window.innerWidth * 0.05);
            Browser.window.clientHeight = Browser.window.innerHeight;
        }

        if (typeof Browser.window.availWidth === 'undefined' || typeof Browser.window.availHeight === 'undefined') {
            Browser.window.availWidth = Browser.window.width;
            if (!Browser.global.isMobile && Browser.window.height > 600) {
                Browser.window.availHeight = Browser.window.height - 55;
            } else {
                Browser.window.availHeight = Browser.window.height;
            }
        } else if (Browser.window.availWidth === '' || Browser.window.availHeight === '') {
            if (!Browser.global.isMobile && Browser.window.height > 600) {
                Browser.window.availHeight = Browser.window.height - 55;
            } else {
                Browser.window.availHeight = Browser.window.height;
            }
        }

        defineProp(window, "devicePixelRatio", Browser.window.devicePixelRatio);
        defineProp(window, "outerWidth", Browser.window.outerWidth);
        defineProp(window, "outerHeight", Browser.window.outerHeight);
        defineProp(window, "innerWidth", Browser.window.innerWidth);
        defineProp(window, "innerHeight", Browser.window.innerHeight);
        // defineProp(window, "clientWidth", Browser.window.clientWidth);
        // defineProp(window, "clientHeight", Browser.window.clientHeight);

        defineProp(window.screen, "width", Browser.window.width);
        defineProp(window.screen, "height", Browser.window.height);

        defineProp(window.screen, "availWidth", Browser.window.availWidth);
        defineProp(window.screen, "availHeight", Browser.window.availHeight);
        defineProp(window.screen, "top", undefined);
        defineProp(window.screen, "left", undefined);
        defineProp(window.screen, "availTop", 0);
        defineProp(window.screen, "availLeft", 0);
        defineProp(window.screen, "pixelDepth", Browser.window.pixelDepth);
        defineProp(window.screen, "colorDepth", Browser.window.colorDepth);
        defineProp(window.screen.orientation, "type", Browser.window.orientation_type);
        defineProp(window.screen.orientation, "angle", Browser.window.orientation_angle);

        defineProp(HTMLElement.prototype, "innerWidth", Browser.window.innerWidth);
        defineProp(HTMLElement.prototype, "innerHeight", Browser.window.innerHeight);
        defineProp(HTMLElement.prototype, "outerWidth", Browser.window.outerWidth);
        defineProp(HTMLElement.prototype, "outerHeight", Browser.window.outerHeight);

        // defineProp(HTMLElement.prototype, "scrollWidth", Browser.window.innerWidth);
        // defineProp(HTMLElement.prototype, "scrollHeight", Browser.window.innerHeight);
        // defineProp(HTMLElement.prototype, "outerWidth", Browser.window.outerWidth);
        // defineProp(HTMLElement.prototype, "outerHeight", Browser.window.outerHeight);

        // defineProp(HTMLElement.prototype, "clientWidth", Browser.window.clientWidth);
        // defineProp(HTMLElement.prototype, "clientHeight", Browser.window.clientHeight);

        const rand = {
            "noise": function() {
                const SIGN = Math.random() < Math.random() ? -1 : 1;
                return Math.floor(Math.random() + SIGN * Math.random());
            },
            "sign": function() {
                const tmp = [-1, -1, -1, -1, -1, -1, +1, -1, -1, -1];
                const index = Math.floor(Math.random() * tmp.length);
                return tmp[index];
            }
        };

        // Fake rect coordinate for fingerprint
        function clientRect() {
            let xTmp1 = Browser.window.innerHeight / (5 + Math.random());
            let yTmp1 = Browser.window.innerWidth / (6 + Math.random());

            return {
                width: Browser.window.innerWidth / (2 + Math.random()),
                height: Browser.window.innerHeight / (2 + Math.random()),
                top: yTmp1,
                right: Browser.window.innerWidth / (3 + Math.random()),
                bottom: Browser.window.innerHeight / (2 + Math.random()),
                left: xTmp1,
                x: xTmp1,
                y: yTmp1
            };
        };

        Object.defineProperty(HTMLElement.prototype, 'getBoundingClientRect', {
            value: () => (clientRect())
        });

        Object.defineProperty(Element.prototype, 'getBoundingClientRect', {
            value: () => (clientRect())
        });

        Object.defineProperty(HTMLElement.prototype, 'getClientRects', {
            value: () => {
                return {
                    0: clientRect()
                };
            }
        });

        Object.defineProperty(Element.prototype, 'getClientRects', {
            value: () => {
                return {
                    0: clientRect()
                };
            }
        });

        Object.defineProperty(window, 'getComputedStyle', {
            value: () => ({
                getPropertyValue: (prop) => {
                    if (prop.toLowerCase() === 'width') {
                        return Browser.window.innerWidth + 'px';
                    }

                    if (prop.toLowerCase() === 'height') {
                        return Browser.window.innerHeight + 'px';
                    }
                }
            })
        });

        // Navigator Faker
        defineNavigatorGetter("doNotTrack", 1);
        defineNavigatorGetter("deviceMemory", Browser.navigator.deviceMemory);
        defineNavigatorGetter("hardwareConcurrency", Browser.navigator.deviceCPUs);

        defineNavigatorGetter("productSub", Browser.navigator.productSub);
        defineNavigatorGetter("oscpu", Browser.navigator.oscpu);

        defineNavigatorGetter("plugins", Browser.plugins);
        defineNavigatorGetter("mimeTypes", Browser.mimeTypes);

        if (Browser.global.isChangeLang) {
            defineNavigatorGetter("language", Languages.lang);
            defineNavigatorGetter("languages", Languages.lang);
            defineNavigatorGetter("systemLanguage", Languages.lang);
            defineNavigatorGetter("userLanguage", Languages.lang);
            defineNavigatorGetter("browserLanguage", Languages.lang);
        }

        if (Browser.global.isChangeUA) {
            defineNavigatorGetter("userAgent", Browser.navigator.userAgent);
            defineNavigatorGetter("appVersion", Browser.navigator.appVersion);
            defineNavigatorGetter("platform", Browser.navigator.platform);
            defineNavigatorGetter("vendor", Browser.navigator.vendor);
        }

        if (Browser.global.isMobile) {
            defineNavigatorGetter("maxTouchPoints", Browser.navigator.maxTouchPoints);
        }

        // DateTime Faker
        const timeZone = -TimeSettings.newTimeOffset; // in minutes
        let timeZoneHour = '';
        if (TimeSettings.newTimeOffset > 0) {
            if ((TimeSettings.newTimeOffset / 60) < 10) {
                timeZoneHour = '+0' + TimeSettings.newTimeOffset / 60; // in hour
            } else {
                timeZoneHour = '+' + TimeSettings.newTimeOffset / 60; // in hour
            }
        } else if (TimeSettings.newTimeOffset < 0) {
            if ((TimeSettings.newTimeOffset / 60) > -10) {
                timeZoneHour = '-0' + (-TimeSettings.newTimeOffset / 60); // in hour
            } else {
                timeZoneHour = '-' + (-TimeSettings.newTimeOffset / 60); // in hour
            }
        } else {
            timeZoneHour = '';
        }

        // Font Faker
        //

        Object.defineProperties(HTMLElement.prototype, {
            // offsetLeft: {
            //     get: function() {
            //         const value = window.getComputedStyle(this).marginLeft;
            //         const valid = value && rand.sign() === 1;
            //         return valid ? value + rand.noise() : value;
            //     }
            // },
            // offsetTop: {
            //     get: function() {
            //         const value = window.getComputedStyle(this).marginTop;
            //         const valid = value && rand.sign() === 1;
            //         return valid ? value + rand.noise() : value;
            //     }
            // },
            offsetHeight: {
                get: function() {
                    let value = Math.ceil(Browser.window.height / 6);

                    if (value < 60) {
                        value = 60;
                    }

                    const valid = value && rand.sign() === 1;
                    return valid ? value + rand.noise() : value;
                }
            },
            offsetWidth: {
                get: function() {
                    let value = Math.ceil(Browser.window.width / 6);

                    if (value < 200) {
                        value = 200;
                    }

                    const valid = value && rand.sign() === 1;
                    return valid ? value + rand.noise() : value;
                }
            }
        });

        // Font Faker -- END

        //AudioContext Faker
        const context = {
            "BUFFER": null,
            "getChannelData": function(e) {
                const getChannelData = e.prototype.getChannelData;
                defineProp(e.prototype, "getChannelData", function() {
                    const results_1 = getChannelData.apply(this, arguments);
                    if (context.BUFFER !== results_1) {
                        context.BUFFER = results_1;
                        for (var i = 0; i < results_1.length; i += 100) {
                            let index = Math.floor(Math.random() * i);
                            results_1[index] = results_1[index] + Math.random() * 0.0000001;
                        }
                    }
                    return results_1;
                });
            },
            "createAnalyser": function(e) {
                const createAnalyser = e.prototype.__proto__.createAnalyser;

                defineProp(e.prototype.__proto__, "createAnalyser", function() {
                    const results_2 = createAnalyser.apply(this, arguments);
                    const getFloatFrequencyData = results_2.__proto__.getFloatFrequencyData;

                    defineProp(results_2.__proto__, "getFloatFrequencyData", function() {
                        const results_3 = getFloatFrequencyData.apply(this, arguments);
                        for (var i = 0; i < arguments[0].length; i += 100) {
                            let index = Math.floor(Math.random() * i);
                            arguments[0][index] = arguments[0][index] + Math.random() * 0.1;
                        }
                        return results_3;
                    });
                    return results_2;
                });
            }
        };
        //
        context.getChannelData(AudioBuffer);
        context.createAnalyser(AudioContext);
        context.getChannelData(OfflineAudioContext);
        context.createAnalyser(OfflineAudioContext);

        // WebGL Faker
        WebGLRenderingContext.prototype.getParameter = function(origFn) {
            const pm = {};
            pm[0x9245] = Browser.WebGL.WebGLUVendor;
            pm[0x9246] = Browser.WebGL.WebGLURender;
            pm[0x1F00] = Browser.WebGL.WebGLVendor;
            pm[0x1F01] = Browser.WebGL.WebGLRender;

            return function(parameter) {
                return pm[parameter] || origFn.call(this, parameter);
            };
        }(WebGLRenderingContext.prototype.getParameter);

        WebGL2RenderingContext.prototype.getParameter = function(origFn) {
            const pm = {};
            pm[0x9245] = Browser.WebGL.WebGLUVendor;
            pm[0x9246] = Browser.WebGL.WebGLURender;
            pm[0x1F00] = Browser.WebGL.WebGLVendor;
            pm[0x1F01] = Browser.WebGL.WebGLRender;

            return function(parameter) {
                return pm[parameter] || origFn.call(this, parameter);
            };
        }(WebGL2RenderingContext.prototype.getParameter);

        defineProp(Intl.DateTimeFormat.prototype, "format", function() {
            return (new Date()).toUTCString();
        });

        Intl.DateTimeFormat.prototype.resolvedOptions = function(origFn) {
            return function(parameter) {
                return {
                    calendar: "gregory",
                    day: "2-digit",
                    locale: Languages.lang,
                    month: "2-digit",
                    numberingSystem: "latn",
                    timeZone: TimeSettings.timeZoneV,
                    year: "numeric"
                };
            };
        }(Intl.DateTimeFormat.prototype.resolvedOptions);

        Intl.NumberFormat.prototype.resolvedOptions = function(origFn) {
            return function(parameter) {
                return {
                    locale: Languages.lang,
                    maximumFractionDigits: 3,
                    minimumFractionDigits: 0,
                    minimumIntegerDigits: 1,
                    notation: "standard",
                    numberingSystem: "latn",
                    signDisplay: "auto",
                    style: "decimal",
                    useGrouping: true
                };
            };
        }(Intl.NumberFormat.prototype.resolvedOptions);

        Intl.DisplayNames.prototype.resolvedOptions = function(origFn) {
            return function(parameter) {
                return {
                    fallback: "code",
                    locale: Languages.lang,
                    style: "long",
                    type: "language"
                };
            };
        }(Intl.DisplayNames.prototype.resolvedOptions);

        Intl.ListFormat.prototype.resolvedOptions = function(origFn) {
            return function(parameter) {
                return {
                    locale: Languages.lang,
                    style: "long",
                    type: "conjunction"
                };
            };
        }(Intl.ListFormat.prototype.resolvedOptions);

        Intl.RelativeTimeFormat.prototype.resolvedOptions = function(origFn) {
            return function(parameter) {
                return {
                    locale: Languages.lang,
                    style: "long",
                    numberingSystem: "latn",
                    numeric: "always"
                };
            };
        }(Intl.RelativeTimeFormat.prototype.resolvedOptions);

        defineProp(Intl.Locale.prototype, "hourCycle", 'h23');
        defineNavigatorGetter(Intl.Locale.prototype.hourCycle, 'h23');

        Intl.PluralRules.prototype.resolvedOptions = function(origFn) {
            return function(parameter) {
                return {
                    locale: Languages.lang,
                    maximumFractionDigits: 3,
                    minimumFractionDigits: 0,
                    minimumIntegerDigits: 1,
                    pluralCategories: ["few", "many", "one", "other"]
                };
            };
        }(Intl.PluralRules.prototype.resolvedOptions);

        // DateTime Faker
        (function() {
            const offsetDate = new Date();
            Date.prototype.timezoneOffset = offsetDate.getTimezoneOffset();
            Date.setTimezoneOffset = function(timezoneOffset) {
                return this.prototype.timezoneOffset = timezoneOffset;
            };
            Date.getTimezoneOffset = function(timezoneOffset) {
                return this.prototype.timezoneOffset;
            };
            Date.prototype.getTimezoneOffset = function() {
                return this.timezoneOffset;
            };
            Date.prototype.setTimezoneOffset = function(timezoneOffset) {
                return this.timezoneOffset = timezoneOffset;
            };
            Date.prototype.toString = function() {
                const offsetTime = this.timezoneOffset * 60 * 1000;
                offsetDate.setTime(this.getTime() - offsetTime);
                return offsetDate.toUTCString() + timeZoneHour.toString() + '00';
            };

            Date.prototype.toLocaleString = function() {
                const date1 = new Date();

                let date = date1.getDate();
                let month = date1.getMonth();
                let year = date1.getFullYear();

                let hours = date1.getHours();
                let minutes = date1.getMinutes();
                let seconds = date1.getSeconds();

                if (date < 10) date = '0' + date;
                if (month < 10) month = '0' + month;
                if (hours < 10) hours = '0' + hours;
                if (minutes < 10) minutes = '0' + minutes;
                if (seconds < 10) seconds = '0' + seconds;

                return date + '.' + month + '.' + year + ' ' + hours + ':' + minutes + ':' + seconds;
            };

            Date.prototype.toLocaleTimeString = function() {
                const date1 = new Date();
                let hours = date1.getHours();
                let minutes = date1.getMinutes();
                let seconds = date1.getSeconds();

                if (hours < 10) hours = '0' + hours;
                if (minutes < 10) minutes = '0' + minutes;
                if (seconds < 10) seconds = '0' + seconds;

                return hours + ':' + minutes + ':' + seconds;
            };
            return ['Milliseconds', 'Seconds', 'Minutes', 'Hours', 'Date', 'Month', 'FullYear', 'Day'].forEach((function(_this) {
                return function(key) {
                    Date.prototype["get" + key] = function() {
                        const offsetTime = this.timezoneOffset * 60 * 1000;
                        offsetDate.setTime(this.getTime() - offsetTime);
                        return offsetDate["getUTC" + key]();
                    };
                    return Date.prototype["set" + key] = function(value) {
                        const offsetTime = this.timezoneOffset * 60 * 1000;
                        offsetDate.setTime(this.getTime() - offsetTime);
                        offsetDate["setUTC" + key](value);
                        let time = offsetDate.getTime() + offsetTime;
                        this.setTime(time);
                        return time;
                    };
                };
            })(this));
        })();

        // Disable WebRTC
        navigator.mediaDevices.getUserMedia = navigator.webkitGetUserMedia = navigator.mozGetUserMedia = navigator.getUserMedia = webkitRTCPeerConnection = RTCPeerConnection = MediaStreamTrack = undefined;

        if (Browser.global.isChangeTime) {
            Date.setTimezoneOffset(timeZone);
        }

        document.documentElement.dataset.cbscriptallow = true;
    };


    const _display = (html, textColor, bgColor) => {

        // No iFrame
        try {
            if (window.self !== window.top) {
                return;
            }
        } catch (e) {
            return;
        }

        const el = document.createElement('div');
        el.innerHTML = html;

        el.style.width = '220px';
        el.style.height = '75px';
        el.style.fontSize = '12px';
        el.style.fontFamily = 'arial';
        el.style.textAlign = 'center';
        el.style.padding = '20px';
        el.style.position = 'fixed';
        el.style.bottom = '20px';
        el.style.right = '20px';
        el.style.borderRadius = '5px';
        el.style.zIndex = '99999999';
        el.style.lineHeight = '1';
        el.style.overflow = 'hidden';
        el.style.cursor = 'move';
        el.style.boxSizing = 'content-box';

        el.style.color = textColor;
        el.style.backgroundColor = bgColor;

        const dragElement = (elmnt) => {
            let pos1 = 0,
                pos2 = 0,
                pos3 = 0,
                pos4 = 0;
            if (document.getElementById(elmnt.id + "header")) {
                document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
            } else {
                elmnt.onmousedown = dragMouseDown;
            }

            function dragMouseDown(e) {
                e = e || window.event;
                e.preventDefault();
                pos3 = e.clientX;
                pos4 = e.clientY;
                document.onmouseup = closeDragElement;
                document.onmousemove = elementDrag;
            }

            function elementDrag(e) {
                e = e || window.event;
                e.preventDefault();
                pos1 = pos3 - e.clientX;
                pos2 = pos4 - e.clientY;
                pos3 = e.clientX;
                pos4 = e.clientY;
                elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
                elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
            }

            function closeDragElement() {
                document.onmouseup = null;
                document.onmousemove = null;
            }
        };

        dragElement(el);
        (document.body || document.documentElement.body || document.documentElement || document.head).appendChild(el);
    };

    // Inject code into page
    try {
        const script_1 = document.createElement('script');
        script_1.textContent = '(' + inject + ')()';
        (document.head || document.documentElement).appendChild(script_1);
        script_1.remove();
    } catch (e) {}

    if (isShowInfoPopup) {
        try {
            let colorBgRed = 'rgba(209, 97, 97, 0.6)';
            let colorBgGreen = 'rgba(142, 185, 121, 0.6)';
            let flag = '<img style="width:24px; vertical-align: middle; border-style: none;" src="https://www.countryflags.io/' + document.documentElement.dataset.cc + '/flat/24.png">';

            let ipInfo = document.documentElement.dataset.DC;
            ipInfo += (document.documentElement.dataset.PRX !== '' ? ', ' + document.documentElement.dataset.PRX : '');
            ipInfo += (document.documentElement.dataset.MLW !== '' ? ', ' + document.documentElement.dataset.MLW : '');
            ipInfo += (document.documentElement.dataset.CRW !== '' ? ', ' + document.documentElement.dataset.CRW : '');

            let textDisplayParam = '`<div style="all: unset;"><b>' + Profile.name + '</b><hr style="margin: 7px 0;" />IP: ' + document.documentElement.dataset.IP + ' [' + document.documentElement.dataset.ct + ']<br>Country: ' + document.documentElement.dataset.Country + ' ' + flag + '<br><font color="red"><b>' + ipInfo + '</b></font></div>`, `#323232`, `' + colorBgGreen + '`';
            const script_display = document.createElement('script');
            script_display.textContent = '(' + _display + ')(' + textDisplayParam + ')';
            (document.head || document.documentElement).appendChild(script_display);
            script_display.remove();
        } catch (e) {
            console.debug(e);
        }
    }

});

if (document.documentElement.dataset.cbscriptallow !== "true") {
    try {
        let script_2 = document.createElement('script');
        script_2.textContent = `{
    const iframes = window.top.document.querySelectorAll("iframe[sandbox]");
    for (let i = 0; i < iframes.length; i++)
    {
        if (iframes[i].contentWindow)
        {
            if (iframes[i].contentWindow.AudioBuffer)
            {
                if (iframes[i].contentWindow.AudioBuffer.prototype)
                {
                    if (iframes[i].contentWindow.AudioBuffer.prototype.getChannelData)
                    {
                        iframes[i].contentWindow.AudioBuffer.prototype.getChannelData = AudioBuffer.prototype.getChannelData;
                    }
                }
            }

            if (iframes[i].contentWindow.AudioContext)
            {
                if (iframes[i].contentWindow.AudioContext.prototype)
                {
                    if (iframes[i].contentWindow.AudioContext.prototype.__proto__)
                    {
                        if (iframes[i].contentWindow.AudioContext.prototype.__proto__.createAnalyser)
                        {
                            iframes[i].contentWindow.AudioContext.prototype.__proto__.createAnalyser = AudioContext.prototype.__proto__.createAnalyser;
                        }
                    }
                }
            }

            if (iframes[i].contentWindow.OfflineAudioContext)
            {
                if (iframes[i].contentWindow.OfflineAudioContext.prototype)
                {
                    if (iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__)
                    {
                        if (iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__.createAnalyser)
                        {
                            iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__.createAnalyser = OfflineAudioContext.prototype.__proto__.createAnalyser;
                        }
                    }
                }
            }

            if (iframes[i].contentWindow.OfflineAudioContext)
            {
                if (iframes[i].contentWindow.OfflineAudioContext.prototype)
                {
                    if (iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__)
                    {
                        if (iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__.getChannelData)
                        {
                            iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__.getChannelData = OfflineAudioContext.prototype.__proto__.getChannelData;
                        }
                    }
                }
            }
        }

        if (iframes[i].contentWindow.HTMLElement)
        {
            try {
                iframes[i].contentWindow.HTMLElement.prototype.offsetWidth = HTMLElement.prototype.offsetWidth;
                iframes[i].contentWindow.HTMLElement.prototype.offsetHeight = HTMLElement.prototype.offsetHeight;
            } catch (e) {
            }
        }

        if (iframes[i].contentWindow.HTMLCanvasElement)
        {
            let tb = iframes[i].contentWindow.HTMLCanvasElement.prototype.toBlob;
            if (tb !== HTMLCanvasElement.prototype.toBlob)
            {
                try {
                    iframes[i].contentWindow.HTMLCanvasElement.prototype.toBlob = HTMLCanvasElement.prototype.toBlob;
                    iframes[i].contentWindow.HTMLCanvasElement.prototype.toDataURL = HTMLCanvasElement.prototype.toDataURL;
                } catch (e) {
                }
            }
        }
    }
}`;
        window.top.document.documentElement.appendChild(script_2);
        script_2.remove();
    } catch (e) {}
}