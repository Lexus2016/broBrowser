// Get Config from LocalStorage
function getConfig(){return new Promise(function(a,b){chrome.storage.local.get(["fkConfig"],function(c){chrome.runtime.lastError?(console.error(chrome.runtime.lastError.message),b(chrome.runtime.lastError.message)):a(c.fkConfig)})})}// Change IP
if(chrome.storage.onChanged.addListener(function(){getConfig().then(function(a){document.documentElement.dataset.timeZoneV=a.timeZoneV,document.documentElement.dataset.newTimeOffset=a.newTimeOffset,document.documentElement.dataset.lang=a.lang,document.documentElement.dataset.langs=JSON.stringify(a.langs)})}),getConfig().then(function(a){document.documentElement.dataset.timeZoneV=a.timeZoneV,document.documentElement.dataset.newTimeOffset=a.newTimeOffset,document.documentElement.dataset.lang=a.lang,document.documentElement.dataset.langs=JSON.stringify(a.langs),document.documentElement.dataset.Browser=JSON.stringify(Profile);// This is function injected to Page
var b=function(){var a=Math.floor;console.log(".");// Config Start
// https://developers.whatismybrowser.com/useragents/explore/operating_system_name/ios/
var b=JSON.parse(document.documentElement.dataset.Browser),c=c||{},d=d||{};c.lang=document.documentElement.dataset.lang,c.langs=JSON.parse(document.documentElement.dataset.langs),d.newTimeOffset=document.documentElement.dataset.newTimeOffset,d.timeZoneV=document.documentElement.dataset.timeZoneV;// Config End
// Canvas Faker
var e=function(b){const c=HTMLCanvasElement.prototype[b];Object.defineProperty(HTMLCanvasElement.prototype,b,{value:function(){var b={r:a(10*Math.random())-5,g:a(10*Math.random())-5,b:a(10*Math.random())-5,a:a(10*Math.random())-5},d=this.width,e=this.height,f=this.getContext("2d");if(null===f)return c.apply(this,arguments);for(var g=f.getImageData(0,0,d,e),h=0;h<e;h++)for(var k,l=0;l<d;l++)k=h*(4*d)+4*l,g.data[k+0]=g.data[k+0]+b.r,g.data[k+1]=g.data[k+1]+b.g,g.data[k+2]=g.data[k+2]+b.b,g.data[k+3]=g.data[k+3]+b.a;return f.putImageData(g,0,0),c.apply(this,arguments)}})};e("toBlob"),e("toDataURL");// Window size faker
var f=function(a,b,c){Object.defineProperty(a,b,{enumerable:!0,configurable:!0,value:c})};f(window.screen,"width",b.window.width),f(window.screen,"height",b.window.height),f(window.screen,"availWidth",b.window.width),f(window.screen,"availHeight",b.window.height),f(window.screen,"top",0),f(window.screen,"left",0),f(window.screen,"availTop",0),f(window.screen,"availLeft",0),f(window.screen,"pixelDepth",b.window.pixelDepth),f(window.screen,"colorDepth",b.window.colorDepth),f(window.screen.orientation,"type",b.window.orientation_type),f(window.screen.orientation,"angle",b.window.orientation_angle),f(window,"innerWidth",b.window.innerWidth),f(window,"innerHeight",b.window.innerHeight),f(window,"outerWidth",b.window.outerWidth),f(window,"outerHeight",b.window.outerHeight),f(window,"clientWidth",b.window.innerWidth),f(window,"clientHeight",b.window.innerHeight),f(HTMLElement.prototype,"innerWidth",b.window.innerWidth),f(HTMLElement.prototype,"innerHeight",b.window.innerHeight),f(HTMLElement.prototype,"offsetWidth",b.window.innerWidth),f(HTMLElement.prototype,"offsetHeight",b.window.innerHeight),f(HTMLElement.prototype,"outerWidth",b.window.outerWidth),f(HTMLElement.prototype,"outerHeight",b.window.outerHeight),f(HTMLElement.prototype,"clientWidth",b.window.innerWidth),f(HTMLElement.prototype,"clientHeight",b.window.innerHeight),f(HTMLElement.prototype,"scrollWidth",b.window.innerWidth),f(HTMLElement.prototype,"scrollHeight",b.window.innerHeight),f(HTMLElement.prototype,"outerWidth",b.window.innerWidth),f(HTMLElement.prototype,"outerHeight",b.window.innerHeight),f(window,"clientHeight",b.window.innerHeight),Object.defineProperty(HTMLElement.prototype,"getBoundingClientRect",{value:()=>({bottom:b.window.innerHeight,height:b.window.innerHeight,left:0,right:b.window.innerWidth,top:0,width:b.window.innerWidth,x:0,y:0})}),Object.defineProperty(window,"getComputedStyle",{value:()=>({getPropertyValue:a=>"width"===a.toLowerCase()?b.window.innerWidth+"px":"height"===a.toLowerCase()?b.window.innerHeight+"px":void 0})}),f(window,"devicePixelRatio",b.window.devicePixelRatio),navigator.mediaDevices.getUserMedia=navigator.webkitGetUserMedia=navigator.mozGetUserMedia=navigator.getUserMedia=webkitRTCPeerConnection=RTCPeerConnection=MediaStreamTrack=void 0;// Navigator Faker
var g=function(a,b){navigator.__defineGetter__(a,function(){return b})};g("doNotTrack",1),g("deviceMemory",b.navigator.deviceMemory),g("hardwareConcurrency",b.navigator.deviceCPUs),g("productSub",b.navigator.productSub),g("oscpu",b.navigator.oscpu),g("plugins",b.plugins),g("mimeTypes",b.mimeTypes),b.global.isChangeLang&&(g("language",c.lang),g("languages",c.lang),g("systemLanguage",c.lang),g("userLanguage",c.lang),g("browserLanguage",c.lang)),b.global.isChangeUA&&(g("userAgent",b.navigator.userAgent),g("appVersion",b.navigator.appVersion),g("platform",b.navigator.platform),g("vendor",b.navigator.vendor)),b.global.isMobile&&g("maxTouchPoints",b.navigator.maxTouchPoints);// DateTime Faker
var h=new Date;const i=h.getTimezoneOffset();var j=(-i-d.newTimeOffset)/60,k=h.getTime()-60*(60*j),l=h.getHours(),m=Math.ceil(h.getHours()-j);const n=-d.newTimeOffset;// in minutes
if(0<d.newTimeOffset){if(10>d.newTimeOffset/60)var o="+0"+d.newTimeOffset/60;// in hour
else var o="+"+d.newTimeOffset/60;// in hour
}else if(!(0>d.newTimeOffset))var o="";else if(-10<d.newTimeOffset/60)var o="-0"+-d.newTimeOffset/60;// in hour
else var o="-"+-d.newTimeOffset/60;// in hour
// Font Faker
var p={noise:function(){var b=Math.random()<Math.random()?-1:1;return a(Math.random()+b*Math.random())},sign:function(){const b=[-1,-1,-1,-1,-1,-1,1,-1,-1,-1],c=a(Math.random()*b.length);return b[c]}};//
Object.defineProperty(HTMLElement.prototype,"offsetHeight",{get(){const a=b.window.innerHeight,c=a&&1===p.sign(),d=c?a+p.noise():a;//            const height = Math.floor(this.getBoundingClientRect().height);
//
//            if (valid && result !== height) {
//                window.top.postMessage("font-fingerprint-defender-alert", '*');
//            }
//
return d}}),Object.defineProperty(HTMLElement.prototype,"offsetWidth",{get(){const a=b.window.innerWidth,c=a&&1===p.sign(),d=c?a+p.noise():a;//            const width = Math.floor(this.getBoundingClientRect().width);
//
//            if (valid && result !== width) {
//                window.top.postMessage("font-fingerprint-defender-alert", '*');
//            }
//
return d}});//AudioContext Faker
const q={BUFFER:null,getChannelData:function(b){const c=b.prototype.getChannelData;Object.defineProperty(b.prototype,"getChannelData",{value:function(){const b=c.apply(this,arguments);if(q.BUFFER!==b){q.BUFFER=b;//                        window.top.postMessage("audiocontext-fingerprint-defender-alert", '*');
for(var d=0;d<b.length;d+=100){let c=a(Math.random()*d);b[c]+=1e-7*Math.random()}}//
return b}})},createAnalyser:function(b){const c=b.prototype.__proto__.createAnalyser;Object.defineProperty(b.prototype.__proto__,"createAnalyser",{value:function(){const b=c.apply(this,arguments),d=b.__proto__.getFloatFrequencyData;//
return Object.defineProperty(b.__proto__,"getFloatFrequencyData",{value:function(){//                            window.top.postMessage("audiocontext-fingerprint-defender-alert", '*');
const b=d.apply(this,arguments);for(var c=0;c<arguments[0].length;c+=100){let b=a(Math.random()*c);arguments[0][b]+=.1*Math.random()}//
return b}}),b}})}};//
// WebGL Faker
// DateTime Faker
//    window.top.postMessage("canvas-fingerprint-defender-alert", '*');
q.getChannelData(AudioBuffer),q.createAnalyser(AudioContext),q.getChannelData(OfflineAudioContext),q.createAnalyser(OfflineAudioContext),WebGLRenderingContext.prototype.getParameter=function(a){const c={37445:b.WebGL.WebGLUVendor,37446:b.WebGL.WebGLURender,7936:b.WebGL.WebGLVendor,7937:b.WebGL.WebGLRender};//pm[0x1F02] = "Version 1.99"; // VERSION
return function(b){return c[b]||a.call(this,b)}}(WebGLRenderingContext.prototype.getParameter),WebGL2RenderingContext.prototype.getParameter=function(a){const c={37445:b.WebGL.WebGLUVendor,37446:b.WebGL.WebGLURender,7936:b.WebGL.WebGLVendor,7937:b.WebGL.WebGLRender};return function(b){return c[b]||a.call(this,b)}}(WebGL2RenderingContext.prototype.getParameter),Object.defineProperty(Intl.DateTimeFormat.prototype,"format",{value:function(){return new Date().toUTCString();//            return (new Date()).toUTCString() + timeZoneHour.toString();
}}),Intl.DateTimeFormat.prototype.resolvedOptions=function(){return function(){return{calendar:"gregory",day:"2-digit",locale:c.lang,month:"2-digit",numberingSystem:"latn",timeZone:d.timeZoneV,year:"numeric"}}}(Intl.DateTimeFormat.prototype.resolvedOptions),Intl.NumberFormat.prototype.resolvedOptions=function(){return function(){return{locale:c.lang,maximumFractionDigits:3,minimumFractionDigits:0,minimumIntegerDigits:1,notation:"standard",numberingSystem:"latn",signDisplay:"auto",style:"decimal",useGrouping:!0}}}(Intl.NumberFormat.prototype.resolvedOptions),Intl.DisplayNames.prototype.resolvedOptions=function(){return function(){return{fallback:"code",locale:c.lang,style:"long",type:"language"}}}(Intl.DisplayNames.prototype.resolvedOptions),Intl.ListFormat.prototype.resolvedOptions=function(){return function(){return{locale:c.lang,style:"long",type:"conjunction"}}}(Intl.ListFormat.prototype.resolvedOptions),Intl.RelativeTimeFormat.prototype.resolvedOptions=function(){return function(){return{locale:c.lang,style:"long",numberingSystem:"latn",numeric:"always"}}}(Intl.RelativeTimeFormat.prototype.resolvedOptions),Intl.PluralRules.prototype.resolvedOptions=function(){return function(){return{locale:c.lang,maximumFractionDigits:3,minimumFractionDigits:0,minimumIntegerDigits:1,pluralCategories:["few","many","one","other"]}}}(Intl.PluralRules.prototype.resolvedOptions),function(){var a=new Date;//        return ['Milliseconds', 'Seconds', 'Minutes', 'Hours', 'Date', 'Month', 'FullYear', 'Year', 'Day'].forEach((function(_this) {
return Date.prototype.timezoneOffset=a.getTimezoneOffset(),Date.setTimezoneOffset=function(a){return this.prototype.timezoneOffset=a},Date.getTimezoneOffset=function(){return this.prototype.timezoneOffset},Date.prototype.getTimezoneOffset=function(){return this.timezoneOffset},Date.prototype.setTimezoneOffset=function(a){return this.timezoneOffset=a},Date.prototype.toString=function(){var b;return b=1e3*(60*this.timezoneOffset),a.setTime(this.getTime()-b),a.toUTCString()+o.toString()+"00"},Date.prototype.toLocaleString=function(){var a=new Date,b=a.getDate(),c=a.getMonth(),d=a.getFullYear(),e=a.getHours(),f=a.getMinutes(),g=a.getSeconds();return 10>b&&(b="0"+b),10>c&&(c="0"+c),10>e&&(e="0"+e),10>f&&(f="0"+f),10>g&&(g="0"+g),b+"."+c+"."+d+" "+e+":"+f+":"+g},Date.prototype.toLocaleTimeString=function(){var a=new Date,b=a.getHours(),c=a.getMinutes(),d=a.getSeconds();return 10>b&&(b="0"+b),10>c&&(c="0"+c),10>d&&(d="0"+d),b+":"+c+":"+d},["Milliseconds","Seconds","Minutes","Hours","Date","Month","FullYear","Day"].forEach(function(){return function(b){return Date.prototype["get"+b]=function(){var c;return c=1e3*(60*this.timezoneOffset),a.setTime(this.getTime()-c),a["getUTC"+b]()},Date.prototype["set"+b]=function(c){var d,e;return d=1e3*(60*this.timezoneOffset),a.setTime(this.getTime()-d),a["setUTC"+b](c),e=a.getTime()+d,this.setTime(e),e}}}(this))}(),b.global.isChangeTime&&Date.setTimezoneOffset(n),document.documentElement.dataset.cbscriptallow=!0};// Returns "bar"
try{var c=document.createElement("script");c.textContent="("+b+")()",(document.head||document.documentElement).appendChild(c),c.remove()}catch(a){}}),"true"!==document.documentElement.dataset.cbscriptallow)try{var script_2=document.createElement("script");script_2.textContent=`{
    const iframes = window.top.document.querySelectorAll("iframe[sandbox]");
    for (var i = 0; i < iframes.length; i++)
    {
        if (iframes[i].contentWindow)
        {
            if (iframes[i].contentWindow.AudioBuffer)
            {
                if (iframes[i].contentWindow.AudioBuffer.prototype)
                {
                    if (iframes[i].contentWindow.AudioBuffer.prototype.getChannelData)
                    {
                        iframes[i].contentWindow.AudioBuffer.prototype.getChannelData = AudioBuffer.prototype.getChannelData;
                    }
                }
            }

            if (iframes[i].contentWindow.AudioContext)
            {
                if (iframes[i].contentWindow.AudioContext.prototype)
                {
                    if (iframes[i].contentWindow.AudioContext.prototype.__proto__)
                    {
                        if (iframes[i].contentWindow.AudioContext.prototype.__proto__.createAnalyser)
                        {
                            iframes[i].contentWindow.AudioContext.prototype.__proto__.createAnalyser = AudioContext.prototype.__proto__.createAnalyser;
                        }
                    }
                }
            }

            if (iframes[i].contentWindow.OfflineAudioContext)
            {
                if (iframes[i].contentWindow.OfflineAudioContext.prototype)
                {
                    if (iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__)
                    {
                        if (iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__.createAnalyser)
                        {
                            iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__.createAnalyser = OfflineAudioContext.prototype.__proto__.createAnalyser;
                        }
                    }
                }
            }

            if (iframes[i].contentWindow.OfflineAudioContext)
            {
                if (iframes[i].contentWindow.OfflineAudioContext.prototype)
                {
                    if (iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__)
                    {
                        if (iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__.getChannelData)
                        {
                            iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__.getChannelData = OfflineAudioContext.prototype.__proto__.getChannelData;
                        }
                    }
                }
            }
        }

        if (iframes[i].contentWindow.HTMLElement)
        {
            iframes[i].contentWindow.HTMLElement.prototype.offsetWidth = HTMLElement.prototype.offsetWidth;
            iframes[i].contentWindow.HTMLElement.prototype.offsetHeight = HTMLElement.prototype.offsetHeight;
        }

        if (iframes[i].contentWindow.HTMLCanvasElement)
        {
            let tb = iframes[i].contentWindow.HTMLCanvasElement.prototype.toBlob;
            if (tb !== HTMLCanvasElement.prototype.toBlob)
            {
                iframes[i].contentWindow.HTMLCanvasElement.prototype.toBlob = HTMLCanvasElement.prototype.toBlob;
                iframes[i].contentWindow.HTMLCanvasElement.prototype.toDataURL = HTMLCanvasElement.prototype.toDataURL;
            }
        }
    }
}`,window.top.document.documentElement.appendChild(script_2),script_2.remove()}catch(a){}
