process.setMaxListeners(0);

const path = require('path');
const cors = require("cors");
const express = require("express");
const bodyParser = require('body-parser');
const fs = require('fs');

const {activateAPIToken, checkAPIToken, createDeviceZIP, getDevice, getDevices, getRequestParams} = require('./nodeLib/lib.js');

const APITokensPath = path.resolve(__dirname) + '/APITOKENS/';
const configPath = path.resolve(__dirname) + '/Config/';
const pluginPath = path.resolve(__dirname) + '/Core/';
const devicePath = path.resolve(__dirname) + '/Devices/';
const profileUploadPath = path.resolve(__dirname) + '/Plugins/';

// Create WebServer
const app = express();
app.use(cors());
app.set('trust proxy', true);
app.use(bodyParser.json()); // to support JSON-encoded bodies
app.use(bodyParser.text()); // to support TEXT-encoded bodies
app.use(bodyParser.urlencoded({ // to support URL-encoded bodies
    extended: true
}));

// WebServer Routing

// Check Alive
/*
http://127.0.0.1:5000/ping
*/

app.get('/ping', (request, response) => {
    const {ip} = getRequestParams(request);

    console.log(new Date().toUTCString() + ' : Get Ping -> Send: Pong > IP: ' + ip);
    response.send(new Date().toUTCString() + ' : Pong!');
});

/*
 http://127.0.0.1:5000/validate/?token=thisistesttokenfortesting10&computer=JKHGUYGAKJGGGILLK
*/
app.get('/validate', (request, response) => {

    const {token, computer, ip} = getRequestParams(request);

    // Check API Token Exists, check Valid Computer and Not Expired
    checkAPIToken(APITokensPath, token, computer).then((data) => {

        if (data.toString() === '9') {
            // Activate Token and Computer
            console.debug(new Date().toUTCString() + ' : Activate: Token-Computer-IP: ' + token + '-' + computer + '-' + ip);
            activateAPIToken(APITokensPath, token, computer);
            response.send('1');
        } else {
            if (data === '0') {
                console.log(new Date().toUTCString() + ' : Forbidden: Token-Computer-IP: ' + token + '-' + computer + '-' + ip);
            } else {
                console.log(new Date().toUTCString() + ' : Allow: Token-Computer-IP: ' + token + '-' + computer + '-' + ip);
            }
            // 0-Forbidden / 1-Access
            response.send(data);
        }
    });

});

/*
http://127.0.0.1:5000/getDeviceList/?token=thisistesttokenfortesting10&computer=JKHGUYGAKJGGGILLK
*/
app.get('/getDeviceList', (request, response) => {

    const {token, computer, ip} = getRequestParams(request);

    console.debug(new Date().toUTCString() + ' : getDeviceList > Token-Computer-IP: ' + token + '-' + computer + '-' + ip);

    // Get List of Devices
    getDevices(APITokensPath, devicePath, token, computer).then((data) => {
        response.json(data);
    });

});

/*
http://127.0.0.1:5000/getDevice/?token=thisistesttokenfortesting10&computer=JKHGUYGAKJGGGILLK&deviceFile=1.js
*/
app.get('/getDevice', (request, response) => {

    const {token, computer, ip, deviceFile} = getRequestParams(request);

    console.debug(new Date().toUTCString() + ' : getDevice : Token-Computer-IP: ' + token + '-' + computer + '-' + ip);

    // Get Device Profile
    getDevice(APITokensPath, devicePath, deviceFile, token, computer).then((data) => {
        response.send(data);
    });

});

/*
http://127.0.0.1:5000/getProfileFile/?token=thisistesttokenfortesting10&computer=JKHGUYGAKJGGGILLK&deviceFile=001
*/
app.get('/getProfileFile', (request, response) => {

    const {token, computer, ip, deviceFile} = getRequestParams(request);

    console.debug(new Date().toUTCString() + ' : getProfileFile : Token-Computer-IP: ' + token + '-' + computer + '-' + ip);

    // Get Device Profile
    createDeviceZIP(APITokensPath, devicePath, configPath, pluginPath, deviceFile, token, computer).then((data) => {
        //set the archive name
        if (data) {
            console.debug(new Date().toUTCString() + ' : Send Profile Zip-File: ' + data + ' : Token-Computer-IP: ' + token + '-' + computer + '-' + ip);
            response.download(data, 'profile.zip');
        } else {
            response.send('0');
        }
    });

});

/*
http://127.0.0.1:5000/getPluginFile/?token=thisistesttokenfortesting10&computer=JKHGUYGAKJGGGILLK&deviceFile=001
*/
app.get('/getPluginFile', (request, response) => {

    const {token, computer, ip, deviceFile} = getRequestParams(request);

    console.debug(new Date().toUTCString() + ' : getPluginFile : Token-Computer-IP: ' + token + '-' + computer + '-' + ip + '-' + deviceFile);

    checkAPIToken(APITokensPath, token, computer).then((data) => {

        if (data !== '1') {
            console.debug(new Date().toUTCString() + ' : >>> FORBIDDEN!');
            response.send('0');
        }

    }).then(() => {
        let filePluginFilePath = profileUploadPath + "tmp_" + deviceFile + ".zip";
        if (filePluginFilePath && fs.existsSync(filePluginFilePath)) {
            console.debug(new Date().toUTCString() + ' : Send profile > ' + filePluginFilePath);
            response.download(filePluginFilePath, "tmp.zip");
        } else {
            console.debug(new Date().toUTCString() + ' : >>> ERROR Send profile > \' + filePluginFilePath!');
            response.send('0');
        }
    });
});

// Start WebServer on Port: 5000
app.listen('5000');
