const fs = require('fs');
const path = require('path');

// Find all device Profiles
function getDevices(APITokensPath, devicePath, token, computer) {

    return new Promise((resolve) => {
        checkAPIToken(APITokensPath, token, computer).then((data) => {
            if (data !== '1') {
                resolve('0');
            }
        }).then(() => {
            let targetFiles = [];
            targetFiles.length = 0;

            fs.readdir(devicePath, function (err, files) {

                let filesList = files.filter(function (e) {
                    return path.extname(e).toLowerCase() === '.js'
                });
                //console.log(filesList);

                filesList.forEach(file => {
                    require(devicePath + file);
                    targetFiles.push({
                        'file': file,
                        'profile': Profile.name,
                        'device': Profile.device,
                        'OSName': Profile.OSName,
                        'OSVersion': Profile.OSVersion,
                        'BrowserName': Profile.BrowserName,
                        'BrowserVersion': Profile.BrowserVersion
                    });
                    delete require.cache[devicePath + file];
                });

                targetFiles.sort(function (a, b) {
                    let tmpOsV_a = a['OSVersion'];
                    let tmpOsV_b = b['OSVersion'];

                    if (a['OSVersion'] < 10) {
                        tmpOsV_a = '0' + a['OSVersion'];
                    }
                    if (b['OSVersion'] < 10) {
                        tmpOsV_b = '0' + b['OSVersion'];
                    }
                    return (a['device'] + a['OSName'] + tmpOsV_a + a['BrowserName'] + a['BrowserVersion']).localeCompare(b['device'] + b['OSName'] + tmpOsV_b + +b['BrowserName'] + b['BrowserVersion']);
                });

                resolve(targetFiles);
            });
        });
    });
}

// Get Global Config and Device Profile (Together)
function getGlobalConfig(APITokensPath, devicePath, configPath, deviceFile, token, computer) {

    return new Promise((resolve) => {
        checkAPIToken(APITokensPath, token, computer).then((data) => {
            if (data !== '1') {
                resolve('0');
            }
        }).then(() => {
            fs.readFile(configPath + 'config.js', function read(err, data1) {
                let resultContent = data1;
                fs.readFile(devicePath + deviceFile, function read(err, data2) {
                    resultContent += "\n" + data2;
                    resolve(resultContent.toString());
                });
            });
        });
    });
}

// Get Global Config and Device Profile (Separate)
function getConfig(APITokensPath, configPath, token, computer) {

    return new Promise((resolve) => {
        checkAPIToken(APITokensPath, token, computer).then((data) => {
            if (data !== '1') {
                resolve('0');
            }
        }).then(() => {
            fs.readFile(configPath + 'config.js', function read(err, data) {
                resolve(data.toString());
            });
        });
    });
}

// Get Device Profile (Separate)
function getDevice(APITokensPath, devicePath, deviceFile, token, computer) {

    return new Promise((resolve) => {
        checkAPIToken(APITokensPath, token, computer).then((data) => {
            if (data !== '1') {
                resolve('0');
            }
        }).then(() => {
            fs.readFile(devicePath + deviceFile, function read(err, data) {
                if (data) {
                    resolve(data.toString());
                } else {
                    resolve('');
                }
            });
        });
    });
}

// Activate API Token
function activateAPIToken(APITokensPath, token, computer) {

    let result = {
        'computer': computer,
        'date': Date.now() + 10 * 24 * 60 * 60 * 1000 // +30 days
    };

    try {
        fs.writeFileSync(APITokensPath + token + '.js', JSON.stringify(result));
    } catch (e) {
        return '0';
    }

    return '1';
}

// Check API Token Exists, check Valid Computer and Not Expired
function checkAPIToken(APITokensPath, token, computer) {

    return new Promise((resolve) => {
        // Input Data small
        if (!token || !computer || typeof token === undefined || typeof computer === undefined) {
            console.log('checkAPIToken: Input Data small');
            resolve('0');
        }

        fs.readFile(APITokensPath + token + '.js', function read(err, data) {
            try {
                let content = data.toString();

                // Broken info
                if (content.length < 10) {
                    resolve('9');
                } else {

                    // No Valid JSON or Verification data
                    try {
                        let contentJSON = JSON.parse(content);

                        // Computer No Valid
                        if (computer !== contentJSON['computer']) {
                            console.log('checkAPIToken: Computer error');
                            resolve('0');
                        }

                        // Date Expired
                        if (Date.now() > contentJSON['date']) {
                            console.log('checkAPIToken: Date expire');
                            resolve('0');
                        }
                    } catch (e) {
                        // JSON Broken
                        console.log('checkAPIToken: Exception error 1: ' + e);
                        resolve('0');
                    }

                    // validate OK!
                    resolve('1');
                }
            } catch (e) {
                console.log('checkAPIToken: Exception error 2: ' + e);
                // Token Not Found
                resolve('0');
            }
        });
    });
}

function createDeviceZIP(APITokensPath, devicePath, configPath, pluginPath, deviceFile, token, computer) {

    return new Promise((resolve) => {
        let ncp = require('ncp').ncp;

        let tmpDir = devicePath.replace('Devices', 'tmp');
        let tmpPluginDir = tmpDir + '/Plugin/';

        // Create tmp folder
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir);
        }

        // Delete OLD files
        if (fs.existsSync(tmpPluginDir)) {
            try {
                fs.rmdirSync(tmpPluginDir, {
                    recursive: true
                });
            } catch (e) {

            }
        }

        // Copy Plugins Core to Tmp Folder
        ncp(pluginPath, tmpPluginDir, function (err) {
            if (err) {
                resolve('');
            }

            // Get config and device
            getGlobalConfig(APITokensPath, devicePath, configPath, deviceFile, token, computer)
                .then((data) => {
                    try {
                        // Write Device Profile
                        fs.writeFileSync(tmpPluginDir + 'Profile.js', data.toString());
                    } catch (e) {
                    }
                })
                .then(() => {

                    try {
                        // Remove Old Zip file
                        fs.unlinkSync(tmpDir + token + '.zip')
                    } catch (err) {
                    }

                    // Make Zip file
                    let zip = getZippedFolderSync(tmpPluginDir);

                    // Write Zip file
                    fs.writeFileSync(tmpDir + token + '.zip', zip);
                })
                .then(() => {
                    resolve(tmpDir + token + '.zip');
                });
        });
    });
}

// Zip folder
function getZippedFolderSync(dir) {
    let JSZip = require("jszip-sync");

    let allPaths = getFilePathsRecursiveSync(dir);

    let zip = new JSZip();
    return zip.sync(() => {
        for (let filePath of allPaths) {
            let addPath = path.relative(path.join(dir, ".."), filePath);
            // let addPath = path.relative(dir, filePath) // use this instead if you don't want the source folder itself in the zip

            let data = fs.readFileSync(filePath);
            zip.file(addPath, data);
        }
        let data = null;
        zip.generateAsync({
            type: "nodebuffer"
        }).then((content) => {
            data = content;
        });
        return data;
    })
}

// returns a flat array of absolute paths of all files recursively contained in the dir
function getFilePathsRecursiveSync(dir) {
    let results = []
    let list = fs.readdirSync(dir);
    let pending = list.length;
    if (!pending) return results;

    for (let file of list) {
        file = path.resolve(dir, file);
        let stat = fs.statSync(file);
        if (stat && stat.isDirectory()) {
            let res = getFilePathsRecursiveSync(file);
            results = results.concat(res);
        } else {
            results.push(file);
        }
        if (!--pending) return results;
    }

    return results;
}

function getRequestParams(request) {
    let token = encodeURI(request.query['token']);
    let computer = encodeURI(request.query['computer']);
    let ip = request.headers['x-forwarded-for'] || request.connection.remoteAddress || request.socket.remoteAddress;
    let deviceFile = encodeURI(request.query.deviceFile);

    return {
        token: token !== undefined ? token : '',
        computer: computer !== undefined ? computer : '',
        ip: ip !== undefined ? ip : '',
        deviceFile: deviceFile !== undefined ? deviceFile : ''
    };
}

// ====================
// ====================
// ====================
// ====================

// Export functions
module.exports = {
    getDevices,
    getGlobalConfig,
    getConfig,
    getDevice,
    checkAPIToken,
    activateAPIToken,
    createDeviceZIP,
    getRequestParams
};

/*
 Examples
*/

// Lib.createDeviceZIP(APITokensPath, devicePath, configPath, pluginPath, deviceFile, token, computer)
//     .then(data => {
//         console.debug(data);
//     });

// Activate API Token
// if(Lib.activateAPIToken(APITokensPath, token, computer) === '1') {
//      console.debug('// Activate API Token');
// } else {
//     console.debug('// NO! Activate API Token');
// }

// Check API Token Exists, check Valid Computer and Not Expired
// Lib.checkAPIToken(APITokensPath, token, computer).then((data) => {
//      console.debug('// Check API Token Exists, check Valid Computer and Not Expired');
//      console.debug(data);
//  });

// Find all device Profiles
// Lib.getDevices(APITokensPath, devicePath, token, computer).then((data) => {
//     console.debug('// Find all device Profiles');
//     console.debug(data);
// });

// Get Global Config and Device Profile (Together)
// Lib.getGlobalConfig(APITokensPath, devicePath, configPath, deviceFile, token, computer).then((data) => {
//     console.debug('// Get Global Config and Device Profile (Together)');
//     console.debug(data);
// });

// Get Global Config and Device Profile (Separate) - config.js
// Lib.getConfig(APITokensPath, configPath, token, computer).then((data) => {
//     console.debug('// Get Global Config - config.js');
//     console.debug(data);
// });

// Get Global Config and Device Profile (Separate) - config.js
// Lib.getDevice(APITokensPath, devicePath, '7.js', token, computer).then((data) => {
//     console.debug('// Get Device Profile - Profile.js');
//     console.debug(data);
// });