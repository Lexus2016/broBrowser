Profile = {"device":"Mobile","OSName":"iOS","OSVersion":13.7,"BrowserName":"DuckDuckGo","BrowserVersion":7,"global":{"isMobile":true},"navigator":{"plugins":{"length":0},"mimeTypes":{"length":0},"cookieEnabled":true,"standalone":"","webdriver":"","maxTouchPoints":5,"appCodeName":"Mozilla","appName":"Netscape","appVersion":"5.0 (iPhone; CPU iPhone OS 13_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.7 Mobile/15E148 DuckDuckGo/7 Safari/605.1.15","platform":"iPhone","product":"Gecko","productSub":"20030107","userAgent":"Mozilla/5.0 (iPhone; CPU iPhone OS 13_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.7 Mobile/15E148 DuckDuckGo/7 Safari/605.1.15","vendor":"Apple Computer, Inc.","vendorSub":"","onLine":true},"window":{"name":"","status":"","closed":"","length":"","innerHeight":647,"innerWidth":375,"scrollX":"","pageXOffset":"","scrollY":"","pageYOffset":"","screenX":"","screenY":"","outerWidth":375,"outerHeight":647,"devicePixelRatio":2,"orientation":"","defaultStatus":"","defaultstatus":"","offscreenBuffering":true,"screenLeft":"","screenTop":"","origin":"","isSecureContext":true},"screen":{"height":667,"width":375,"colorDepth":32,"pixelDepth":32,"availLeft":"","availTop":"","availHeight":667,"availWidth":375},"WebGLInfo":{"contextName":"webgl","glVersion":"WebGL 1.0","shadingLanguageVersion":"WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.00)","vendor":"WebKit","renderer":"WebKit WebGL","unMaskedVendor":"Apple Inc.","unMaskedRenderer":"Apple GPU","antialias":"Available","angle":"No","maxColorBuffers":1,"redBits":8,"greenBits":8,"blueBits":8,"alphaBits":8,"depthBits":24,"stencilBits":0,"maxRenderBufferSize":4096,"maxCombinedTextureImageUnits":8,"maxCubeMapTextureSize":4096,"maxFragmentUniformVectors":64,"maxTextureImageUnits":8,"maxTextureSize":4096,"maxVaryingVectors":8,"maxVertexAttributes":16,"maxVertexTextureImageUnits":8,"maxVertexUniformVectors":128,"maxAnisotropy":16,"extensions":["EXT_blend_minmax","EXT_sRGB","OES_texture_float","OES_texture_float_linear","OES_texture_half_float","OES_texture_half_float_linear","OES_standard_derivatives","EXT_shader_texture_lod","EXT_texture_filter_anisotropic","OES_vertex_array_object","OES_element_index_uint","WEBGL_lose_context","WEBKIT_WEBGL_compressed_texture_pvrtc","WEBGL_depth_texture","ANGLE_instanced_arrays","WEBGL_debug_renderer_info"],"webgl2Status":"webgl2 and experimental-webgl2 contexts not available.","webgl2Functions":[]},"WebGLInfo2":[]};


Profile["name"] = Profile.device + ": " + Profile.OSName + " " + Profile.OSVersion + "/" + Profile.BrowserName + " " + Profile.BrowserVersion;

try {
    Languages = {
        "lang": "en",
        "langs": ["en"]
    };
} catch (e) {
    Languages = {};
}

TimeSettings = {
    "newTimeOffset": new Date().getTimezoneOffset(),
    "timeZoneV": "Europe/Berlin"
};
