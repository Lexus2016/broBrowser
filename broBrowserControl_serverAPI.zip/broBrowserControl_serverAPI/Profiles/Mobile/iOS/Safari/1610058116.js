Profile = {"device":"Mobile","OSName":"iOS","OSVersion":10.1,"BrowserName":"Safari","BrowserVersion":10,"global":{"isMobile":true},"navigator":{"plugins":{"length":0},"mimeTypes":{"length":0},"cookieEnabled":true,"standalone":"","appCodeName":"Mozilla","appName":"Netscape","appVersion":"5.0 (iPhone; CPU iPhone OS 10_1_1 like Mac OS X) AppleWebKit/602.2.14 (KHTML, like Gecko) Version/10.0 Mobile/14B100 Safari/602.1","platform":"iPhone","product":"Gecko","productSub":"20030107","userAgent":"Mozilla/5.0 (iPhone; CPU iPhone OS 10_1_1 like Mac OS X) AppleWebKit/602.2.14 (KHTML, like Gecko) Version/10.0 Mobile/14B100 Safari/602.1","vendor":"Apple Computer, Inc.","vendorSub":"","onLine":true},"window":{"screen":{"height":568,"width":320,"colorDepth":32,"pixelDepth":32,"availLeft":0,"availTop":0,"availHeight":568,"availWidth":320},"offscreenBuffering":true,"outerHeight":"","outerWidth":"","innerHeight":460,"innerWidth":320,"screenX":"","screenY":"","screenLeft":"","screenTop":"","scrollX":"","scrollY":"","pageXOffset":"","pageYOffset":"","closed":"","length":"","name":"","status":"","defaultStatus":"","defaultstatus":"","devicePixelRatio":2,"orientation":""},"screen":{"height":568,"width":320,"colorDepth":32,"pixelDepth":32,"availLeft":"","availTop":"","availHeight":568,"availWidth":320},"WebGLInfo":{"contextName":"webgl","glVersion":"WebGL 1.0 (OpenGL ES 2.0 IMGSGX543-128)","shadingLanguageVersion":"WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.00)","vendor":"WebKit","renderer":"WebKit WebGL","unMaskedVendor":"Imagination Technologies","unMaskedRenderer":"PowerVR SGX 543","antialias":"Available","angle":"No","maxColorBuffers":1,"redBits":8,"greenBits":8,"blueBits":8,"alphaBits":8,"depthBits":24,"stencilBits":0,"maxRenderBufferSize":4096,"maxCombinedTextureImageUnits":8,"maxCubeMapTextureSize":4096,"maxFragmentUniformVectors":64,"maxTextureImageUnits":8,"maxTextureSize":4096,"maxVaryingVectors":8,"maxVertexAttributes":16,"maxVertexTextureImageUnits":8,"maxVertexUniformVectors":128,"maxAnisotropy":2,"extensions":["EXT_blend_minmax","EXT_sRGB","OES_texture_float","OES_texture_float_linear","OES_texture_half_float","OES_texture_half_float_linear","OES_standard_derivatives","EXT_shader_texture_lod","EXT_texture_filter_anisotropic","OES_vertex_array_object","OES_element_index_uint","WEBGL_lose_context","WEBKIT_WEBGL_compressed_texture_pvrtc","WEBGL_depth_texture","ANGLE_instanced_arrays","WEBGL_debug_renderer_info"],"webgl2Status":"webgl2 and experimental-webgl2 contexts not available.","webgl2Functions":[]},"WebGLInfo2":[]};


Profile["name"] = Profile.device + ": " + Profile.OSName + " " + Profile.OSVersion + "/" + Profile.BrowserName + " " + Profile.BrowserVersion;

try {
    Languages = {
        "lang": "en",
        "langs": ["en"]
    };
} catch (e) {
    Languages = {};
}

TimeSettings = {
    "newTimeOffset": new Date().getTimezoneOffset(),
    "timeZoneV": "Europe/Berlin"
};
