Profile = {"device":"Mobile","OSName":"iOS","OSVersion":14.3,"BrowserName":"Firefox iOS","BrowserVersion":8.1,"global":{"isMobile":true},"navigator":{"cookieEnabled":true,"standalone":"","webdriver":"","maxTouchPoints":5,"appCodeName":"Mozilla","appName":"Netscape","appVersion":"5.0 (iPhone; CPU iPhone OS 14_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/8.1.6 Mobile/15E148 Safari/605.1.15","platform":"iPhone","product":"Gecko","productSub":"20030107","userAgent":"Mozilla/5.0 (iPhone; CPU iPhone OS 14_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/8.1.6 Mobile/15E148 Safari/605.1.15","vendor":"Apple Computer, Inc.","vendorSub":"","onLine":true,"plugins":{"length":0},"mimeTypes":{"length":0}},"window":{"name":"","status":"","closed":"","length":"","innerHeight":787,"innerWidth":414,"scrollX":"","pageXOffset":"","scrollY":"","pageYOffset":"","screenX":"","screenY":"","outerWidth":414,"outerHeight":821,"devicePixelRatio":2,"orientation":"","defaultStatus":"","defaultstatus":"","offscreenBuffering":true,"screenLeft":"","screenTop":"","origin":"","isSecureContext":true},"screen":{"height":896,"width":414,"colorDepth":32,"pixelDepth":32,"availLeft":"","availTop":"","availHeight":896,"availWidth":414},"WebGLInfo":{"contextName":"webgl","glVersion":"WebGL 1.0","shadingLanguageVersion":"WebGL GLSL ES 1.0 (1.0)","vendor":"WebKit","renderer":"WebKit WebGL","unMaskedVendor":"Apple Inc.","unMaskedRenderer":"Apple GPU","antialias":"Available","angle":"No","maxColorBuffers":1,"redBits":8,"greenBits":8,"blueBits":8,"alphaBits":8,"depthBits":24,"stencilBits":0,"maxRenderBufferSize":16384,"maxCombinedTextureImageUnits":32,"maxCubeMapTextureSize":16384,"maxFragmentUniformVectors":224,"maxTextureImageUnits":16,"maxTextureSize":16384,"maxVaryingVectors":15,"maxVertexAttributes":16,"maxVertexTextureImageUnits":16,"maxVertexUniformVectors":512,"maxAnisotropy":16,"extensions":["EXT_blend_minmax","EXT_sRGB","OES_texture_float","OES_texture_half_float","OES_texture_half_float_linear","OES_standard_derivatives","EXT_shader_texture_lod","EXT_texture_filter_anisotropic","OES_vertex_array_object","OES_element_index_uint","WEBGL_lose_context","WEBGL_compressed_texture_astc","WEBGL_compressed_texture_etc","WEBGL_compressed_texture_etc1","WEBKIT_WEBGL_compressed_texture_pvrtc","WEBGL_depth_texture","ANGLE_instanced_arrays","WEBGL_debug_shaders","WEBGL_debug_renderer_info","EXT_color_buffer_half_float"],"webgl2Status":"webgl2 and experimental-webgl2 contexts not available.","webgl2Functions":[]},"WebGLInfo2":[]};


Profile["name"] = Profile.device + ": " + Profile.OSName + " " + Profile.OSVersion + "/" + Profile.BrowserName + " " + Profile.BrowserVersion;

try {
    Languages = {
        "lang": "en",
        "langs": ["en"]
    };
} catch (e) {
    Languages = {};
}

TimeSettings = {
    "newTimeOffset": new Date().getTimezoneOffset(),
    "timeZoneV": "Europe/Berlin"
};
