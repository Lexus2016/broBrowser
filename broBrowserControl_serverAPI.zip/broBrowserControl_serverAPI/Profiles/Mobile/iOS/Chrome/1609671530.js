Profile = {"device":"Mobile","OSName":"iOS","OSVersion":13.5,"BrowserName":"Chrome","BrowserVersion":87,"global":{"isMobile":true},"navigator":{"plugins":{"length":0},"mimeTypes":{"length":0},"cookieEnabled":true,"standalone":"","webdriver":"","maxTouchPoints":5,"appCodeName":"Mozilla","appName":"Netscape","appVersion":"5.0 (iPhone; CPU iPhone OS 13_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/87.0.4280.77 Mobile/15E148 Safari/604.1","platform":"iPhone","product":"Gecko","productSub":"20030107","userAgent":"Mozilla/5.0 (iPhone; CPU iPhone OS 13_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/87.0.4280.77 Mobile/15E148 Safari/604.1","vendor":"Apple Computer, Inc.","vendorSub":"","onLine":true},"window":{"internal$$module$__$__$third_party$text_fragments_polyfill$src$src$text_fragment_utils":{"BLOCK_ELEMENTS":["ADDRESS","ARTICLE","ASIDE","BLOCKQUOTE","DETAILS","DIALOG","DD","DIV","DL","DT","FIELDSET","FIGCAPTION","FIGURE","FOOTER","FORM","H1","H2","H3","H4","H5","H6","HEADER","HGROUP","HR","LI","MAIN","NAV","OL","P","PRE","SECTION","TABLE","UL"]},"start_main_frame_injected":true,"start_all_frames_injected":true,"MAX_EXACT_MATCH_LENGTH$$module$__$__$third_party$text_fragments_polyfill$src$src$fragment_generation_utils":300,"name":"","status":"","closed":"","length":"","innerHeight":2121,"innerWidth":980,"scrollX":"","pageXOffset":"","scrollY":"","pageYOffset":"","screenX":"","screenY":"","outerWidth":414,"outerHeight":896,"devicePixelRatio":2,"orientation":"","defaultStatus":"","defaultstatus":"","offscreenBuffering":true,"screenLeft":"","screenTop":"","origin":"","isSecureContext":true},"screen":{"height":896,"width":414,"colorDepth":32,"pixelDepth":32,"availLeft":"","availTop":"","availHeight":896,"availWidth":414},"WebGLInfo":{"contextName":"webgl","glVersion":"WebGL 1.0","shadingLanguageVersion":"WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.00)","vendor":"WebKit","renderer":"WebKit WebGL","unMaskedVendor":"Apple Inc.","unMaskedRenderer":"Apple GPU","antialias":"Available","angle":"No","maxColorBuffers":1,"redBits":8,"greenBits":8,"blueBits":8,"alphaBits":8,"depthBits":24,"stencilBits":0,"maxRenderBufferSize":4096,"maxCombinedTextureImageUnits":8,"maxCubeMapTextureSize":4096,"maxFragmentUniformVectors":64,"maxTextureImageUnits":8,"maxTextureSize":4096,"maxVaryingVectors":8,"maxVertexAttributes":16,"maxVertexTextureImageUnits":8,"maxVertexUniformVectors":128,"maxAnisotropy":16,"extensions":["EXT_blend_minmax","EXT_sRGB","OES_texture_float","OES_texture_float_linear","OES_texture_half_float","OES_texture_half_float_linear","OES_standard_derivatives","EXT_shader_texture_lod","EXT_texture_filter_anisotropic","OES_vertex_array_object","OES_element_index_uint","WEBGL_lose_context","WEBKIT_WEBGL_compressed_texture_pvrtc","WEBGL_depth_texture","ANGLE_instanced_arrays","WEBGL_debug_renderer_info"],"webgl2Status":"webgl2 and experimental-webgl2 contexts not available.","webgl2Functions":[]},"WebGLInfo2":[]};


Profile["name"] = Profile.device + ": " + Profile.OSName + " " + Profile.OSVersion + "/" + Profile.BrowserName + " " + Profile.BrowserVersion;

try {
    Languages = {
        "lang": "en",
        "langs": ["en"]
    };
} catch (e) {
    Languages = {};
}

TimeSettings = {
    "newTimeOffset": new Date().getTimezoneOffset(),
    "timeZoneV": "Europe/Berlin"
};
