Profile = {"device":"Mobile","OSName":"Android","OSVersion":5.1,"BrowserName":"Opera","BrowserVersion":33,"global":{"isMobile":true},"navigator":{"vendorSub":"","productSub":"20030107","vendor":"Google Inc.","maxTouchPoints":5,"hardwareConcurrency":4,"cookieEnabled":true,"appCodeName":"Mozilla","appName":"Netscape","appVersion":"5.0 (Linux; U; Android 5.1; HUAWEI TIT-U02 Build/HUAWEITIT-U02; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/64.0.3282.137 Mobile Safari/537.36 OPR/33.0.2254.125672","platform":"Linux armv7l","product":"Gecko","userAgent":"Mozilla/5.0 (Linux; U; Android 5.1; HUAWEI TIT-U02 Build/HUAWEITIT-U02; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/64.0.3282.137 Mobile Safari/537.36 OPR/33.0.2254.125672","onLine":true,"connection":{"downlink":9.4,"downlinkMax":42,"type":"cellular","effectiveType":"4g","rtt":0},"plugins":{"length":0},"mimeTypes":{"length":0},"deviceMemory":2},"window":{"length":"","closed":"","origin":"","name":"description","status":"","innerWidth":360,"innerHeight":519,"scrollX":"","pageXOffset":"","scrollY":"","pageYOffset":"","screenX":"","screenY":"","outerWidth":360,"outerHeight":519,"devicePixelRatio":2,"screenLeft":"","screenTop":"","defaultStatus":"","defaultstatus":"","isSecureContext":true,"orientation":"","TEMPORARY":"","PERSISTENT":1},"screen":{"availWidth":360,"availHeight":640,"width":360,"height":640,"colorDepth":24,"pixelDepth":24,"availLeft":"","availTop":"","orientation":{"angle":0,"type":"portrait-primary"}},"WebGLInfo":{"contextName":"webgl","glVersion":"WebGL 1.0 (OpenGL ES 2.0 Chromium)","shadingLanguageVersion":"WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.0 Chromium)","vendor":"WebKit","renderer":"WebKit WebGL","unMaskedVendor":"ARM","unMaskedRenderer":"Mali-400 MP","antialias":"Available","angle":"No","maxColorBuffers":1,"redBits":8,"greenBits":8,"blueBits":8,"alphaBits":8,"depthBits":24,"stencilBits":0,"maxRenderBufferSize":4096,"maxCombinedTextureImageUnits":8,"maxCubeMapTextureSize":4096,"maxFragmentUniformVectors":256,"maxTextureImageUnits":8,"maxTextureSize":4096,"maxVaryingVectors":12,"maxVertexAttributes":16,"maxVertexTextureImageUnits":0,"maxVertexUniformVectors":256,"maxAnisotropy":"n/a","extensions":["EXT_blend_minmax","EXT_shader_texture_lod","OES_standard_derivatives","OES_vertex_array_object","WEBGL_compressed_texture_etc1","WEBGL_debug_renderer_info","WEBGL_debug_shaders","WEBGL_depth_texture","WEBKIT_WEBGL_depth_texture","WEBGL_lose_context","WEBKIT_WEBGL_lose_context"],"webgl2Status":"webgl2 and experimental-webgl2 contexts not available.","webgl2Functions":[]},"WebGLInfo2":[]};


Profile["name"] = Profile.device + ": " + Profile.OSName + " " + Profile.OSVersion + "/" + Profile.BrowserName + " " + Profile.BrowserVersion;

try {
    Languages = {
        "lang": "en",
        "langs": ["en"]
    };
} catch (e) {
    Languages = {};
}

TimeSettings = {
    "newTimeOffset": new Date().getTimezoneOffset(),
    "timeZoneV": "Europe/Berlin"
};
