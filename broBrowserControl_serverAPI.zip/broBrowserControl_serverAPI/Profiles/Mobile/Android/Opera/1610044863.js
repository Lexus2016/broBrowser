Profile = {"device":"Mobile","OSName":"Android","OSVersion":10,"BrowserName":"Opera","BrowserVersion":42,"global":{"isMobile":true},"navigator":{"vendorSub":"","productSub":"20030107","vendor":"Google Inc.","maxTouchPoints":5,"hardwareConcurrency":8,"appCodeName":"Mozilla","appName":"Netscape","appVersion":"5.0 (Linux; Android 10.0; M2003J15SC Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.91 Mobile Safari/537.36 OPR/42.7.2246.114996","platform":"Linux armv8l","product":"Gecko","userAgent":"Mozilla/5.0 (Linux; Android 10.0; M2003J15SC Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.91 Mobile Safari/537.36 OPR/42.7.2246.114996","onLine":true,"cookieEnabled":true,"plugins":{"length":0},"mimeTypes":{"length":0}},"window":{"speechSynthesis":{"pending":false,"speaking":false,"paused":false},"webkitStorageInfo":{"TEMPORARY":0,"PERSISTENT":1},"orientation":"","isSecureContext":true,"defaultstatus":"","defaultStatus":"","screenTop":"","screenLeft":"","devicePixelRatio":2.75,"outerHeight":714,"outerWidth":393,"screenY":"","screenX":"","pageYOffset":"","scrollY":"","pageXOffset":"","scrollX":"","innerHeight":714,"innerWidth":393,"length":"","closed":"","status":"","name":"description","TEMPORARY":"","PERSISTENT":1},"screen":{"availWidth":393,"availHeight":851,"width":393,"height":851,"colorDepth":32,"pixelDepth":32,"availLeft":"","availTop":"","orientation":{"angle":0,"type":"portrait-primary"}},"WebGLInfo":{"contextName":"webgl","glVersion":"WebGL 1.0 (OpenGL ES 2.0 Chromium)","shadingLanguageVersion":"WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.0 Chromium)","vendor":"WebKit","renderer":"WebKit WebGL","unMaskedVendor":"ARM","unMaskedRenderer":"Mali-G52 MC2","antialias":"Available","angle":"No","maxColorBuffers":1,"redBits":8,"greenBits":8,"blueBits":8,"alphaBits":8,"depthBits":24,"stencilBits":0,"maxRenderBufferSize":8192,"maxCombinedTextureImageUnits":96,"maxCubeMapTextureSize":4096,"maxFragmentUniformVectors":1024,"maxTextureImageUnits":16,"maxTextureSize":4096,"maxVaryingVectors":15,"maxVertexAttributes":16,"maxVertexTextureImageUnits":16,"maxVertexUniformVectors":1024,"maxAnisotropy":16,"extensions":["ANGLE_instanced_arrays","EXT_blend_minmax","EXT_disjoint_timer_query","EXT_sRGB","EXT_texture_filter_anisotropic","WEBKIT_EXT_texture_filter_anisotropic","OES_element_index_uint","OES_standard_derivatives","OES_vertex_array_object","WEBGL_compressed_texture_etc1","WEBGL_debug_renderer_info","WEBGL_debug_shaders","WEBGL_depth_texture","WEBKIT_WEBGL_depth_texture","WEBGL_lose_context","WEBKIT_WEBGL_lose_context"],"webgl2Status":"webgl2 and experimental-webgl2 contexts not available.","webgl2Functions":[]},"WebGLInfo2":[]};


Profile["name"] = Profile.device + ": " + Profile.OSName + " " + Profile.OSVersion + "/" + Profile.BrowserName + " " + Profile.BrowserVersion;

try {
    Languages = {
        "lang": "en",
        "langs": ["en"]
    };
} catch (e) {
    Languages = {};
}

TimeSettings = {
    "newTimeOffset": new Date().getTimezoneOffset(),
    "timeZoneV": "Europe/Berlin"
};
