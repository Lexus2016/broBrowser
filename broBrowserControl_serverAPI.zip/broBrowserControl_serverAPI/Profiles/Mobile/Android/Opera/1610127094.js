Profile = {"device":"Mobile","OSName":"Android","OSVersion":5,"BrowserName":"Opera","BrowserVersion":61,"global":{"isMobile":true},"navigator":{"vendorSub":"","productSub":"20030107","vendor":"Google Inc.","maxTouchPoints":5,"userActivation":{"hasBeenActive":false,"isActive":false},"connection":{"effectiveType":"4g","rtt":0,"downlink":9.4,"saveData":false,"type":"cellular","downlinkMax":42},"plugins":{"length":0},"mimeTypes":{"length":0},"hardwareConcurrency":4,"cookieEnabled":true,"appCodeName":"Mozilla","appName":"Netscape","appVersion":"5.0 (Linux; Android 5.0.1; GT-I9500) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Mobile Safari/537.36 OPR/61.1.3076.56625","platform":"Linux armv7l","product":"Gecko","userAgent":"Mozilla/5.0 (Linux; Android 5.0.1; GT-I9500) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Mobile Safari/537.36 OPR/61.1.3076.56625","onLine":true,"deviceMemory":2},"window":{"name":"description","status":"","closed":"","length":"","origin":"","innerWidth":360,"innerHeight":511,"scrollX":"","pageXOffset":"","scrollY":"","pageYOffset":"","screenX":"","screenY":"","outerWidth":360,"outerHeight":511,"devicePixelRatio":3,"screenLeft":"","screenTop":"","defaultStatus":"","defaultstatus":"","isSecureContext":true,"orientation":"","TEMPORARY":"","PERSISTENT":1},"screen":{"availWidth":360,"availHeight":640,"width":360,"height":640,"colorDepth":24,"pixelDepth":24,"availLeft":"","availTop":"","orientation":{"angle":0,"type":"portrait-primary"}},"WebGLInfo":{"contextName":"webgl","glVersion":"WebGL 1.0 (OpenGL ES 2.0 Chromium)","shadingLanguageVersion":"WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.0 Chromium)","vendor":"WebKit","renderer":"WebKit WebGL","unMaskedVendor":"Imagination Technologies","unMaskedRenderer":"PowerVR SGX 544MP","antialias":"Available","angle":"No","maxColorBuffers":1,"redBits":8,"greenBits":8,"blueBits":8,"alphaBits":8,"depthBits":24,"stencilBits":0,"maxRenderBufferSize":4096,"maxCombinedTextureImageUnits":8,"maxCubeMapTextureSize":4096,"maxFragmentUniformVectors":64,"maxTextureImageUnits":8,"maxTextureSize":4096,"maxVaryingVectors":8,"maxVertexAttributes":16,"maxVertexTextureImageUnits":8,"maxVertexUniformVectors":128,"maxAnisotropy":"n/a","extensions":["EXT_blend_minmax","EXT_shader_texture_lod","OES_element_index_uint","OES_standard_derivatives","OES_texture_float","OES_texture_half_float","OES_vertex_array_object","WEBGL_compressed_texture_etc1","WEBGL_compressed_texture_pvrtc","WEBKIT_WEBGL_compressed_texture_pvrtc","WEBGL_debug_renderer_info","WEBGL_debug_shaders","WEBGL_depth_texture","WEBKIT_WEBGL_depth_texture","WEBGL_lose_context","WEBKIT_WEBGL_lose_context"],"webgl2Status":"webgl2 and experimental-webgl2 contexts not available.","webgl2Functions":[]},"WebGLInfo2":[]};


Profile["name"] = Profile.device + ": " + Profile.OSName + " " + Profile.OSVersion + "/" + Profile.BrowserName + " " + Profile.BrowserVersion;

try {
    Languages = {
        "lang": "en",
        "langs": ["en"]
    };
} catch (e) {
    Languages = {};
}

TimeSettings = {
    "newTimeOffset": new Date().getTimezoneOffset(),
    "timeZoneV": "Europe/Berlin"
};
