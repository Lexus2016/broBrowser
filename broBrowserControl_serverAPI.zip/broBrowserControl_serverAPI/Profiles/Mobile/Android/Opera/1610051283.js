Profile = {"device":"Mobile","OSName":"Android","OSVersion":6,"BrowserName":"Opera","BrowserVersion":45,"global":{"isMobile":true},"navigator":{"vendorSub":"","productSub":"20030107","vendor":"Google Inc.","maxTouchPoints":5,"hardwareConcurrency":8,"appCodeName":"Mozilla","appName":"Netscape","appVersion":"5.0 (Linux; U; Android 6.0; S9 Build/MRA58K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/52.0.2743.98 Mobile Safari/537.36 OPR/45.0.2254.144855","platform":"Linux armv8l","product":"Gecko","userAgent":"Mozilla/5.0 (Linux; U; Android 6.0; S9 Build/MRA58K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/52.0.2743.98 Mobile Safari/537.36 OPR/45.0.2254.144855","onLine":true,"cookieEnabled":true,"plugins":{"length":0},"mimeTypes":{"length":0}},"window":{"webkitStorageInfo":{"TEMPORARY":0,"PERSISTENT":1},"orientation":"","isSecureContext":true,"defaultstatus":"","defaultStatus":"","screenTop":"","screenLeft":"","devicePixelRatio":3,"outerHeight":512,"outerWidth":360,"screenY":"","screenX":"","pageYOffset":"","scrollY":"","pageXOffset":"","scrollX":"","innerHeight":512,"innerWidth":360,"length":"","closed":"","status":"","name":"","TEMPORARY":"","PERSISTENT":1},"screen":{"availWidth":360,"availHeight":640,"width":360,"height":640,"colorDepth":32,"pixelDepth":32,"availLeft":"","availTop":"","orientation":{"angle":0,"type":"portrait-primary"}},"WebGLInfo":{"contextName":"webgl","glVersion":"WebGL 1.0 (OpenGL ES 2.0 Chromium)","shadingLanguageVersion":"WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.0 Chromium)","vendor":"WebKit","renderer":"WebKit WebGL","unMaskedVendor":"ARM","unMaskedRenderer":"Mali-T860","antialias":"Available","angle":"No","maxColorBuffers":1,"redBits":8,"greenBits":8,"blueBits":8,"alphaBits":8,"depthBits":24,"stencilBits":0,"maxRenderBufferSize":8192,"maxCombinedTextureImageUnits":96,"maxCubeMapTextureSize":4096,"maxFragmentUniformVectors":1024,"maxTextureImageUnits":16,"maxTextureSize":4096,"maxVaryingVectors":15,"maxVertexAttributes":16,"maxVertexTextureImageUnits":16,"maxVertexUniformVectors":1024,"maxAnisotropy":"n/a","extensions":["ANGLE_instanced_arrays","EXT_blend_minmax","EXT_disjoint_timer_query","EXT_sRGB","OES_element_index_uint","OES_standard_derivatives","OES_vertex_array_object","WEBGL_compressed_texture_etc1","WEBGL_debug_renderer_info","WEBGL_debug_shaders","WEBGL_depth_texture","WEBKIT_WEBGL_depth_texture","WEBGL_lose_context","WEBKIT_WEBGL_lose_context"],"webgl2Status":"webgl2 and experimental-webgl2 contexts not available.","webgl2Functions":[]},"WebGLInfo2":[]};


Profile["name"] = Profile.device + ": " + Profile.OSName + " " + Profile.OSVersion + "/" + Profile.BrowserName + " " + Profile.BrowserVersion;

try {
    Languages = {
        "lang": "en",
        "langs": ["en"]
    };
} catch (e) {
    Languages = {};
}

TimeSettings = {
    "newTimeOffset": new Date().getTimezoneOffset(),
    "timeZoneV": "Europe/Berlin"
};
