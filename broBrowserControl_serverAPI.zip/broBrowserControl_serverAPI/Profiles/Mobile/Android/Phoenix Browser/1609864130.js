Profile = {"device":"Mobile","OSName":"Android","OSVersion":8.1,"BrowserName":"Phoenix Browser","BrowserVersion":6.3,"global":{"isMobile":true},"navigator":{"vendorSub":"","productSub":"20030107","vendor":"Google Inc.","maxTouchPoints":5,"userActivation":{"hasBeenActive":false,"isActive":false},"connection":{"effectiveType":"4g","rtt":0,"downlink":9.4,"saveData":false,"type":"cellular","downlinkMax":42},"plugins":{"length":0},"mimeTypes":{"length":0},"hardwareConcurrency":4,"cookieEnabled":true,"appCodeName":"Mozilla","appName":"Netscape","appVersion":"5.0 (Linux; U; Android 8.1.0; en-us; TECNO B1p Build/O11019) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Mobile Safari/537.36 PHX/6.3","platform":"Linux armv7l","product":"Gecko","userAgent":"Mozilla/5.0 (Linux; U; Android 8.1.0; en-us; TECNO B1p Build/O11019) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Mobile Safari/537.36 PHX/6.3","onLine":true,"deviceMemory":1},"window":{"name":"","status":"","closed":"","length":"","origin":"","innerWidth":320,"innerHeight":467,"scrollX":"","pageXOffset":"","scrollY":"","pageYOffset":"","screenX":"","screenY":"","outerWidth":320,"outerHeight":467,"devicePixelRatio":1.5,"screenLeft":"","screenTop":"","defaultStatus":"","defaultstatus":"","isSecureContext":true,"orientation":"","crossOriginIsolated":"","TEMPORARY":"","PERSISTENT":1},"screen":{"availWidth":320,"availHeight":640,"width":320,"height":640,"colorDepth":24,"pixelDepth":24,"availLeft":"","availTop":"","orientation":{"angle":0,"type":"portrait-primary"}},"WebGLInfo":{"contextName":"webgl","glVersion":"WebGL 1.0 (OpenGL ES 2.0 Chromium)","shadingLanguageVersion":"WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.0 Chromium)","vendor":"WebKit","renderer":"WebKit WebGL","unMaskedVendor":"ARM","unMaskedRenderer":"Mali-400 MP","antialias":"Available","angle":"No","maxColorBuffers":1,"redBits":8,"greenBits":8,"blueBits":8,"alphaBits":8,"depthBits":24,"stencilBits":0,"maxRenderBufferSize":4096,"maxCombinedTextureImageUnits":8,"maxCubeMapTextureSize":4096,"maxFragmentUniformVectors":256,"maxTextureImageUnits":8,"maxTextureSize":4096,"maxVaryingVectors":12,"maxVertexAttributes":16,"maxVertexTextureImageUnits":0,"maxVertexUniformVectors":256,"maxAnisotropy":"n/a","extensions":["EXT_blend_minmax","EXT_shader_texture_lod","OES_standard_derivatives","OES_vertex_array_object","WEBGL_compressed_texture_etc1","WEBGL_debug_renderer_info","WEBGL_debug_shaders","WEBGL_depth_texture","WEBKIT_WEBGL_depth_texture","WEBGL_lose_context","WEBKIT_WEBGL_lose_context"],"webgl2Status":"webgl2 and experimental-webgl2 contexts not available.","webgl2Functions":[]},"WebGLInfo2":[]};


Profile["name"] = Profile.device + ": " + Profile.OSName + " " + Profile.OSVersion + "/" + Profile.BrowserName + " " + Profile.BrowserVersion;

try {
    Languages = {
        "lang": "en",
        "langs": ["en"]
    };
} catch (e) {
    Languages = {};
}

TimeSettings = {
    "newTimeOffset": new Date().getTimezoneOffset(),
    "timeZoneV": "Europe/Berlin"
};
