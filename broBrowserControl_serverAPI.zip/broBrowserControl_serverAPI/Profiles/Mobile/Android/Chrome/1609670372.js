Profile = {"device":"Mobile","OSName":"Android","OSVersion":6,"BrowserName":"Chrome","BrowserVersion":86,"global":{"isMobile":true},"navigator":{"vendorSub":"","productSub":"20030107","vendor":"Google Inc.","maxTouchPoints":5,"userActivation":{"hasBeenActive":false,"isActive":false},"connection":{"effectiveType":"4g","rtt":250,"downlink":3.05,"saveData":true,"type":"cellular","downlinkMax":100},"plugins":{"length":0},"mimeTypes":{"length":0},"hardwareConcurrency":4,"cookieEnabled":true,"appCodeName":"Mozilla","appName":"Netscape","appVersion":"5.0 (Linux; Android 6.0.1; vivo 1610) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.110 Mobile Safari/537.36","platform":"Linux armv7l","product":"Gecko","userAgent":"Mozilla/5.0 (Linux; Android 6.0.1; vivo 1610) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.110 Mobile Safari/537.36","onLine":true,"deviceMemory":2},"window":{"name":"0.4952801353692944","status":"","closed":"","length":"","origin":"","innerWidth":980,"innerHeight":1524,"scrollX":"","pageXOffset":"","scrollY":"","pageYOffset":"","screenX":"","screenY":"","outerWidth":360,"outerHeight":560,"devicePixelRatio":2,"screenLeft":"","screenTop":"","defaultStatus":"","defaultstatus":"","isSecureContext":true,"orientation":"","TEMPORARY":"","PERSISTENT":1},"screen":{"availWidth":360,"availHeight":640,"width":360,"height":640,"colorDepth":24,"pixelDepth":24,"availLeft":"","availTop":"","orientation":{"angle":0,"type":"portrait-primary"}},"WebGLInfo":{"contextName":"webgl","glVersion":"WebGL 1.0 (OpenGL ES 2.0 Chromium)","shadingLanguageVersion":"WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.0 Chromium)","vendor":"WebKit","renderer":"WebKit WebGL","unMaskedVendor":"Qualcomm","unMaskedRenderer":"Adreno (TM) 308","antialias":"Available","angle":"No","maxColorBuffers":1,"redBits":8,"greenBits":8,"blueBits":8,"alphaBits":8,"depthBits":24,"stencilBits":0,"maxRenderBufferSize":4096,"maxCombinedTextureImageUnits":32,"maxCubeMapTextureSize":4096,"maxFragmentUniformVectors":224,"maxTextureImageUnits":16,"maxTextureSize":4096,"maxVaryingVectors":16,"maxVertexAttributes":16,"maxVertexTextureImageUnits":16,"maxVertexUniformVectors":256,"maxAnisotropy":16,"extensions":["ANGLE_instanced_arrays","EXT_blend_minmax","EXT_color_buffer_half_float","EXT_texture_filter_anisotropic","WEBKIT_EXT_texture_filter_anisotropic","EXT_sRGB","OES_element_index_uint","OES_fbo_render_mipmap","OES_standard_derivatives","OES_texture_float","OES_texture_half_float","OES_texture_half_float_linear","OES_vertex_array_object","WEBGL_color_buffer_float","WEBGL_compressed_texture_etc","WEBGL_compressed_texture_etc1","WEBGL_debug_renderer_info","WEBGL_debug_shaders","WEBGL_lose_context","WEBKIT_WEBGL_lose_context","WEBGL_multi_draw"],"webgl2Status":"webgl2 and experimental-webgl2 contexts not available.","webgl2Functions":[]},"WebGLInfo2":[]};


Profile["name"] = Profile.device + ": " + Profile.OSName + " " + Profile.OSVersion + "/" + Profile.BrowserName + " " + Profile.BrowserVersion;

try {
    Languages = {
        "lang": "en",
        "langs": ["en"]
    };
} catch (e) {
    Languages = {};
}

TimeSettings = {
    "newTimeOffset": new Date().getTimezoneOffset(),
    "timeZoneV": "Europe/Berlin"
};
