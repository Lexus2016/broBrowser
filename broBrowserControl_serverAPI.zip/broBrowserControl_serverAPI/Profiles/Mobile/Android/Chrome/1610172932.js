Profile = {"device":"Mobile","OSName":"Android","OSVersion":4.4,"BrowserName":"Chrome","BrowserVersion":81,"global":{"isMobile":true},"navigator":{"vendorSub":"","productSub":"20030107","vendor":"Google Inc.","maxTouchPoints":5,"hardwareConcurrency":4,"cookieEnabled":true,"appCodeName":"Mozilla","appName":"Netscape","appVersion":"5.0 (Linux; Android 4.4.2; SM-T231) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36","platform":"Linux armv7l","product":"Gecko","userAgent":"Mozilla/5.0 (Linux; Android 4.4.2; SM-T231) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36","onLine":true,"connection":{"effectiveType":"3g","rtt":750,"downlink":1.3,"saveData":true,"downlinkMax":42,"type":"cellular"},"plugins":{"length":0},"mimeTypes":{"length":0},"userActivation":{"hasBeenActive":false,"isActive":false},"deviceMemory":1},"window":{"length":"","closed":"","name":"","status":"","origin":"","innerWidth":602,"innerHeight":841,"scrollX":"","pageXOffset":"","scrollY":"","pageYOffset":"","screenX":"","screenY":"","outerWidth":601,"outerHeight":841,"devicePixelRatio":1.3312500715255737,"screenLeft":"","screenTop":"","defaultStatus":"","defaultstatus":"","isSecureContext":true,"orientation":"","TEMPORARY":"","PERSISTENT":1},"screen":{"availWidth":601,"availHeight":962,"width":601,"height":962,"colorDepth":24,"pixelDepth":24,"availLeft":"","availTop":"","orientation":{"angle":0,"type":"portrait-primary"}},"WebGLInfo":{"contextName":"webgl","glVersion":"WebGL 1.0 (OpenGL ES 2.0 Chromium)","shadingLanguageVersion":"WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.0 Chromium)","vendor":"WebKit","renderer":"WebKit WebGL","unMaskedVendor":"Vivante Corporation","unMaskedRenderer":"Vivante GC1000","antialias":"Available","angle":"No","maxColorBuffers":1,"redBits":8,"greenBits":8,"blueBits":8,"alphaBits":8,"depthBits":24,"stencilBits":0,"maxRenderBufferSize":8192,"maxCombinedTextureImageUnits":12,"maxCubeMapTextureSize":4096,"maxFragmentUniformVectors":64,"maxTextureImageUnits":8,"maxTextureSize":4096,"maxVaryingVectors":8,"maxVertexAttributes":10,"maxVertexTextureImageUnits":4,"maxVertexUniformVectors":256,"maxAnisotropy":"n/a","extensions":["EXT_blend_minmax","EXT_frag_depth","OES_element_index_uint","OES_fbo_render_mipmap","OES_vertex_array_object","WEBGL_compressed_texture_etc1","WEBGL_compressed_texture_s3tc","WEBKIT_WEBGL_compressed_texture_s3tc","WEBGL_debug_renderer_info","WEBGL_debug_shaders","WEBGL_depth_texture","WEBKIT_WEBGL_depth_texture","WEBGL_lose_context","WEBKIT_WEBGL_lose_context"],"webgl2Status":"webgl2 and experimental-webgl2 contexts not available.","webgl2Functions":[]},"WebGLInfo2":[]};


Profile["name"] = Profile.device + ": " + Profile.OSName + " " + Profile.OSVersion + "/" + Profile.BrowserName + " " + Profile.BrowserVersion;

try {
    Languages = {
        "lang": "en",
        "langs": ["en"]
    };
} catch (e) {
    Languages = {};
}

TimeSettings = {
    "newTimeOffset": new Date().getTimezoneOffset(),
    "timeZoneV": "Europe/Berlin"
};
