const isDebug = false;
const checkMachineID = false;

const {
    verifyLogin,
    loadConfig,
    saveConfig,
    changePassword,
    slash
} = require("./Lib/config");

const shell = require('electron').shell;

const {
    app,
    BrowserWindow,
    Menu,
    dialog,
    ipcMain
} = require('electron');

const {
    machineIdSync
} = require('node-machine-id');

const fs = require("fs");
const path = require('path');
const puppeteer = require('puppeteer-core');

const currentAppVersion = app.getVersion();
const repositoryUrl = "https://api.github.com/repos/Lexus2016/broBrowser"; //process.env.REPOSITORY;

// Модули для управления приложением и создания окна
const getChromePath = require('./Lib/chrome-path');
const startChrome = require("./Lib/chrome-ruuner");

const {
    getProfiles,
    setProfiles,
    getProfileByID,
    loadProfile,
    saveProfile,
    deleteProfile,
    deleteDevice
} = require('./Lib/get-profiles');

const checkUpdateAndGetDownloadUrl = require('./Lib/updater');

const openAboutWindow = require('about-window').default;

const {
    ValidateToken
} = require('./Lib/api');

const Cache = new Map();

let mainWindow = null;

let serverApiConfig = {
    apiUrl: 'https://api.brobrowser.io'
};

let config = {
    deviceID: machineIdSync(true),
    userName: '034b5f8c3c6c515b63cc17ef8c402c6016349b70d343d191fbbca5d1211625be', // admin
    userPassword: '4764a48f5c9388cc576e38c597bafaab357f51332523b0a41442d60fca85a0ea', // admin10
    apiKey: 'thisistesttokenfortesting11',
    license: 'licenseKeyForDemo',
    role: 'admin'
};

const workPath = slash(app.getPath('userData'));
const configFile = slash(workPath + '/general.conf');
const profileFile = slash(workPath + '/' + config.userName + '_profile.conf');

if (!fs.existsSync(configFile)) {
    saveConfig(configFile, config);
} else {
    config = loadConfig(configFile);
}

app.setName('broBrowser');

let chromePath = slash(getChromePath(dialog));

// Run App
function createWindow() {
    // Создаем окно браузера.
    mainWindow = new BrowserWindow({
        width: 600,
        height: 600,
        frame: true,
        title: 'broBrowser',
        // titleBarStyle: 'hidden',
        // transparent: true,
        webPreferences: {
            devTools: isDebug, // debug -> enable DevTools
            nodeIntegration: true,
            contextIsolation: false,
            enableRemoteModule: true
        }
    });

    if (!isDebug) {
        mainWindow.setResizable(true);
        mainWindow.removeMenu();
        Menu.setApplicationMenu(null);
        mainWindow.webContents.on("devtools-opened", () => {
            mainWindow.webContents.closeDevTools();
        });
    } else {
        // Отображаем средства разработчика.
        mainWindow.webContents.openDevTools();
    }

    const startUrl = process.env.ELECTRON_START_URL || slash(`file://${path.join(__dirname, '../build/index.html')}`);

    if (fs.existsSync(profileFile)) {
        loadProfile(profileFile);
    } else {
        saveProfile(profileFile);
    }

    mainWindow.loadURL(startUrl).then(() => {
        try {
            checkUpdateAndGetDownloadUrl(shell, dialog, currentAppVersion, repositoryUrl);
        } catch (err) {
            dialog.showErrorBox('ERROR', err);
        }

        if (checkMachineID) {
            ValidateToken(serverApiConfig.apiUrl, config.apiKey, config.deviceID, function (isValidToken) {
                if (isValidToken === '99') {
                    dialog.showErrorBox("License error", "License server not found! Check your internet access.");
                    app.quit();
                } else if (config.deviceID !== machineIdSync(true) || isValidToken !== '1') {
                    dialog.showErrorBox("License error", "Hacking attempt detected!");
                    app.quit();
                }
            });
        }
    });
};

// Если запущено уже приложение, то новое не запускать
app.on('second-instance', () => {
    // Someone tried to run a second instance, we should focus our window.
    if (mainWindow) {
        if (mainWindow.isMinimized()) {
            mainWindow.restore();
        }
        mainWindow.focus();
    }
});

// Этот метод вызывается когда приложение инициализируется
// и будет готово для создания окон.
// Некоторые API могут использоваться только после возникновения этого события.
app.whenReady().then(() => {
    createWindow();

    app.on('activate', function () {
        // На MacOS обычно пересоздают окно в приложении,
        // после того, как на иконку в доке нажали и других открытых окон нету.
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });

    const application = {
        label: 'About...',
        submenu: [{
            label: 'About broBrowser',
            click: () =>
                openAboutWindow({
                    icon_path: slash(path.join(__dirname, 'icon.png')),
                    copyright: 'Copyright (c) 2021 RAWIRA LTD',
                    package_json_dir: slash(__dirname),
                    homepage: 'https://brobrowser.io/',
                    open_devtools: isDebug,
                    // description: 'Free version',
                    license: 'For Testing Only'
                }),
        }]
    };

    const edit = {
        label: 'Edit',
        submenu: [{
            label: 'Undo',
            accelerator: 'CmdOrCtrl+Z',
            role: 'undo',
        }, {
            label: 'Redo',
            accelerator: 'Shift+CmdOrCtrl+Z',
            role: 'redo',
        }, {
            type: 'separator',
        }, {
            label: 'Cut',
            accelerator: 'CmdOrCtrl+X',
            role: 'cut',
        }, {
            label: 'Copy',
            accelerator: 'CmdOrCtrl+C',
            role: 'copy',
        }, {
            label: 'Paste',
            accelerator: 'CmdOrCtrl+V',
            role: 'paste',
        }, {
            label: 'Select All',
            accelerator: 'CmdOrCtrl+A',
            role: 'selectAll',
        }, {
            type: 'separator',
        }, {
            // role: 'quit',
            label: 'Quit',
            accelerator: 'CmdOrCtrl+Q',
            click: async () => {
                await cleanUP();
                app.quit();
            }
        }]
    };

    const template = [
        application,
        edit
    ]

    Menu.setApplicationMenu(Menu.buildFromTemplate(template))

});

//
// IPC callbacks
//
ipcMain.on('get-validate-login', (event, param) => {
    let isLogin = verifyLogin(param.login, param.password, config);
    mainWindow.webContents.send('get-validate-login', isLogin);
    if (isLogin) {
        mainWindow.setPosition(20, 20, true);
        mainWindow.setContentSize(1193, 670, true);
    }
});

ipcMain.on('get-change-password', (event, password) => {
    changePassword(configFile, password, config);
});

ipcMain.on('get-data', () => {
    mainWindow.webContents.send('get-profiles', getProfiles());
});

// Get event from ReactApp (button "Start Browser")
ipcMain.on('start-browser', async (event, profileID) => {

    const profilePath = slash(workPath + '/Profile/' + profileID);
    // const startUrlChrome = 'http://whoer.net/en/?tz=' + Math.random()*Math.random();
    // const startUrlChrome = 'https://browserleaks.com/canvas';
    const startUrlChrome = '';

    if (!fs.existsSync(workPath + '/Profile/')) {
        fs.mkdirSync(workPath + '/Profile/');
    }

    if (!fs.existsSync(profilePath)) {
        fs.mkdirSync(profilePath);
    }

    const profile = getProfileByID(profileID);

    const [browserURL, broProxyChildProcess, chromeChildProcess] = await startChrome(dialog, chromePath, profilePath, profile, startUrlChrome, isDebug);
    await Cache.set(profileID, [browserURL, broProxyChildProcess, chromeChildProcess]);

    event.returnValue = 'ok'
});

ipcMain.on('run-chrome-script', (event, profileID, script) => {

    profileID = parseInt(profileID, 10);
    let profile = getProfileByID(profileID);
    profile.script = script;

    const ProfileArr = getProfiles();

    let resultUpdates = ProfileArr.filter(obj => {
        return (obj.id !== profileID);
    });

    resultUpdates.push(profile);

    setProfiles(resultUpdates);
    saveProfile(profileFile);

    runRemoteControl(Cache.get(profileID), profile.script);

    mainWindow.webContents.send('get-profiles', getProfiles());

    event.returnValue = 'ok'
});

ipcMain.on('get-chrome-path', (event) => {

    if (chromePath === '') {
        let file = dialog.showOpenDialogSync(mainWindow, {
            title: 'Specify the path to the Google Chrome browser launch file',
            properties: ['openFile'],
            filters: [{
                name: 'All Files',
                extensions: ['*']
            }]
        });

        if (typeof file === 'undefined' || typeof file[0] === 'undefined') {
            dialog.showErrorBox("Canceled by user", "You haven't selected the Google Chrome app");
            event.returnValue = '';
        } else {
            chromePath = file[0];
            event.returnValue = file[0];
        }
    } else {
        event.returnValue = chromePath;
    }
});

ipcMain.on('delete-profile', (event, profileID) => {

    const ProfileArr = getProfiles();
    const result = ProfileArr.filter(obj => {
        return (obj.id !== profileID);
    });

    setProfiles(result);
    saveProfile(profileFile);

    const profilePath = slash(workPath + '/Profile/' + profileID + '/');
    deleteProfile(profilePath);

    mainWindow.webContents.send('get-profiles', getProfiles());

});

ipcMain.on('add-profile', (event, profile) => {

    if (checkMachineID) {
        ValidateToken(serverApiConfig.apiUrl, config.apiKey, config.deviceID, function (isValidToken) {
            if (isValidToken === '99') {
                dialog.showErrorBox("License error", "License server not found! Check your internet access.");
                app.quit();
            } else if (config.deviceID !== machineIdSync(true) || isValidToken !== '1') {
                dialog.showErrorBox("License error", "Hacking attempt detected!");
                app.quit();
            }
        });
    }

    let profileID = Math.floor(new Date().getTime() + (Math.random() * (1000 - 1) + 1000));

    let result = {},
        resultDelete;

    const ProfileArr = getProfiles();

    if (profile.id && profile.id !== '' && typeof profile.id !== 'undefined') {
        profileID = parseInt(profile.id, 10);

        resultDelete = ProfileArr.filter(obj => {
            return (obj.id !== profileID);
        });

        if (!resultDelete) {
            resultDelete = [];
        }
    } else {
        resultDelete = ProfileArr;
    }

    result.id = profileID;
    result.name = profile.name;
    result.os = profile.os;
    result.browser = profile.browser;
    result.device = profile.device;
    result.proxy = profile.proxy;
    result.proxyProtocol = profile.proxyProtocol;
    result.proxyIP = profile.proxyIP;
    result.proxyPort = profile.proxyPort;
    result.proxyLogin = profile.proxyLogin;
    result.proxyPassword = profile.proxyPassword;
    result.script = profile.script;

    resultDelete.push(result);

    const profilePath = slash(workPath + '/Profile/' + profileID + '/');
    deleteDevice(profilePath);

    setProfiles(resultDelete);
    saveProfile(profileFile);

    mainWindow.webContents.send('get-profiles', getProfiles());
});

// =============
// IPC callbacks
// =============

async function cleanUP() {
    try {
        await Cache.forEach(function (process) {
            try {
                process[1].kill('SIGINT'); // Kill broProxy
            } catch (e) {
            }

            try {
                (async () => {
                    const browser = await puppeteer.connect({
                        browserURL: process[0],
                        defaultViewport: {
                            width: 0,
                            height: 0
                        }
                    });

                    await browser.close();
                    await puppeteer.disconnect();
                })();
            } catch (e) {
            }

            try {
                process[2].kill('SIGINT'); // Kill Chrome
            } catch (e) {
            }

            try {
                window.removeAllListeners('error');
                window.removeAllListeners('close');
            } catch (e) {
            }
        });
    } catch (e) {
    }

    return Promise.resolve();
}

// Quit events (Electron)
// app.once('window-all-closed', () => {
//     cleanUP(Cache);
//     setTimeout(() => app.quit(), 1500);
// });
//
// app.once('before-quit', () => {
//     cleanUP(Cache);
//     try {
//         window.removeAllListeners('error');
//         window.removeAllListeners('close');
//     } catch (e) {
//     }
// });
// app.once('will-quit', () => {
//     cleanUP(Cache);
// });

// ###########################################
// Run JS Script on Browser (using puppeteer)
// ###########################################
function runRemoteControl(BrowserInfo, script) {
    if (BrowserInfo === undefined || BrowserInfo[0] === undefined || BrowserInfo[0] === '' || BrowserInfo[0] === null) {
        dialog.showErrorBox('Error!', 'Browser connection error! Perhaps it is not running?');
    } else {
        (async () => {
            let browser = await puppeteer.connect({
                browserURL: BrowserInfo[0],
                slowMo: 500,
                defaultViewport: {
                    width: 0,
                    height: 0
                }
            });

            for (let i = 0; i < 10; i++) {
                if (browser === null || browser === undefined) {
                    browser = await puppeteer.connect({
                        browserURL: BrowserInfo[0],
                        slowMo: 500,
                        defaultViewport: {
                            width: 0,
                            height: 0
                        }
                    });
                } else {
                    break;
                }
            }

            try {
                eval("(async () => {" + script + "})();")
            } catch (e) {
                if (e instanceof SyntaxError) {
                    dialog.showErrorBox('Error in script', e.message);
                }
            }

            await puppeteer.disconnect();
        })();
    }
}