const {
    override,
    disableEsLint,
    addDecoratorsLegacy,
    fixBabelImports,
} = require("customize-cra");

const MonacoWebpackPlugin = require('monaco-editor-webpack-plugin');

module.exports = override(
    disableEsLint(),
    addDecoratorsLegacy(),
    override(),
    fixBabelImports("react-app-rewire-mobx", {
        libraryDirectory: "",
        camel2DashComponentName: false
    }),
    function override(config, env) {
        config.plugins.push(new MonacoWebpackPlugin({
            languages: ['json', 'javascript']
        }));
        return config;
    }
);