import React from 'react';

// React-dom
import ReactDOM from 'react-dom';
import {
    HashRouter as Router
} from "react-router-dom";

import {Provider} from 'mobx-react';

import './index.css';
import 'antd/dist/antd.css';
import App from './App';

import mainStore from './store/mobxStore';

const store = {
    mainStore
};

ReactDOM.render(
    <Provider {...store}>
        <Router>
            <App/>
        </Router>
    </Provider>,
    document.getElementById('root')
);
