import {action, computed, observable} from 'mobx';

class mainStore {

    @observable
    store = observable.map({});

    @action
    set = action((key, value) => {
        console.log('MOBX: SET');
        this.store.set(key, value);
    });

    @action
    delete = action((key, value) => {
        console.log('MOBX: DELETE');
        this.store.delete(key);
    });

    constructor() {
        console.log('MOBX: CONSTRUCTOR');
        this.set("showLoader", false);
        this.set("userUid", null);
//    this.set("date", getCurrentDate());
    }

    @computed
    get = (key) => {
        console.log('MOBX: GET');
        return this.store.get(key);
    };

    @action
    showLoader = () => {
        console.log('MOBX: SHOW_LOADER');
        this.set("showLoader", true);

        setTimeout(() => {
            this.set("showLoader", false);
        }, 900)
    }

    @action
    showLoaderInStartBrowser = () => {
        console.log('MOBX: SHOW_LOADER');
        this.set("showLoader", true);

        setTimeout(() => {
            this.set("showLoader", false);
        }, 3000)
    }
}

export default new mainStore();
