import React from 'react';

import ProfileLogo from '../../profile.png';
import {Card, Modal} from 'antd';
import {DeleteOutlined, EditOutlined, PlayCircleFilled, CodeOutlined} from '@ant-design/icons';
import {withRouter} from "react-router";
import Meta from "antd/es/card/Meta";
import Avatar from "antd/es/avatar/avatar";
import {inject, observer} from "mobx-react";

import MonacoEditor from 'react-monaco-editor';

const electron = window.require('electron');
const ipcRenderer = electron.ipcRenderer;

@inject('mainStore')
@observer
class ProfileCard extends React.Component {
    state = {
        isModalDeleteVisible: false,
        isModalScriptVisible: false,
        script: ''
    };

    jsScript = "// Use the 'browser' object to control the browser\n" +
        "// See: https://pptr.dev/#?product=Puppeteer&version=v10.1.0&show=api-class-browser\n" +
        "// Example:\n" +
        "const page = await browser.newPage();\n" +
        "await page.goto('https://booking.com');\n" +
        "await page.type('#ss', 'Berlin');\n" +
        "await page.click('.sb-searchbox__button');\n" +
        "await page.waitForSelector('#hotellist_inner');\n" +
        "const hotels = await page.$$eval('span.sr-hotel__name', anchors => {\n" +
        "   return anchors.map(anchor => anchor.textContent.trim()).slice(0, 10);\n" +
        "});" +
        "await page.evaluate(() => {\n" +
        "  alert('Job Done!');\n" +
        "});";

    componentDidMount() {
        const {profile} = this.props;

        if (profile.script === undefined || profile.script === '') {
            this.setState({
                script: this.jsScript,
            });
        } else {
            this.setState({
                script: profile.script,
            });
        }
    }

    handlerStartBrowser = (id) => {
        const {mainStore} = this.props;
        ipcRenderer.send('start-browser', id);
        mainStore.showLoaderInStartBrowser();
    }

    handlerEditProfile = (e, id) => {
        e.stopPropagation();

        const {profile, mainStore} = this.props;
        mainStore.set('isFirstShow', false);

        this.props.history.push({
            pathname: "/addProfile/" + id,
            state: {profile: profile}
        });
    }

    handlerDeleteProfile = () => {
        this.setState({
            isModalDeleteVisible: true,
        });
    }

    handlerEditScript = () => {
        this.setState({
            isModalScriptVisible: true,
        });
    }

    handlerStartJSScript = (id) => {
        if (this.state.script !== '') {
            ipcRenderer.send('run-chrome-script', id, this.state.script);

            this.setState({
                isModalScriptVisible: false,
            });
        }
    }

    // Delete Profile - OK
    deleteProfile = (id) => {
        this.setState({
            isModalDeleteVisible: false,
        });

        ipcRenderer.send('delete-profile', id);
    }

    // Delete Profile - Cancel
    handleModalCancel = () => {
        this.setState({
            isModalDeleteVisible: false,
        });
    }

    handleModalScriptCancel = () => {
        this.setState({
            isModalScriptVisible: false,
        });
    }

    editorDidMount(editor) {
        console.log('editorDidMount', editor);
        editor.focus();
    }

    render() {

        const {profile} = this.props;

        const options = {
            selectOnLineNumbers: true
        };

        return (
            <>
                <Modal
                    title="Delete profile"
                    visible={this.state.isModalDeleteVisible}
                    onOk={() => this.deleteProfile(profile.id)}
                    onCancel={this.handleModalCancel}
                >
                    Do you want to delete profile <strong>{profile.name}</strong> ?
                </Modal>
                <Modal
                    title="Run script"
                    visible={this.state.isModalScriptVisible}
                    okText="Run script"
                    onOk={() => this.handlerStartJSScript(profile.id)}
                    onCancel={this.handleModalScriptCancel}
                    centered={true}
                    width={900}
                >
                    <MonacoEditor
                        height="450"
                        language="javascript"
                        theme="vs-dark"
                        value={this.state.script}
                        options={options}
                        onChange={script => this.setState({script})}
                        editorDidMount={this.editorDidMount}
                    />
                </Modal>
                <Card
                    key={profile.id}
                    // title={profile.name}
                    size="small"
                    style={{textAlign: 'center', width: 213}}
                    bodyStyle={{backgroundColor: 'white'}}
                    headStyle={{backgroundColor: 'gray', color: 'white', fontWeight: 'bold'}}
                    bordered={true}
                    hoverable
                    // onClick={(event) => this.handlerEditProfile(event, profile.id)}
                    actions={[
                        <DeleteOutlined key="delete"
                                        onClick={() => this.handlerDeleteProfile()}/>,
                        <EditOutlined key="edit" onClick={(event) => this.handlerEditProfile(event, profile.id)}/>,
                        <CodeOutlined key="execjs" onClick={() => this.handlerEditScript()}/>,
                        <PlayCircleFilled key="run" style={{fontSize: '24px', color: '#08c'}}
                                          onClick={() => this.handlerStartBrowser(profile.id)}/>
                    ]}
                >
                    <Meta
                        avatar={
                            <Avatar src={ProfileLogo}/>
                        }
                        style={{textAlign: 'center', height: 50, fontWeight: 700}}
                        title=""
                        description={profile.name}
                    />
                    <hr/>
                    {profile.os ? (
                        <p><strong>{profile.os} / {profile.browser}</strong></p>
                    ) : (
                        <p><strong>No emulation</strong></p>
                    )}
                    <hr/>
                    {profile.device ? (
                        <p><strong>{profile.device}</strong></p>
                    ) : (
                        <p><strong>No emulation</strong></p>
                    )}
                    <hr/>
                    {!profile.proxy || profile.proxy === 'None/VPN' ? (
                        <p><strong>No proxy</strong></p>
                    ) : (
                        <p><strong>{profile.proxyProtocol.toUpperCase()}</strong></p>
                    )}
                </Card>
            </>
        );
    }
}

export default withRouter(ProfileCard);