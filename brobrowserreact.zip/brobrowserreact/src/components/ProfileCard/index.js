import ProfileCard from './ProfileCard.js';

export default ProfileCard;