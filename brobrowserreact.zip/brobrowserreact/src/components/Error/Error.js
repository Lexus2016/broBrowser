import React, {Component} from "react";
// import s from "./Error.module.scss";

import {notification} from 'antd';

class Error extends Component {
    render() {
        const {message} = this.props;

        if (message.length > 0) {
            notification.error({
                message: 'Error',
                description: message,
                duration: 3,
                style: {
                    width: 350,
                }
            });
        }

        return(<></>);
    }
}

export default Error;