import SpinLoader from './SpinLoader';

export default SpinLoader;