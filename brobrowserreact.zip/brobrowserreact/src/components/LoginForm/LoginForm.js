import React, {Component} from 'react';
import {Button, Form, Image, Input} from 'antd';
import {inject, observer} from 'mobx-react';

import Error from '../Error/Error';

import Logo from '../../brobrowser.png';
import s from './LoginForm.module.scss';

const electron = window.require('electron');
const ipcRenderer = electron.ipcRenderer;

@inject('mainStore')
@observer
class LoginForm extends Component {
    state = {
        errorMsg: '',
    };

    inputRef = React.createRef();

    componentDidMount() {
        ipcRenderer.on('get-validate-login', (event, result) => {
            if(result) {
                const {mainStore} = this.props;
                mainStore.set('isLogin', true);
                mainStore.showLoader();
            } else {
                this.handlerSetErrorMsg('Forbidden!');
            }
        });

        this.inputRef.current.focus({
            cursor: 'start',
        });
    }

    componentWillUnmount() {
        this.setState({
            errorMsg: '',
        });

        clearTimeout(this.errTimeout);
    }

    // ввели логин и пароль - проверяем
    onFinish = ({login, password}) => {
        ipcRenderer.send('get-validate-login', {login, password});
    };

    // Выводим ошибку
    handlerSetErrorMsg = (error) => {
        this.setState({
            errorMsg: error,
        });

        this.errTimeout = setTimeout(() => {
            this.setState({
                errorMsg: '',
            });
        }, 5000);
    };

    // Отрисовка формы
    renderForm = () => {
        const layout = {
            labelCol: {span: 5},
            wrapperCol: {span: 18},
        };
        const tailLayout = {
            wrapperCol: {offset: 5},
        };

        const validateMessages = {
            // eslint-disable-next-line no-template-curly-in-string
            required: '${label} - required field!',
        };

        return (
            <div>
                <Form
                    {...layout}
                    name="basic"
                    initialValues={{remember: true}}
                    onFinish={this.onFinish}
                    validateMessages={validateMessages}
                >
                    <Form.Item
                        label="Login"
                        name="login"
                        rules={[{required: true, message: 'Enter your Login'}]}
                    >
                        <Input
                            ref={this.inputRef}
                        />
                    </Form.Item>

                    <Form.Item
                        label="Password"
                        name="password"
                        rules={[{required: true, message: 'Enter your Password'}]}
                    >
                        <Input.Password
                            visibilityToggle={true}
                        />
                    </Form.Item>

                    <Form.Item {...tailLayout}>
                        <Button type="primary" htmlType="submit">
                            Login
                        </Button>
                    </Form.Item>
                </Form>
            </div>
        );
    };

    render() {
        const {errorMsg} = this.state;

        return (
            <div>
                <Error
                    message={errorMsg}
                />
                <div className={s.login_logo}>
                    <Image
                        src={Logo}
                        width={200}
                        preview={false}
                        alt=""
                    />
                </div>
                <div className={s.root}>
                    <div className={s.form_wrap}>
                        {this.renderForm()}
                    </div>
                </div>
            </div>
        );
    }
}

export default LoginForm;
