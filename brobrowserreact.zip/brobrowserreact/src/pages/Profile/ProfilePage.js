import s from './ProfilePage.module.scss';

import React from 'react';
import {withRouter} from 'react-router-dom';

import {inject, observer} from "mobx-react";

import {
    Layout,
    PageHeader,
    Form,
    Input,
    Select,
    InputNumber,
    Switch,
    Button,
    Divider,
    Space,
    Row,
    Col,
    Modal
} from 'antd';

import {
    BookOutlined,
    ChromeFilled,
    KeyOutlined,
    LaptopOutlined,
    QuestionCircleOutlined,
    UserOutlined,
    WarningOutlined,
    WindowsFilled
} from "@ant-design/icons";

const {Option} = Select;
const {Content} = Layout;

const electron = window.require('electron');
const ipcRenderer = electron.ipcRenderer;

@inject('mainStore')
@observer
class ProfilePage extends React.Component {
    state = {
        editMode: false,
        deviceShow: false,
        proxyShow: false,
        proxyAuthShow: false,
        formProfileName: '',
        profile: {},
        isAndroid: false,
        isIOS: false,
        isFullVersion: true,
        isFormChanged: false,
    };

    formRef = React.createRef();

    profileTemplate = {
        id: '',
        name: '',
        device: '',
        browser: '',
        os: '',
        proxy: '',
        proxyProtocol: '',
        proxyIP: '',
        proxyPort: '',
        proxyLogin: '',
        proxyPassword: '',
        script: '',
    }

    // Change Form
    handleChangeForm = (values) => {
        const {profile, deviceShow, proxyShow, proxyAuthShow} = this.state;

        this.setState({
            isFormChanged: true,
        });

        this.profileTemplate.name = values.name ? values.name : profile.name;
        if (deviceShow) {
            this.profileTemplate.device = values.device ? values.device : profile.device;
            this.profileTemplate.browser = values.browser ? values.browser : profile.browser;
            this.profileTemplate.os = values.os ? values.os : profile.os;
        } else {
            this.profileTemplate.device = undefined;
            this.profileTemplate.browser = undefined;
            this.profileTemplate.os = undefined;
        }
        if (proxyShow) {
            this.profileTemplate.proxyProtocol = values.proxyProtocol ? values.proxyProtocol : profile.proxyProtocol;
            this.profileTemplate.proxyIP = values.proxyIP ? values.proxyIP : profile.proxyIP;
            this.profileTemplate.proxyPort = values.proxyPort ? values.proxyPort : profile.proxyPort;
            this.profileTemplate.proxyLogin = values.proxyLogin ? values.proxyLogin : profile.proxyLogin;
            this.profileTemplate.proxyPassword = values.proxyPassword ? values.proxyPassword : profile.proxyPassword;
        } else {
            this.profileTemplate.proxyProtocol = undefined;
            this.profileTemplate.proxyIP = undefined;
            this.profileTemplate.proxyPort = undefined;
            this.profileTemplate.proxyLogin = undefined;
            this.profileTemplate.proxyPassword = undefined;
        }

        if (proxyShow && proxyAuthShow) {
            this.profileTemplate.proxyLogin = values.proxyLogin ? values.proxyLogin : profile.proxyLogin;
            this.profileTemplate.proxyPassword = values.proxyPassword ? values.proxyPassword : profile.proxyPassword;
        } else {
            this.profileTemplate.proxyLogin = undefined;
            this.profileTemplate.proxyPassword = undefined;
        }

        this.profileTemplate.proxy = this.profileTemplate.proxyIP ? (this.profileTemplate.proxyProtocol + this.profileTemplate.proxyIP + ':' + this.profileTemplate.proxyPort) : "None/VPN";

        // console.dir(this.profileTemplate);
    }

    // Submit Form
    handleSubmitForm = (values) => {
        this.handleChangeForm(values);
        ipcRenderer.send('add-profile', this.profileTemplate);
        this.handleGotoBack();
    };

    componentDidMount() {

        const {mainStore} = this.props;

        if (!mainStore.get('isFirstShow')) {
            mainStore.set('isFirstShow', true);
            mainStore.showLoader();
        }

        this.formRef.current.resetFields();

        try {
            const {profile} = this.props.location.state;
            const {id} = this.props.match.params;

            if (id) {
                this.profileTemplate.id = id;
            }

            // console.dir(profile);

            this.setState({
                editMode: true,
                profile: profile,
            }, () => {
                this.initFormValue()
            });

            if (profile.device) {
                this.setState({
                    deviceShow: true,
                });
            }

            if (profile.proxyProtocol) {
                this.setState({
                    proxyShow: true,
                });

                if (profile.proxyLogin) {
                    this.setState({
                        proxyAuthShow: true,
                    });
                }
            }

            if (profile.os === 'Android') {
                this.setState({
                    isAndroid: true,
                    isIOS: false,
                });
            } else if (profile.os === 'iOS' || profile.os === 'MacOSX') {
                this.setState({
                    isAndroid: false,
                    isIOS: true,
                });
            } else {
                this.setState({
                    isAndroid: false,
                    isIOS: false,
                });
            }

        } catch (e) {
            // console.warn(e);
        }

        this.handleChangeDevice();
        this.handleChangeOS();
    }

    handleChangeDevice = () => {
        this.setState({
            isAndroid: false,
            isIOS: false,
        });

        this.formRef.current.setFieldsValue({
            os: undefined,
            browser: undefined,
        });
    }

    handleChangeOS = () => {
        if (this.profileTemplate.os === 'Android') {
            this.setState({
                isAndroid: true,
                isIOS: false,
            });
        } else if (this.profileTemplate.os === 'iOS' || this.profileTemplate.os === 'MacOSX') {
            this.setState({
                isAndroid: false,
                isIOS: true,
            });
        } else {
            this.setState({
                isAndroid: false,
                isIOS: false,
            });
        }

        this.formRef.current.setFieldsValue({
            browser: undefined,
        })
    }

    // Возвращаемся на главную страницу
    handleGotoBack = () => {
        Modal.destroyAll();

        const {mainStore} = this.props;
        mainStore.set('isFirstShow', false);

        this.props.history.push("/");
    };

    onChangeDeviceSelect = (checked) => {
        const {profile} = this.state;

        this.setState({
            deviceShow: !this.state.deviceShow,
            isFormChanged: true,
        });

        if (!checked) {
            this.setState({
                profile: {
                    device: undefined,
                    os: undefined,
                    browser: undefined,
                    ...profile
                }
            });

            this.formRef.current.setFieldsValue({
                device: undefined,
                os: undefined,
                browser: undefined,
            });
        }

    };

    onChangeProxySelect = (checked) => {
        const {profile} = this.state;

        this.setState({
            proxyShow: !this.state.proxyShow,
            isFormChanged: true,
        });

        if (!checked) {
            this.setState({
                profile: {
                    proxyProtocol: undefined,
                    proxyIP: undefined,
                    proxyPort: undefined,
                    proxyLogin: undefined,
                    proxyPassword: undefined,
                    ...profile
                }
            })
        }

        this.formRef.current.setFieldsValue({
            proxyProtocol: undefined,
            proxyIP: undefined,
            proxyPort: undefined,
        });
    };

    handleChangeProxyProtocol = () => {
        const {profile} = this.state;

        const proxyProtocol = this.profileTemplate.proxyProtocol;

        if (proxyProtocol === 'socks4://') {
            Modal.error({
                title: 'SOCKS4 Info',
                content: (
                    <>
                        <br/>
                        SOCKS4 does not support authorization.
                    </>
                )
            });

            this.setState({
                proxyAuthShow: false,
                profile: {
                    proxyLogin: undefined,
                    proxyPassword: undefined,
                    ...profile
                }
            });
        }
    }

    onChangeProxyAuthSelect = (checked) => {

        if (this.state.isFullVersion) {
            const {profile} = this.state;

            const proxyProtocol = this.profileTemplate.proxyProtocol;

            if (proxyProtocol === 'socks4://') {
                Modal.error({
                    title: 'SOCKS4 Info',
                    content: (
                        <>
                            <br/>
                            SOCKS4 does not support authorization.
                        </>
                    )
                });

                this.setState({
                    proxyAuthShow: false,
                });

                return;
            }

            this.setState({
                proxyAuthShow: !this.state.proxyAuthShow,
                isFormChanged: true,
            });

            if (!checked) {
                this.setState({
                    profile: {
                        proxyLogin: undefined,
                        proxyPassword: undefined,
                        ...profile
                    }
                });
            }

            this.formRef.current.setFieldsValue({
                proxyLogin: undefined,
                proxyPassword: undefined,
            });
        } else {
            Modal.error({
                title: 'Limited Version',
                content: (
                    <>
                        <br/>
                        This version works with limitations.
                        <br/>
                        <br/>
                        With a full license, you can use the fully functional broBrowser product with unlimited usage.
                    </>
                )
            });
        }
    };

    initFormValue = () => {
        const {profile, editMode} = this.state;

        if (editMode) {
            this.formRef.current.setFieldsValue({
                name: profile.name,
                device: profile.device,
                os: profile.os,
                browser: profile.browser,
                proxy: profile.proxy,
                proxyProtocol: profile.proxyProtocol,
                proxyIP: profile.proxyIP,
                proxyPort: profile.proxyPort,
                proxyLogin: profile.proxyLogin,
                proxyPassword: profile.proxyPassword,
            });
        }
    }

    render() {
        const {editMode, deviceShow, proxyShow, proxyAuthShow, profile, isIOS} = this.state;

        let titleText = "Create Profile";
        let subTitleText = "Create a new browser profile";

        if (editMode) {
            titleText = "Edit Profile";
            subTitleText = "Edit existing browser profile";
        }

        const validateMessages = {
            required: 'required field!',
        };

        return (
            <>
                <PageHeader
                    className={s['site-page-header']}
                    onBack={() => {
                        if (this.state.isFormChanged) {
                            Modal.confirm({
                                title: 'Attention...',
                                icon: <WarningOutlined/>,
                                content: 'All your changes will be lost. Are you sure?',
                                okText: 'Yes',
                                cancelText: 'No',
                                onOk: this.handleGotoBack,
                            });
                        } else {
                            this.handleGotoBack();
                        }
                    }}
                    title={titleText}
                    subTitle={subTitleText}
                />

                <Layout className="layout">
                    <div className={s['site-layout-content']}>
                        <Content className={s['div-content-style']}>

                            <Form
                                ref={this.formRef}
                                name="profileForm"
                                labelCol={{span: 3}}
                                layout="horizontal"
                                onFinish={(values) => {
                                    if (editMode) {
                                        Modal.confirm({
                                            title: 'Save profile...',
                                            icon: <QuestionCircleOutlined/>,
                                            content: 'Do you want change profile ?',
                                            okText: 'Yes',
                                            cancelText: 'No',
                                            onOk: () => {
                                                this.handleSubmitForm(values);
                                            },
                                        });
                                    } else {
                                        this.handleSubmitForm(values);
                                    }
                                }}
                                onValuesChange={this.handleChangeForm}
                                validateMessages={validateMessages}
                            >

                                <Row justify={"center"}>
                                    <Col span={10}>
                                        <Form.Item
                                            name="name"
                                            rules={[{
                                                required: true,
                                            }]}
                                        >
                                            <Input
                                                prefix={<BookOutlined className="site-form-item-icon"/>}
                                                // disabled={editMode}
                                                placeholder={"Profile Name"}
                                                maxLength={35}
                                                value={profile.name}
                                            />
                                        </Form.Item>
                                    </Col>
                                </Row>

                                <Form.Item
                                    name="deviceEnabled"
                                >
                                    <Space direction={"horizontal"} size={"large"}>
                                        <Switch
                                            name="deviceEnabled"
                                            onChange={this.onChangeDeviceSelect}
                                            checked={deviceShow}/>
                                        Device emulator
                                    </Space>
                                </Form.Item>

                                {deviceShow && (
                                    <>
                                        <Divider>Configure your device</Divider>
                                        <Row justify={"center"}>
                                            <Col>
                                                <Space direction="horizontal" align="center" size="small">
                                                    <Form.Item
                                                        name="device"
                                                        rules={[{
                                                            required: deviceShow,
                                                        }]}
                                                    >
                                                        <Select
                                                            style={{width: 120}}
                                                            placeholder="Device Type"
                                                            suffixIcon={<LaptopOutlined
                                                                className="site-form-item-icon"/>}
                                                            onChange={this.handleChangeDevice}
                                                        >
                                                            <Option value="Computer">Computer</Option>
                                                            <Option value="Mobile">Mobile</Option>
                                                        </Select>
                                                    </Form.Item>
                                                    <Form.Item
                                                        name="os"
                                                        rules={[{
                                                            required: deviceShow,
                                                        }]}
                                                    >
                                                        <Select
                                                            style={{width: 120}}
                                                            placeholder="Operation system"
                                                            suffixIcon={<WindowsFilled
                                                                className="site-form-item-icon"/>}
                                                            onChange={this.handleChangeOS}>
                                                            >
                                                            {(this.formRef.current.getFieldValue(['device']) === 'Computer') && (
                                                                <>
                                                                    <Option value="Windows">Windows</Option>
                                                                    <Option value="MacOSX">MacOSX</Option>
                                                                    <Option value="Linux">Linux</Option>
                                                                </>
                                                            )}
                                                            {(this.formRef.current.getFieldValue(['device']) === 'Mobile') && (
                                                                <>
                                                                    <Option value="Android">Android</Option>
                                                                    <Option value="iOS">iOS</Option>
                                                                </>
                                                            )}
                                                        </Select>
                                                    </Form.Item>
                                                    <Form.Item
                                                        name="browser"
                                                        rules={[{
                                                            required: deviceShow,
                                                        }]}
                                                    >
                                                        <Select
                                                            style={{width: 120}}
                                                            placeholder="Browser"
                                                            suffixIcon={<ChromeFilled
                                                                className="site-form-item-icon"/>}
                                                            value={profile.browser}
                                                        >
                                                            {(this.formRef.current.getFieldValue(['device']) && this.formRef.current.getFieldValue(['os'])) && (
                                                                <>
                                                                    <Option value="Chrome">Chrome</Option>
                                                                    {/*{!isIOS && (*/}
                                                                    {/*    <Option value="Firefox">Firefox</Option>*/}
                                                                    {/*)}*/}
                                                                    {(this.formRef.current.getFieldValue(['os']) === 'Windows') &&
                                                                    (
                                                                        <Option value="Edge">Edge</Option>
                                                                    )}
                                                                    {!isIOS && (
                                                                        <Option value="Opera">Opera</Option>
                                                                    )}
                                                                </>
                                                            )}
                                                            {(isIOS && this.formRef.current.getFieldValue(['device']) && this.formRef.current.getFieldValue(['os'])) && (
                                                                <>
                                                                    <Option value="Safari">Safari</Option>
                                                                </>
                                                            )}
                                                        </Select>
                                                    </Form.Item>
                                                </Space>
                                            </Col>
                                        </Row>
                                        <Divider/>
                                    </>
                                )}

                                <Form.Item
                                    name="proxyEnabled"
                                >
                                    <Space direction={"horizontal"} size={"large"}>
                                        <Switch onChange={this.onChangeProxySelect} checked={proxyShow}/>
                                        Use proxy
                                    </Space>
                                </Form.Item>

                                {proxyShow && (<>
                                    <Divider>Configure your proxy server</Divider>
                                    <Row justify={"center"}>
                                        <Col>
                                            <Space direction="horizontal" align="center" size="small">
                                                <Form.Item
                                                    name="proxyProtocol"
                                                    rules={[{
                                                        required: proxyShow,
                                                    }]}
                                                >
                                                    <Select
                                                        style={{width: 120}}
                                                        placeholder="Proxy type"
                                                        onChange={this.handleChangeProxyProtocol}
                                                    >
                                                        <Option value="socks4://">SOCKS4</Option>
                                                        <Option value="socks5://">SOCKS5</Option>
                                                        <Option value="http://">HTTP</Option>
                                                        <Option value="https://">HTTPS</Option>
                                                    </Select>
                                                </Form.Item>
                                                <Form.Item
                                                    name="proxyIP"
                                                    rules={[{
                                                        required: proxyShow,
                                                    }]}
                                                >
                                                    <Input
                                                        placeholder="IP address"
                                                        maxLength={15}
                                                    />
                                                </Form.Item>
                                                <Form.Item
                                                    name="proxyPort"
                                                    rules={[{
                                                        required: proxyShow,
                                                    }]}
                                                >
                                                    <InputNumber
                                                        placeholder="Port"
                                                    />
                                                </Form.Item>
                                                <Divider/>
                                            </Space>
                                        </Col>
                                    </Row>
                                    <div className={s['switch-proxy-auth']}>
                                        <Space direction={"horizontal"} size={"large"}>
                                            <Switch onChange={this.onChangeProxyAuthSelect} checked={proxyAuthShow}/>Authorization
                                        </Space>
                                    </div>
                                    {proxyAuthShow &&
                                    <>
                                        <Divider dashed={true}/>
                                        <Row justify={"center"}>
                                            <Col>
                                                <Space direction="horizontal" align="center" size="small">
                                                    <Form.Item
                                                        name="proxyLogin"
                                                        rules={[{
                                                            required: proxyAuthShow,
                                                        }]}
                                                    >
                                                        <Input
                                                            placeholder="Login"
                                                            prefix={<UserOutlined className="site-form-item-icon"/>}
                                                        />
                                                    </Form.Item>
                                                    <Form.Item
                                                        name="proxyPassword"
                                                        rules={[{
                                                            required: proxyAuthShow,
                                                        }]}
                                                    >
                                                        <Input
                                                            placeholder="Password"
                                                            prefix={<KeyOutlined className="site-form-item-icon"/>}
                                                        />
                                                    </Form.Item>
                                                </Space>
                                            </Col>
                                        </Row>
                                    </>
                                    }
                                    <Divider/>
                                </>)}
                                <Form.Item>
                                    <Row justify={"center"}>
                                        <Col span={10}>
                                            <Button
                                                size={"large"}
                                                shape={"round"}
                                                block={true}
                                                type="primary"
                                                htmlType="submit">
                                                Submit
                                            </Button>
                                        </Col>
                                    </Row>
                                </Form.Item>
                            </Form>
                        </Content>
                    </div>
                </Layout>

            </>
        );
    }

}

export default withRouter(ProfilePage);
