import React, { Component } from 'react';

import RegisterForm from "../../components/RegisterForm/RegisterForm";
import { Layout } from "antd";

const { Content } = Layout;

class RegisterPage extends Component {
    state = {};

    render() {
        return (
            <Layout>
                <Content>
                    <RegisterForm/>
                </Content>
            </Layout>
        );
    };
}

export default RegisterPage;