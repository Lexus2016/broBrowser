import RegisterPage from './RegisterPage';

export default RegisterPage;
