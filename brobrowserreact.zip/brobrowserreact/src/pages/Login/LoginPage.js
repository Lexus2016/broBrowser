import React, {Component} from 'react';

import LoginForm from "../../components/LoginForm/LoginForm";

class LoginPage extends Component {
    state = {};

    render() {
        return (
            <LoginForm/>
        );
    };
}

export default LoginPage;