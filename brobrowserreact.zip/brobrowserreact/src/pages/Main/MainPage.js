import s from './MainPage.module.scss';
import React from "react";

// import Logo from '../../brobrowser.png';

import {Button, Col, Divider, Input, Layout, Menu, Modal, Row, Space, Tooltip} from 'antd';

import {
    EyeInvisibleOutlined,
    EyeTwoTone,
    LogoutOutlined,
    SettingOutlined,
    UserAddOutlined,
    UserOutlined
} from '@ant-design/icons';

import ProfileCard from '../../components/ProfileCard';
import {inject, observer} from 'mobx-react';
import Error from '../../components/Error';

const {Sider, Content} = Layout;
const {Search} = Input;

const electron = window.require('electron');
const ipcRenderer = electron.ipcRenderer;

@inject('mainStore')
@observer
class MainPage extends React.Component {
    state = {
        collapsed: true,
        profileMenu: true,
        settingsMenu: false,
        ProfileArr: [],
        ProfileShowArr: [],
        pathToChrome: '',
        isModalPasswordVisible: false,
        isModalLogOutVisible: false,
        pass1: '',
        pass2: '',
        errorMsg: '',
        needExit: false,
    };

    version = process.env.REACT_APP_NAME;

    componentDidMount() {
        document.body.style.overflow = 'hidden';

        const {mainStore} = this.props;

        if (!mainStore.get('isFirstShow')) {
            mainStore.set('isFirstShow', true);
            mainStore.showLoader();
        }

        ipcRenderer.send('get-data');
        this.getChromePath();

        // When the document is rendered.
        // const self = this;
        ipcRenderer.on('get-profiles', (event, profiles) => {
            // alert(JSON.stringify(profiles));

            // console.dir( profiles );
            this.setState({
                ProfileArr: profiles,
            });

            this.setState({
                ProfileShowArr: profiles,
            });
        });
    }

    onCollapse = collapsed => {
        // console.log( collapsed );
        this.setState({collapsed});
    };

    getChromePath = () => {
        let path = ipcRenderer.sendSync('get-chrome-path');

        if (path !== '') {
            this.setState({
                pathToChrome: path,
            });
        }
    }

    ProfileMenu = () => {
        this.setState({
                profileMenu: true,
                settingsMenu: false,
                needExit: false,
            }
        );
    }

    SettingsMenu = () => {
        this.setState({
                profileMenu: false,
                settingsMenu: true,
                needExit: false,
            }
        );
    }

    logOutMenu = () => {
        this.setState({
                // profileMenu: false,
                // settingsMenu: false,
                needExit: true,
                isModalLogOutVisible: true,
            }
        );
    }

    handleLogOut = () => {
        const {mainStore} = this.props;
        mainStore.set('isLogin', false);
        mainStore.showLoader();
    }

    // Выводим ошибку
    handlerSetErrorMsg = (error) => {
        this.setState({
            errorMsg: error,
        });

        this.errTimeout = setTimeout(() => {
            this.setState({
                errorMsg: '',
            });
        }, 5000);
    };

    setNewPassword = () => {
        this.setState({
            isModalPasswordVisible: true,
            pass1: '',
            pass2: '',
        });
    }

    handleOkPassword = () => {

        const {pass1, pass2} = this.state;

        if (pass1 !== pass2) {
            this.handlerSetErrorMsg('Passwords are not equal');
        } else if (pass1.length <= 6) {
            this.handlerSetErrorMsg('Password must be longer than 6 characters');
        } else {
            // Set new password
            ipcRenderer.send('get-change-password', pass1);
            Modal.success({
                content: 'Password successfully changed',
            });

            this.setState({
                isModalPasswordVisible: false,
            });
        }
    };

    handleCancel = () => {
        this.setState({
            isModalPasswordVisible: false,
            isModalLogOutVisible: false,
            errorMsg: '',
        });
    };

    // Content Profiles menu
    contentProfile = (ProfileArr) => (
        <>
            <Content>
                <Row gutter={[8, 8]}>
                    {
                        ProfileArr.map((item) => {
                            return (
                                <Col key={item.id}>
                                    <ProfileCard key={item.id} profile={item}/>
                                </Col>
                            );
                        })
                    }
                </Row>
            </Content>
        </>
    );

    setFilteredProfiles = (searchString = '') => {

        const {ProfileArr} = this.state;

        if (searchString === '') {
            this.setState({
                ProfileShowArr: ProfileArr,
            })
        }

        const result = ProfileArr.filter(obj => {
            return (
                (obj.name && obj.name.toLowerCase().includes(searchString.toLowerCase())) ||
                (obj.os && obj.os.toLowerCase().includes(searchString.toLowerCase())) ||
                (obj.browser && obj.browser.toLowerCase().includes(searchString.toLowerCase())) ||
                (obj.device && obj.device.toLowerCase().includes(searchString.toLowerCase()))
            );
        });

        this.setState({
            ProfileShowArr: result,
        });
    }

    onChangePass1 = ({target: {value}}) => {
        this.setState({
            pass1: value,
        });
    };

    onChangePass2 = ({target: {value}}) => {
        this.setState({
            pass2: value,
        });
    };

    // Content Settings menu
    contentSettings = (pathToChrome) => (
        <>
            <Modal
                title="Set New Password"
                visible={this.state.isModalPasswordVisible}
                onOk={this.handleOkPassword}
                onCancel={this.handleCancel}
            >
                <Space direction="vertical">
                    <Input.Password
                        style={{width: 475}}
                        size="large"
                        placeholder="input password"
                        onChange={this.onChangePass1}
                        value={this.state.pass1}
                    />
                    <Input.Password
                        size="large"
                        placeholder="repeat password"
                        iconRender={visible => (visible ? <EyeTwoTone/> : <EyeInvisibleOutlined/>)}
                        onChange={this.onChangePass2}
                        value={this.state.pass2}
                    />
                </Space>
            </Modal>

            <Content>
                <Divider><strong> Settings </strong></Divider>
                <Divider> [ Path to Google Chrome ] </Divider>
                <Input disabled={true} value={pathToChrome}/>
                {pathToChrome === '' &&
                <Button onClick={this.getChromePath}>Get Chrome Path</Button>
                }
                <Divider>[ Change Password ] </Divider>
                <p style={{textAlign: 'center'}}>
                    <Button onClick={this.setNewPassword}>Change password</Button>
                </p>
                <Divider/>
            </Content>
        </>
    );

    // Content Settings menu
    contentLogOut = () => (
        <>
            <Modal
                title="Attention"
                visible={this.state.isModalLogOutVisible}
                onOk={this.handleLogOut}
                onCancel={this.handleCancel}
            >
                <Space direction="vertical">
                    Do you confirm to exit the application?
                </Space>
            </Modal>
        </>
    );

    onSearch = ({target: {value}}) => {
        this.setFilteredProfiles(value);
        this.setState({
                profileMenu: true,
                settingsMenu: false,
            }
        );
    }

    render() {
        const {collapsed, pathToChrome, ProfileShowArr, errorMsg} = this.state;

        return (
            <>
                <Error
                    message={errorMsg}
                />
                <Layout style={{minHeight: '100vh'}}>
                    <Sider collapsible collapsed={collapsed} onCollapse={this.onCollapse}>
                        <Menu theme="dark" defaultSelectedKeys={['1']} mode="inline"
                              style={{marginTop: '-4px'}}>
                            <Menu.Item
                                key="1"
                                icon={<UserOutlined/>}
                                onClick={this.ProfileMenu}
                            >
                                Profiles
                            </Menu.Item>
                            <Menu.Item
                                key="2"
                                icon={<SettingOutlined/>}
                                onClick={this.SettingsMenu}
                            >
                                Settings
                            </Menu.Item>
                            <Menu.Item
                                key="3"
                                icon={<LogoutOutlined/>}
                                onClick={this.logOutMenu}
                            >
                                LogOut
                            </Menu.Item>
                        </Menu>
                    </Sider>
                    <Layout className={s['site-layout']}>
                        {this.state.profileMenu && (
                            // <Content className={s.siteLayoutBackground} style={{padding: 0}}>
                            <div className={s['profile-button']}>
                                {/*<Space direction="horizontal" size={10}>*/}
                                <Tooltip title="Add new profile">
                                    <Button
                                        type="primary"
                                        shape="circle"
                                        size="large"
                                        icon={<UserAddOutlined/>}
                                        onClick={(event) => {
                                            event.stopPropagation();
                                            const {mainStore} = this.props;
                                            mainStore.set('isFirstShow', false);

                                            this.props.history.push({
                                                pathname: "/addProfile/",
                                            });
                                        }}
                                    />
                                </Tooltip>
                                <Search
                                    className={s['search-box']}
                                    placeholder="Start typing to find your profile"
                                    onChange={this.onSearch}
                                    maxLength={30}
                                    allowClear
                                    enterButton
                                />
                                {/*</Space>*/}
                            </div>
                            // </Content>
                        )}
                        <Content
                            className={s['site-layout-background']}
                            style={{
                                margin: '0px 0px 0px 0px',
                                padding: 8,
                                minHeight: 400,
                            }}
                        >
                            <div style={{
                                // overflow: 'auto',
                                overflowX: 'hidden',
                                overflowY: 'auto',
                                height: '1px',
                                minHeight: '90vh',
                                minWidth: '50vh',
                                paddingBottom: '10px'
                            }}>
                                {this.state.profileMenu ? this.contentProfile(ProfileShowArr) : null}
                                {this.state.settingsMenu ? this.contentSettings(pathToChrome) : null}
                                {this.state.needExit ? this.contentLogOut() : null}
                            </div>
                        </Content>
                    </Layout>
                </Layout>
            </>
        );
    }
}

export default MainPage;
