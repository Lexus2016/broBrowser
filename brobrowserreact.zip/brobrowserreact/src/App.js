import './App.css';

import React from 'react';
import {
    Switch,
    Route
} from "react-router-dom";

import MainPage from './pages/Main/MainPage';

import {inject, observer} from 'mobx-react';

import SpinLoader from './components/SpinLoader';
import LoginPage from './pages/Login';
import ProfilePage from "./pages/Profile/ProfilePage";

@inject('mainStore')
@observer
class App extends React.Component {
    state = {};

    componentDidMount() {
        const {mainStore} = this.props;
        mainStore.showLoader();
    }

    render() {

        const {mainStore} = this.props;
        const auth = mainStore.get('isLogin');

        if (mainStore.get('showLoader')) {
            return (
                <SpinLoader/>
            );
        }

        // console.log(auth);

        return (
            <div>
                {!auth && <LoginPage/>}
                {auth &&
                <Switch>
                    <Route exact path="/" component={MainPage}/>
                    <Route exact path="/addProfile/:id" component={ProfilePage}/>
                    <Route exact path="/addProfile" component={ProfilePage}/>
                    <Route path="*" component={MainPage}/>
                </Switch>
                }
            </div>
        );
    }
}

export default App;
