const puppeteer = require('puppeteer-core');

const remoteDebuggingPort = 15940;

(async () => {
    const browserURL = 'http://127.0.0.1:' + remoteDebuggingPort;

    const browser = await puppeteer.connect({
        browserURL
    });

    if (!browser) {
        console.log("Browser control error");
    }

    const page = await browser.newPage();
    await page.setViewport({ width: 0, height: 0 });
    await page._client.send('Emulation.clearDeviceMetricsOverride');
    await page.goto('https://google.com');
})();