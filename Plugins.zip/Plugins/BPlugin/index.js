// chrome.storage.local.clear();
// Fake canvas math
let shift = {
    'r': Math.floor(Math.random() * 5),
    'g': Math.floor(Math.random() * 5),
    'b': Math.floor(Math.random() * 5),
    'a': Math.floor(Math.random() * 5),
};

const SIGN = Math.random() < Math.random() ? -1 : 1;
const tmp = [-1, -1, -1, -1, -1, -1, +1, -1, -1, -1];
const index = Math.floor(Math.random() * tmp.length);

let rand = {
    'noise': Math.floor(Math.random() + SIGN * Math.random()),
    'sign': tmp[index],
    'rand1': Math.random(),
    'rand2': Math.random(),
    'rand3': Math.random(),
    'rand4': Math.random(),
};

function getPlgConfig() {
    // Get Plugin Settings
    chrome.storage.local.get(['fkIPSettingsPlugin'], (elems) => {
        if (!chrome.runtime.lastError) {
            SetFkbrPlgConfig(elems['fkIPSettingsPlugin']);
        }
    });
}

// Get Config from LocalStorage
function getConfig() {
    return new Promise((resolve) => {
        // Restore fingerprints
        // Start
        chrome.storage.local.get({
            'fkShift': shift
        }, (elems) => {
            if (!chrome.runtime.lastError) {
                shift = elems['fkShift'];
                chrome.storage.local.set({
                    'fkShift': elems['fkShift']
                });
            } else {
                chrome.storage.local.set({
                    'fkShift': shift
                });
            }
        });

        chrome.storage.local.get({
            'fkRand': rand
        }, (elems) => {
            if (!chrome.runtime.lastError) {
                rand = elems['fkRand'];
                chrome.storage.local.set({
                    'fkRand': elems['fkRand']
                });
            } else {
                chrome.storage.local.set({
                    'fkRand': rand
                });
            }
        });
        // End
        // Restore fingerprints

        // Get Profile
        chrome.storage.local.get(['fkConfig'], (elems) => {
            if (!chrome.runtime.lastError) {
                SetFkbrConfig(elems['fkConfig']);
                resolve(elems['fkConfig']);
            }
        });
    });
}

function SetFkbrConfig(config) {
    document.documentElement.dataset.IP = config['ip'];
    document.documentElement.dataset.Country = config['country'];
    document.documentElement.dataset.cc = config['countryCode'];
    document.documentElement.dataset.ct = config['connectionType'];
    document.documentElement.dataset.DC = config['isDC'];
    document.documentElement.dataset.PRX = config['isProxy'];
    document.documentElement.dataset.MLW = config['isMalware'];
    document.documentElement.dataset.CRW = config['isCrawler'];
    document.documentElement.dataset.prjname = Profile['name'];
}

function SetFkbrPlgConfig(config) {
    try {
        isPlgOn = config['on'];
        isPlgBlock = config['block'];
        isPlgMinimzed = config['minimized'];
        isPlgShow = config['show'];
    } catch (e) {}
    document.documentElement.dataset.ismin = isPlgMinimzed;
}

// Change IP
chrome.storage.onChanged.addListener(function() {
    getConfig();
    getPlgConfig();
});

getPlgConfig();

// This is function injected to Page
function inject(configSettings, profileSettings, shiftValue, randValue) {

    window.onerror = function() {
        return true;
    }

    if (!Function.prototype.bind) {
        Function.prototype.bind = function(oThis) {
            if (typeof this !== "function") {
                // closest thing possible to the ECMAScript 5 internal IsCallable function
                // throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable");
                return;
            }

            var aArgs = Array.prototype.slice.call(arguments, 1),
                fToBind = this,
                fNOP = function() {},
                fBound = function() {
                    return fToBind.apply(
                        this instanceof fNOP && oThis ? this : oThis,
                        aArgs.concat(Array.prototype.slice.call(arguments))
                    );
                };

            fNOP.prototype = this.prototype;
            fBound.prototype = new fNOP();

            return fBound;
        };
    }

    // Disable WebRTC
    try {
        navigator.mediaDevices.getUserMedia = navigator.webkitGetUserMedia = navigator.mozGetUserMedia = navigator.getUserMedia = undefined;
    } catch (e) {}

    try {
        webkitRTCPeerConnection = RTCPeerConnection = MediaStreamTrack = undefined;
    } catch (e) {}

    // Config Start
    const Browser = profileSettings;

    var Languages = Languages || {};
    var TimeSettings = TimeSettings || {};

    Languages.lang = configSettings.lang;
    Languages.langs = configSettings.langs;

    TimeSettings.newTimeOffset = configSettings.newTimeOffset;
    TimeSettings.timeZoneV = configSettings.timeZoneV;
    // Config End

    // Lib functions
    // Start

    const definePropFunc = function(obj, prop, val) {
        Object.defineProperty(obj, prop, {
            enumerable: true,
            configurable: true,
            writable: true,
            value: val
        });
    };

    const defineProp = function(obj, prop, val) {
        Object.defineProperty(obj, prop, {
            enumerable: true,
            configurable: true,
            writable: true,
            value: val,
        });
    };

    const defineNavigatorGetter = function(obj, val) {
        navigator.__defineGetter__(obj, function() {
            return val;
        });
    };
    // Lib functions
    // End

    // Navigator Faker

    for (let [key, value] of Object.entries(Browser.navigator)) {
        // console.log(key, value);
        try {
            defineNavigatorGetter(key, value);
        } catch (e) {}
    }


    defineNavigatorGetter("doNotTrack", "1");
    defineNavigatorGetter("serviceWorker", null);
    defineNavigatorGetter("Worker", null);

    const langObjects = {
        'language': Languages.lang,
        'languages': [Languages.lang],
        'systemLanguage': Languages.lang,
        'userLanguage': Languages.lang,
        'browserLanguage': Languages.lang,
    };

    for (let [key, value] of Object.entries(langObjects)) {
        try {
            defineNavigatorGetter(key, value);
        } catch (e) {}
    }

    // Window Objects faker
    const HTMLElementObjects = {
        'innerWidth': Browser.window.innerWidth,
        'innerHeight': Browser.window.innerHeight,
        'outerWidth': Browser.window.outerWidth,
        'outerHeight': Browser.window.outerHeight,
    };

    // HTMLElement
    for (let [key, value] of Object.entries(HTMLElementObjects)) {
        try {
            if (typeof value !== 'undefined') {
                defineProp(HTMLElement.prototype, key, value);
            }
        } catch (e) {}
    }

    try {
        if (Browser.global.isMobile) {
            if (typeof Browser.window.innerWidth !== 'undefined') {
                defineProp(HTMLElement.prototype, "clientWidth", Browser.window.innerWidth);
            }
            if (typeof Browser.window.innerHeight !== 'undefined') {
                defineProp(HTMLElement.prototype, "clientHeight", Browser.window.innerHeight);
            }
        }
    } catch (e) {}


    // window
    try {
        for (let [key, value] of Object.entries(Browser.window)) {
            try {
                if (key === 'pageXOffset' || key === 'pageYOffset') {
                    continue;
                }
                defineProp(window, key, value);
            } catch (e) {}
        }
    } catch (e) {}

    // window.screen
    for (let [key, value] of Object.entries(Browser.screen)) {
        try {
            defineProp(window.screen, key, value);
        } catch (e) {}
    }

    // Fix browsers
    if (/Safari/i.test(Browser.navigator.userAgent)) {
        defineProp(window, "webkitConvertPointFromPageToNode", true);
    }

    if (/Opera/i.test(Browser.navigator.userAgent)) {
        defineProp(window, "opr", true);
    }

    if (/Edge/i.test(Browser.navigator.userAgent)) {
        defineProp(window, "StyleMedia", true);
    }

    if (/MSIE/i.test(Browser.navigator.userAgent)) {
        defineProp(document, "documentMode", true);
    }

    // Fake rect coordinate for fingerprint
    const OLDgetBoundingClientRect = window.HTMLElement.prototype.getBoundingClientRect;
    window.HTMLElement.prototype.getBoundingClientRect = function() {
        let r = OLDgetBoundingClientRect.apply(this, arguments);
        try {
            if (r.length > 0) {
                r[0].x = r[0].x + randValue.rand2;
                r[0].y = r[0].y + randValue.rand2;
                r[0].top = r[0].top + randValue.rand2;
                r[0].bottom = r[0].bottom + randValue.rand2;
                // r[0].width = r[0].width + randValue.rand2;
                // r[0].height = r[0].height + randValue.rand2;
                r[0].left = r[0].left + randValue.rand2;
                r[0].right = r[0].right + randValue.rand2;
            }
        } catch (e) {}
        return r;
    }

    const OLDgetBoundingClientRect1 = window.Element.prototype.getBoundingClientRect;
    window.Element.prototype.getBoundingClientRect = function() {
        let r = OLDgetBoundingClientRect1.apply(this, arguments);
        try {
            if (r.length > 0) {
                r[0].x = r[0].x + randValue.rand2;
                r[0].y = r[0].y + randValue.rand2;
                r[0].top = r[0].top + randValue.rand2;
                r[0].bottom = r[0].bottom + randValue.rand2;
                // r[0].width = r[0].width + randValue.rand2;
                // r[0].height = r[0].height + randValue.rand2;
                r[0].left = r[0].left + randValue.rand2;
                r[0].right = r[0].right + randValue.rand2;
            }
        } catch (e) {}
        return r;
    }

    const OLDgetClientRects = window.HTMLElement.prototype.getClientRects;
    window.HTMLElement.prototype.getClientRects = function() {
        let r = OLDgetClientRects.apply(this, arguments);
        try {
            if (r.length > 0) {
                r[0].x = r[0].x + randValue.rand2;
                r[0].y = r[0].y + randValue.rand2;
                r[0].top = r[0].top + randValue.rand2;
                r[0].bottom = r[0].bottom + randValue.rand2;
                // r[0].width = r[0].width + randValue.rand2;
                // r[0].height = r[0].height + randValue.rand2;
                r[0].left = r[0].left + randValue.rand2;
                r[0].right = r[0].right + randValue.rand2;
            }
        } catch (e) {}
        return r;
    }

    const OLDgetClientRects1 = window.Element.prototype.getClientRects;
    window.Element.prototype.getClientRects = function() {
        let r = OLDgetClientRects1.apply(this, arguments);
        try {
            if (r.length > 0) {
                r[0].x = r[0].x + randValue.rand2;
                r[0].y = r[0].y + randValue.rand2;
                r[0].top = r[0].top + randValue.rand2;
                r[0].bottom = r[0].bottom + randValue.rand2;
                // r[0].width = r[0].width + randValue.rand2;
                // r[0].height = r[0].height + randValue.rand2;
                r[0].left = r[0].left + randValue.rand2;
                r[0].right = r[0].right + randValue.rand2;
            }
        } catch (e) {}
        return r;
    }

    // Canvas Faker
    function overrideCanvasInternal(name, old) {
        Object.defineProperty(HTMLCanvasElement.prototype, name, {
            value: function() {

                const ctx = this.getContext("2d");
                if (ctx === null) {
                    old.apply(this, arguments);
                    return;
                }

                const width = this.width;
                const height = this.height;

                let imageData = ctx.getImageData(0, 0, width, height);
                for (let i = 0; i < height; i++) {
                    for (let j = 0; j < width; j++) {
                        let idx = ((i * (width * 4)) + (j * 4));
                        imageData.data[idx] = imageData.data[idx] + shiftValue.r;
                        imageData.data[idx + 1] = imageData.data[idx + 1] + shiftValue.g;
                        imageData.data[idx + 2] = imageData.data[idx + 2] + shiftValue.b;
                        imageData.data[idx + 3] = imageData.data[idx + 3] + shiftValue.a;
                    }
                }
                ctx.putImageData(imageData, 0, 0);
                return old.apply(this, arguments);
            }
        });
    }

    if (window.location.hostname.toLowerCase() !== 'f.vision') {
        overrideCanvasInternal("toDataURL", HTMLCanvasElement.prototype.toDataURL);
        overrideCanvasInternal("toBlob", HTMLCanvasElement.prototype.toBlob);
    }

    // QIWI broken!
    // Object.defineProperty(window, 'matchMedia', {
    //     writable: true,
    //     value: () => {
    //         return {
    //             matches: true,
    //             onchange: null,
    //             addListener: () => {},
    //             removeListener: () => {}
    //         };
    //     }
    // });

    const originalGetComputedStyle1 = HTMLElement.prototype.getComputedStyle;
    Object.defineProperty(HTMLElement.prototype, 'getComputedStyle', {
        value: (node) => ({
            getPropertyValue: (prop) => {

                let prevValue = originalGetComputedStyle1(node)[prop];


                if (prop.toLowerCase() === 'width' || prop.toLowerCase() === 'innerwidth' || prop.toLowerCase() === 'clientwidth') {
                    try {
                        prevValue = prevValue.replace('px', '');
                    } catch (e) {}

                    prevValue = prevValue > Browser.screen.width ? Browser.screen.width : prevValue;
                }

                if (prop.toLowerCase() === 'height' || prop.toLowerCase() === 'outherheight' || prop.toLowerCase() === 'clientheight') {
                    try {
                        prevValue = prevValue.replace('px', '');
                    } catch (e) {}

                    prevValue = prevValue > Browser.screen.height ? Browser.screen.height : prevValue;
                }

                return prevValue;
            }
        })
    });

    const originalGetComputedStyle2 = window.getComputedStyle;
    Object.defineProperty(window, 'getComputedStyle', {
        configurable: true,
        enumerable: true,
        value: function(elem, ...rest) {

            try {
                try {
                    if (typeof elem.width !== 'undefined') {

                        let val = elem.width;
                        try {
                            val = val.replace('px', '');
                        } catch (e) {}

                        if (val !== '' && val > Browser.screen.width) {
                            elem.width = Browser.screen.width;
                        }

                    }
                } catch (e) {}

                try {
                    if (typeof elem.height !== 'undefined') {

                        let val = elem.height;
                        try {
                            val = val.replace('px', '');
                        } catch (e) {}

                        if (val !== '' && val > Browser.screen.height) {
                            elem.height = Browser.screen.height;
                        }

                    }
                } catch (e) {}

                // return originalGetComputedStyle2.apply(this, arguments);

                return originalGetComputedStyle2.apply(this, [elem, ...rest]);

            } catch (e) {
                return originalGetComputedStyle2.apply(this, arguments);

                // return originalGetComputedStyle(elem)[[elem, ...rest]];
            }
        }
    });

    Object.defineProperty(window, 'getComputedStyle', {
        configurable: true,
        enumerable: true,
        value: (node) => ({
            getPropertyValue: (prop) => {

                // let prevValue = originalGetComputedStyle2.apply(node, [...prop]);
                let prevValue = originalGetComputedStyle2(node)[prop];

                // console.log(prop + ' -> ' + prevValue);

                if (prop.toLowerCase() === 'width' || prop.toLowerCase() === 'innerwidth' || prop.toLowerCase() === 'clientwidth') {
                    try {
                        prevValue = prevValue.replace('px', '');
                    } catch (e) {}

                    prevValue = prevValue > Browser.screen.width ? Browser.screen.width : prevValue;
                }

                if (prop.toLowerCase() === 'height' || prop.toLowerCase() === 'outherheight' || prop.toLowerCase() === 'clientheight') {
                    try {
                        prevValue = prevValue.replace('px', '');
                    } catch (e) {}

                    prevValue = prevValue > Browser.screen.height ? Browser.screen.height : prevValue;
                }

                return prevValue;
            }
        })
    });

    // DateTime Faker
    const timeZone = -TimeSettings.newTimeOffset; // in minutes
    let timeZoneHour = '';
    if (TimeSettings.newTimeOffset > 0) {
        if ((TimeSettings.newTimeOffset / 60) < 10) {
            timeZoneHour = '+0' + TimeSettings.newTimeOffset / 60; // in hour
        } else {
            timeZoneHour = '+' + TimeSettings.newTimeOffset / 60; // in hour
        }
    } else if (TimeSettings.newTimeOffset < 0) {
        if ((TimeSettings.newTimeOffset / 60) > -10) {
            timeZoneHour = '-0' + (-TimeSettings.newTimeOffset / 60); // in hour
        } else {
            timeZoneHour = '-' + (-TimeSettings.newTimeOffset / 60); // in hour
        }
    } else {
        timeZoneHour = '-00';
    }

    // Font Faker
    Object.defineProperties(HTMLElement.prototype, {
        offsetWidth: {
            get: function() {
                return this.getBoundingClientRect().width;
            }
        },
    });
    // Font Faker -- END

    // AudioContext Faker
    const context = {
        "BUFFER": null,
        "getChannelData": function(e) {
            const getChannelData = e.prototype.getChannelData;
            Object.defineProperty(e.prototype, "getChannelData", {
                "value": function() {
                    const results_1 = getChannelData.apply(this, arguments);
                    if (context.BUFFER !== results_1) {
                        context.BUFFER = results_1;
                        for (let i = 0; i < results_1.length; i += 100) {
                            let idx = Math.floor(Math.random() * i);
                            results_1[idx] = results_1[idx] + randValue.rand1 * 0.0000001;
                        }
                    }
                    //
                    return results_1;
                }
            });
        },
        "createAnalyser": function(e) {
            const createAnalyser = e.prototype.__proto__.createAnalyser;
            Object.defineProperty(e.prototype.__proto__, "createAnalyser", {
                "value": function() {
                    const results_2 = createAnalyser.apply(this, arguments);
                    const getFloatFrequencyData = results_2.__proto__.getFloatFrequencyData;
                    Object.defineProperty(results_2.__proto__, "getFloatFrequencyData", {
                        "value": function() {
                            const results_3 = getFloatFrequencyData.apply(this, arguments);
                            for (let i = 0; i < arguments[0].length; i += 100) {
                                let idx = Math.floor(Math.random() * i);
                                arguments[0][idx] = arguments[0][idx] + randValue.rand2 * 0.1;
                            }
                            //
                            return results_3;
                        }
                    });
                    //
                    return results_2;
                }
            });
        }
    };
    //
    context.getChannelData(AudioBuffer);
    context.createAnalyser(AudioContext);
    context.getChannelData(OfflineAudioContext);
    context.createAnalyser(OfflineAudioContext);

    // WebGL Faker
    const isWebGL2 = (Object.keys(Browser.WebGLInfo2).length !== 0);

    WebGLRenderingContext.prototype.getParameter = function(origFn) {
        const pm = {};
        pm[0x9245] = Browser.WebGLInfo.unMaskedVendor;
        pm[0x9246] = Browser.WebGLInfo.unMaskedRenderer;
        pm[0x1F00] = Browser.WebGLInfo.vendor;
        pm[0x1F01] = Browser.WebGLInfo.renderer;
        pm[0x1F02] = Browser.WebGLInfo.glVersion;
        pm[0x8B8C] = Browser.WebGLInfo.shadingLanguageVersion;

        return function(parameter) {
            return pm[parameter] || origFn.call(this, parameter);
        };
    }(WebGLRenderingContext.prototype.getParameter);

    WebGLRenderingContext.prototype.getSupportedExtensions = function() {
        return function() {
            return Browser.WebGLInfo.extensions;
        };
    }();

    // WebGL2 - defined ???
    if (isWebGL2) {
        // WebGL2 - YES

        WebGL2RenderingContext.prototype.getSupportedExtensions = function() {
            return function() {
                return Browser.WebGLInfo2.extensions;
            };
        }();

        WebGL2RenderingContext.prototype.getParameter = function(origFn) {
            const pm = {};
            pm[0x9245] = Browser.WebGLInfo2.unMaskedVendor;
            pm[0x9246] = Browser.WebGLInfo2.unMaskedRenderer;
            pm[0x1F00] = Browser.WebGLInfo2.vendor;
            pm[0x1F01] = Browser.WebGLInfo2.renderer;
            pm[0x1F02] = Browser.WebGLInfo2.glVersion;
            pm[0x8B8C] = Browser.WebGLInfo2.shadingLanguageVersion;

            return function(parameter) {
                return pm[parameter] || origFn.call(this, parameter);
            };
        }(WebGL2RenderingContext.prototype.getParameter);

    } else {
        // WebGL2 - NO

        HTMLCanvasElement.prototype.getContext = function(origFn) {
            return function(parameter) {
                if (parameter === 'webgl2') {
                    return undefined;
                }
                return origFn.call(this, parameter);
            };
        }(HTMLCanvasElement.prototype.getContext);

        WebGL2RenderingContext.prototype.webgl2Functions = function() {
            return function() {
                return Browser.WebGLInfo2.webgl2Functions;
            };
        }();
    }

    // Data Faker
    definePropFunc(Intl.DateTimeFormat.prototype, "format", function() {
        return (new Date()).toString();
    });

    Intl.DateTimeFormat.prototype.resolvedOptions = function() {
        return function() {
            return {
                calendar: "gregory",
                day: "2-digit",
                locale: Languages.lang,
                month: "2-digit",
                numberingSystem: "latn",
                timeZone: TimeSettings.timeZoneV,
                year: "numeric",
                hourCycle: 'h23',
            };
        };
    }();

    Intl.NumberFormat.prototype.resolvedOptions = function() {
        return function() {
            return {
                locale: Languages.lang,
                maximumFractionDigits: 3,
                minimumFractionDigits: 0,
                minimumIntegerDigits: 1,
                notation: "standard",
                numberingSystem: "latn",
                signDisplay: "auto",
                style: "decimal",
                useGrouping: true
            };
        };
    }();

    Intl.DisplayNames.prototype.resolvedOptions = function() {
        return function() {
            return {
                fallback: "code",
                locale: Languages.lang,
                style: "long",
                type: "language"
            };
        };
    }();

    Intl.ListFormat.prototype.resolvedOptions = function() {
        return function() {
            return {
                locale: Languages.lang,
                style: "long",
                type: "conjunction"
            };
        };
    }();

    Intl.RelativeTimeFormat.prototype.resolvedOptions = function() {
        return function() {
            return {
                locale: Languages.lang,
                style: "long",
                numberingSystem: "latn",
                numeric: "always"
            };
        };
    }();

    Intl.PluralRules.prototype.resolvedOptions = function() {
        return function() {
            return {
                locale: Languages.lang,
                maximumFractionDigits: 3,
                minimumFractionDigits: 0,
                minimumIntegerDigits: 1,
                pluralCategories: ["few", "many", "one", "other"]
            };
        };
    }();

    // DateTime Faker
    (function() {
        const offsetDate = new Date();
        Date.prototype.timezoneOffset = offsetDate.getTimezoneOffset();

        Date.setTimezoneOffset = function(timezoneOffset) {
            return this.prototype.timezoneOffset = timezoneOffset;
        };
        // Date.prototype.setTimezoneOffset = function (timezoneOffset) {
        //     return this.timezoneOffset = timezoneOffset;
        // };

        Date.getTimezoneOffset = function() {
            return this.prototype.timezoneOffset;
        };
        // Date.prototype.getTimezoneOffset = function () {
        //     return this.timezoneOffset;
        // };

        Date.prototype.toString = function() {
            const offsetTime = this.timezoneOffset * 60 * 1000;
            offsetDate.setTime(this.getTime() - offsetTime);
            if (timeZoneHour.toString() === '-00') {
                timeZoneHour = '00';
            }
            return offsetDate.toUTCString() + timeZoneHour.toString() + '00';
        };

        Date.toString = function() {
            const offsetTime = this.timezoneOffset * 60 * 1000;
            offsetDate.setTime(this.getTime() - offsetTime);
            if (timeZoneHour.toString() === '-00') {
                timeZoneHour = '00';
            }
            return offsetDate.toUTCString() + timeZoneHour.toString() + '00';
        };

        function dateToString() {
            const d1 = new Date();

            let date = d1.getDate();
            let month = d1.getMonth();
            let year = d1.getFullYear();

            let hours = d1.getHours();
            let minutes = d1.getMinutes();
            let seconds = d1.getSeconds();

            if (date < 10) date = '0' + date;
            if (month < 10) month = '0' + month;
            if (hours < 10) hours = '0' + hours;
            if (minutes < 10) minutes = '0' + minutes;
            if (seconds < 10) seconds = '0' + seconds;

            return date + '.' + month + '.' + year + ' ' + hours + ':' + minutes + ':' + seconds;
        }

        Date.prototype.toLocaleString = function() {
            return dateToString();
        };

        Date.toLocaleString = function() {
            return dateToString();
        };

        function timeToString() {
            const d1 = new Date();
            let hours = d1.getHours();
            let minutes = d1.getMinutes();
            let seconds = d1.getSeconds();

            if (hours < 10) hours = '0' + hours;
            if (minutes < 10) minutes = '0' + minutes;
            if (seconds < 10) seconds = '0' + seconds;

            return hours + ':' + minutes + ':' + seconds;
        }

        // Date.prototype.toLocaleTimeString = function () {
        //     return timeToString();
        // };

        Date.toLocaleTimeString = function() {
            return timeToString();
        };

        return ['Milliseconds', 'Seconds', 'Minutes', 'Hours', 'Date', 'Month', 'Year', 'FullYear', 'Day'].forEach((function(_this) {
            return function(key) {

                Date.prototype["get" + key] = function() {
                    try {
                        const offsetTime = this.timezoneOffset * 60 * 1000;
                        offsetDate.setTime(this.getTime() - offsetTime);
                        return offsetDate["getUTC" + key]();
                    } catch (e) {}
                };

                return Date.prototype["set" + key] = function(value) {
                    try {
                        const offsetTime = this.timezoneOffset * 60 * 1000;
                        offsetDate.setTime(this.getTime() - offsetTime);
                        offsetDate["setUTC" + key](value);
                        const time = offsetDate.getTime() + offsetTime;
                        this.setTime(time);
                        return time;
                    } catch (e) {}
                };
            };
        })(this));
    })();

    Date.setTimezoneOffset(timeZone);

    document.documentElement.dataset.cbsal = true;
}

// Inject to page
getConfig().then(function(config) {

    const pluginID = chrome.runtime.id;

    // let ipInfo = document.documentElement.dataset.DC;
    // ipInfo += document.documentElement.dataset.PRX;
    // ipInfo += document.documentElement.dataset.MLW;
    // ipInfo += document.documentElement.dataset.CRW;

    let IP = document.documentElement.dataset.IP;
    let isMin = document.documentElement.dataset.ismin;

    function hideIPWindow() {
        let el = document.getElementById("showIPJS2020");
        if (typeof el !== 'undefined' && el !== null) {
            el.parentNode.removeChild(el);
        }
    }

    function showIPWindow() {

        let el = document.getElementById("showIPJS2020");

        if (typeof el !== 'undefined' && el !== null) {
            el.parentNode.removeChild(el);
        }

        try {
            // let colorBgRed = 'rgba(209, 97, 97, 0.6)';
            let colorBgGreen = 'rgba(142, 185, 121, 0.6)';
            let imgURL = 'chrome-extension://' + pluginID + '/flags/' + document.documentElement.dataset.cc.toLowerCase() + '.png';
            let flag = '<img alt="" style="width:18px; vertical-align: middle; border-style: none;" src="' + imgURL + '">';

            let ipInfo = document.documentElement.dataset.DC;
            ipInfo += document.documentElement.dataset.PRX;
            ipInfo += document.documentElement.dataset.MLW;
            ipInfo += document.documentElement.dataset.CRW;

            let textDisplayParam = '`<div style="all: unset;"><strong>' + document.documentElement.dataset.prjname + '</strong><br /><br />' + document.documentElement.dataset.IP + '<br /> ' + document.documentElement.dataset.Country + '&nbsp;' + flag + '<br /><span style="color: red; "><b>' + ipInfo + '</span></div>`, `#323232`, `' + colorBgGreen + '`';

            if (document.documentElement.dataset.ismin === '1') {
                textDisplayParam = '`<div style="all: unset;"><strong>' + document.documentElement.dataset.prjname + '</strong>&nbsp;' + flag + '</div>`';
            }

            const script_display = document.createElement('script');
            script_display.textContent = '(' + _display + ')(' + textDisplayParam + ')';
            (document.head || document.documentElement).appendChild(script_display);
            script_display.remove();
        } catch (e) {
            console.debug(e);
        }
    }

    const _display = (html, textColor = '#000000', bgColor = 'rgba(142, 185, 121, 0.6)') => {

        // let ipInfo = document.documentElement.dataset.DC;
        // ipInfo += document.documentElement.dataset.PRX;
        // ipInfo += document.documentElement.dataset.MLW;
        // ipInfo += document.documentElement.dataset.CRW;

        // No iFrame
        try {
            if (window.self !== window.top) {
                return;
            }
        } catch (e) {
            return;
        }

        const el = document.createElement('div');
        el.id = "showIPJS2020";
        el.innerHTML = html;

        el.style.display = 'flex';
        el.style.width = '140px';
        el.style.height = '80px';
        el.style.fontSize = '12px';
        el.style.fontFamily = 'arial';
        el.style.justifyContent = 'center';
        el.style.verticalAlign = 'center';
        el.style.alignItems = 'center';
        el.style.textAlign = 'center';
        // el.style.padding = '20px';
        el.style.position = 'fixed';
        el.style.bottom = '20px';
        el.style.right = '20px';
        el.style.borderRadius = '5px';
        el.style.zIndex = '99999999';
        el.style.lineHeight = '1';
        el.style.overflow = 'hidden';
        el.style.cursor = 'move';
        el.style.boxSizing = 'content-box';

        el.style.color = textColor;
        el.style.backgroundColor = bgColor;

        if (document.documentElement.dataset.ismin === '0') {
            // el.style.padding = '20px';
            // el.style.width = '200px'

            el.style.height = '80px';
            el.style.width = '140px';

            // if (ipInfo.length > 0 && ipInfo.length <= 15) {
            //     el.style.height = '80px';
            //     el.style.width = '140px';
            // } else if (ipInfo.length > 15 && ipInfo.length <= 20) {
            //     el.style.height = '80px';
            //     el.style.width = '140px';
            // } else if (ipInfo.length > 20) {
            //     el.style.height = '70px';
            //     el.style.width = '140px';
            // } else {
            //     el.style.height = '50px';
            // }
            //
            // el.style.height = '70px';
            // el.style.width = '140px';

        } else {
            // el.style.padding = '5px';
            el.style.width = '140px'
            el.style.height = '35px';
        }

        const dragElement = (elmnt) => {
            let pos1 = 0,
                pos2 = 0,
                pos3 = 0,
                pos4 = 0;
            if (document.getElementById(elmnt.id + "header")) {
                document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
            } else {
                elmnt.onmousedown = dragMouseDown;
            }

            // elmnt.ondblclick = elementClick;

            function dragMouseDown(e) {
                e = e || window.event;
                e.preventDefault();
                pos3 = e.clientX;
                pos4 = e.clientY;
                document.onmouseup = closeDragElement;
                document.onmousemove = elementDrag;
            }

            // function elementClick(e) {
            //     e = e || window.event;
            //     e.preventDefault();
            //     if (document.documentElement.dataset.ismin === '0') {
            //         document.documentElement.dataset.ismin = '1';
            //     } else {
            //         document.documentElement.dataset.ismin = '0';
            //     }
            // }

            function elementDrag(e) {
                e = e || window.event;
                e.preventDefault();
                pos1 = pos3 - e.clientX;
                pos2 = pos4 - e.clientY;
                pos3 = e.clientX;
                pos4 = e.clientY;
                elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
                elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
            }

            function closeDragElement() {
                document.onmouseup = null;
                document.onmousemove = null;
            }
        };

        dragElement(el);
        (document.body || document.documentElement.body || document.documentElement || document.head).appendChild(el);

    };

    if (isPlgOn === '1') {
        showIPWindow();
    }

    let isPlgOnPrev = isPlgOn;
    let isPlgShowPrev = isPlgShow;
    let prevStatePlgShow = isPlgShow;
    setInterval(function() {

        if (isPlgOnPrev !== isPlgOn || isPlgShowPrev !== isPlgShow) {
            if (isPlgOn === '1' && isPlgShow === '1') {
                showIPWindow();
            } else {
                hideIPWindow();
            }
            isPlgOnPrev = isPlgOn;
            isPlgShowPrev = isPlgShow;
        }

        if (isPlgOn === '1') {
            if (IP !== document.documentElement.dataset.IP || isMin !== document.documentElement.dataset.ismin) {
                showIPWindow();
                IP = document.documentElement.dataset.IP;
                isMin = document.documentElement.dataset.ismin;
            }
        }
    }, 100);

    document.addEventListener("fullscreenchange", function() {
        if (document.fullscreenElement) {
            prevStatePlgShow = isPlgShow;
            isPlgShow = '0';
        } else {
            isPlgShow = prevStatePlgShow;
        }
    });

    // Inject code into page
    try {
        const script = document.createElement('script');
        script.id = Math.floor(Math.random() * 10000).toString();
        script.type = "text/javascript";
        const newChild = document.createTextNode('try{(' + inject + ')(' + JSON.stringify(config) + ', ' + JSON.stringify(Profile) + ', ' + JSON.stringify(shift) + ', ' + JSON.stringify(rand) + ');} catch(e) {console.error(e);}');
        script.appendChild(newChild);
        const node = (document.documentElement || document.documentElement.body || document.head || document.body);
        node.insertBefore(script, node.firstChild);
        // script_1.remove();
    } catch (e) {
        console.error(e);
    }

});

if (document.documentElement.dataset.cbsal !== "true") {
    try {
        let script_2 = document.createElement('script');
        script_2.textContent = `{
    const iframes = window.top.document.querySelectorAll("iframe");
    for (let i = 0; i < iframes.length; i++)
    {
        if (iframes[i].contentWindow)
        {
            if (iframes[i].contentWindow.AudioBuffer)
            {
                if (iframes[i].contentWindow.AudioBuffer.prototype)
                {
                    if (iframes[i].contentWindow.AudioBuffer.prototype.getChannelData)
                    {
                        iframes[i].contentWindow.AudioBuffer.prototype.getChannelData = AudioBuffer.prototype.getChannelData;
                    }
                }
            }

            if (iframes[i].contentWindow.AudioContext)
            {
                if (iframes[i].contentWindow.AudioContext.prototype)
                {
                    if (iframes[i].contentWindow.AudioContext.prototype.__proto__)
                    {
                        if (iframes[i].contentWindow.AudioContext.prototype.__proto__.createAnalyser)
                        {
                            iframes[i].contentWindow.AudioContext.prototype.__proto__.createAnalyser = AudioContext.prototype.__proto__.createAnalyser;
                        }
                    }
                }
            }

            if (iframes[i].contentWindow.OfflineAudioContext)
            {
                if (iframes[i].contentWindow.OfflineAudioContext.prototype)
                {
                    if (iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__)
                    {
                        if (iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__.createAnalyser)
                        {
                            iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__.createAnalyser = OfflineAudioContext.prototype.__proto__.createAnalyser;
                        }
                    }
                }
            }

            if (iframes[i].contentWindow.OfflineAudioContext)
            {
                if (iframes[i].contentWindow.OfflineAudioContext.prototype)
                {
                    if (iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__)
                    {
                        if (iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__.getChannelData)
                        {
                            iframes[i].contentWindow.OfflineAudioContext.prototype.__proto__.getChannelData = OfflineAudioContext.prototype.__proto__.getChannelData;
                        }
                    }
                }
            }
        }

        if (iframes[i].contentWindow.HTMLElement)
        {
            try {
                iframes[i].contentWindow.HTMLElement.prototype.offsetWidth = HTMLElement.prototype.offsetWidth;
                iframes[i].contentWindow.HTMLElement.prototype.offsetHeight = HTMLElement.prototype.offsetHeight;
            } catch (e) {
            }
        }

        if (iframes[i].contentWindow.HTMLCanvasElement)
        {
            let tb = iframes[i].contentWindow.HTMLCanvasElement.prototype.toBlob;
            if (tb !== HTMLCanvasElement.prototype.toBlob)
            {
                try {
                    iframes[i].contentWindow.HTMLCanvasElement.prototype.toBlob = HTMLCanvasElement.prototype.toBlob;
                    iframes[i].contentWindow.HTMLCanvasElement.prototype.toDataURL = HTMLCanvasElement.prototype.toDataURL;
                    //iframes[i].contentWindow.CanvasRenderingContext2D.prototype.getImageData = CanvasRenderingContext2D.prototype.getImageData;
                } catch (e) {
                }
            }
        }

        iframes[i].Worker = null;
        iframes[i].ServiceWorkerContainer = null;
        iframes[i].SharedWorker = null;
        iframes[i].serviceWorker = null;
    }
}`;
        window.top.document.documentElement.appendChild(script_2);
        script_2.remove();
    } catch (e) {}
}