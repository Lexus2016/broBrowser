window.onload = function() {
    var el = document.getElementById('saveButton');
    if (el) {
        el.addEventListener('click', saveButtonHandler, false);
    }

    setForm();
}

function saveButtonHandler() {

    let config = {
        on: document.getElementById('on').value,
        minimized: document.getElementById('minimized').value,
        block: document.getElementById('block').value,
        show: '1'
    }

    chrome.storage.local.set({
        'fkIPSettingsPlugin': config
    });

    alert('Saved');
    window.close();
}

function setForm() {
    chrome.storage.local.get(['fkIPSettingsPlugin'], (elems) => {
        if (!chrome.runtime.lastError) {

            try {
                var el = document.getElementById('on');
                if (el) {
                    el.value = elems['fkIPSettingsPlugin']['on'].toString();
                }

                el = document.getElementById('minimized');
                if (el) {
                    el.value = elems['fkIPSettingsPlugin']['minimized'].toString();
                }

                el = document.getElementById('block');
                if (el) {
                    el.value = elems['fkIPSettingsPlugin']['block'].toString();
                }
            } catch (e) {}

        }
    });
}