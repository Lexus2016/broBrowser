
let ipMismatchAlert = true;

let globalIP = '0.0.0.0';
let globalLang = '';
let globalCountry = '';
let globalCountryCode = '';
let globalLangs = {};
let globalTimeZone = '';
let globalTimeShift = '';

let startTimer = new Date().getTime();
let endTimer = startTimer * 10;
let fetchPeriod = 1000; //msec
const fetchPeriodCycle = 500; //msec

let goodJob = true;

let isFirstStart = true;
let alertShow = false;

function getPlgSettings() {
    chrome.storage.local.get(['fkIPSettingsPlugin'], (elems) => {
        if (!chrome.runtime.lastError) {
            try {
                isPlgOn = elems['fkIPSettingsPlugin']['on'].toString();
                isPlgMinimzed = elems['fkIPSettingsPlugin']['minimized'].toString();
                isPlgBlock = elems['fkIPSettingsPlugin']['block'].toString();
                isPlgShow = elems['fkIPSettingsPlugin']['show'].toString();
            } catch (e) {

                let config = {
                    on: isPlgOn,
                    minimized: isPlgMinimzed,
                    block: isPlgBlock,
                    show: isPlgShow
                }

                chrome.storage.local.set({
                    'fkIPSettingsPlugin': config
                });
            }
        }

    });
}

function toggleShowPlugin(show = '') {

    if (show === '') {
        isPlgShow = (isPlgShow === '1') ? '0' : '1';
    } else {
        isPlgShow = show;
    }

    let config = {
        on: isPlgOn,
        minimized: isPlgMinimzed,
        block: isPlgBlock,
        show: isPlgShow
    }

    chrome.storage.local.set({
        'fkIPSettingsPlugin': config
    });
}

function toggleMinMaxPlugin() {
    isPlgMinimzed = (isPlgMinimzed === '1') ? '0' : '1';
    let config = {
        on: isPlgOn,
        minimized: isPlgMinimzed,
        block: isPlgBlock,
        show: isPlgShow
    }

    chrome.storage.local.set({
        'fkIPSettingsPlugin': config
    });
}


setInterval(async function () {
    getPlgSettings()
}, 1000);

function getConfig() {
    return new Promise((resolve) => {
        if ((endTimer - startTimer) < fetchPeriod) {
            endTimer = new Date().getTime();
            resolve();
            return;
        }

        startTimer = new Date().getTime();
        endTimer = new Date().getTime();

        resolve(getLocales());
    });
}

function getLocales() {
    return Promise.all([
        fetch(CheckURL + new Date().getTime())
    ]).then(data => Promise.all(data.map(el => el.text()))).then(arr => {

        let jsONARR = JSON.parse(arr[0]);
        let ip = jsONARR[0];
        let timeZoneV = jsONARR[1];
        let newTimeOffset = parseInt(jsONARR[2]) / 100 * 60;
        let langsT = jsONARR[3].split(',', 2);
        let langs = Array.from(new Set(langsT));
        let countryCode = jsONARR[4];
        let country = jsONARR[5];
        let isDC = jsONARR[7] === '1' ? '[DC]' : '';
        let isProxy = jsONARR[15] === '1' ? '[Proxy]' : '';
        let isMalware = jsONARR[16] === '1' ? '[Suspicious]' : '';
        let isCrawler = jsONARR[17] === '1' ? '[Crawler]' : '';
        let connectionType = jsONARR[8];

        Languages.lang = langs[0];
        Languages.langs = langs;

        TimeSettings.newTimeOffset = newTimeOffset;
        TimeSettings.timeZoneV = timeZoneV;

        // Profile.global.IP = ip;
        // Profile.global.Country = Country;

        let resultObj = {
            'ip': ip,
            'timeZoneV': timeZoneV,
            'newTimeOffset': newTimeOffset,
            'lang': langs[0],
            'langs': langs,
            'country': country,
            'countryCode': countryCode,
            'isDC': isDC,
            'isProxy': isProxy,
            'isMalware': isMalware,
            'isCrawler': isCrawler,
            'connectionType': connectionType
        };

        chrome.storage.local.set({
            'fkConfig': resultObj
        });

        if (globalIP !== ip && globalIP !== '0.0.0.0') {
            // console.log("WARNING! IP changed!\n\nIP: " + globalIP + ' => ' + ip + "\nTimeZone: " + globalTimeZone + ' => ' + timeZoneV + "\nTimeOffset: " + globalTimeShift + ' => ' + newTimeOffset + "\nLanguage: " + globalLang + ' => ' + langs[0]);
            if (ipMismatchAlert && !alertShow) {
                alertShow = true;
                alert("WARNING! IP changed!\n\nIP: " + globalIP + ' => ' + ip + "\nTimeZone: " + globalTimeZone + ' => ' + timeZoneV + "\nTimeOffset: " + globalTimeShift + ' => ' + newTimeOffset + "\nLanguage: " + globalLang + ' => ' + langs[0]);
            }

            goodJob = false;
        } else {
            alertShow = false;
            goodJob = true;
        }

        if (globalIP === '0.0.0.0') {
            globalIP = ip;
            globalTimeZone = timeZoneV;
            globalTimeShift = newTimeOffset;
            globalLang = langs[0];
            globalLangs = langs;
            globalCountry = country;
            globalCountryCode = countryCode;
        }

    });
};

setTimeout(async function () {
    await getLocales();
}, 1);

setInterval(async function () {
    await getLocales();
}, fetchPeriodCycle);

const onTabs = () => {
    getConfig();
    getPlgSettings();
};

const onCreateNewWindow = () => {
    getConfig();
    getPlgSettings();
};

function sleepFor(sleepDuration) {
    const now = new Date().getTime() + sleepDuration;
    while (new Date().getTime() < now) {
    }
}

chrome.webRequest.onBeforeRequest.addListener(
    // async details => {
    details => {
        // IP no change?
        if (!goodJob) {
            const urlRequest = new URL(details.url).hostname;
            const urlChecker = new URL(CheckURL).hostname;
            if (urlRequest !== urlChecker && urlRequest !== "localhost" && urlChecker !== "127.0.0.1") {
                return {
                    // redirectUrl:"javascript:",
                    cancel: true
                };
            }
        }

        return {
            cancel: false
        };

    }, {
        urls: ['<all_urls>']
    }, ['blocking']
);

chrome.webRequest.onBeforeSendHeaders.addListener(
    function (details) {

        for (let i = 0; i < details.requestHeaders.length; ++i) {
            if (details.requestHeaders[i].name.toLocaleLowerCase() === 'user-agent') {
                details.requestHeaders[i].value = Profile.navigator.userAgent;
            } else if (details.requestHeaders[i].name.toLocaleLowerCase() === 'accept-language') {
                details.requestHeaders[i].value = Languages.langs.join(',') + ';q=0.9';
            } else if (details.requestHeaders[i].name.toLocaleLowerCase() === 'dnt') {
                details.requestHeaders[i].value = '1';
            }
        }

        return {
            requestHeaders: details.requestHeaders
        };
    }, {
        urls: ['<all_urls>']
    }, ['requestHeaders', 'extraHeaders', 'blocking']
);

// chrome.tabs.getSelected(null, function(tab) {
//   var code = 'window.location.reload();';
//   chrome.tabs.executeScript(tab.id, {code: code});
// });

chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
  chrome.tabs.update(tabs[0].id, {url: tabs[0].url});
  // chrome.tabs.update(tabs[0].id, {active: true, highlighted: true, url: tabs[0].url});
  // chrome.tabs.reload(tabs[0].id);
});

chrome.tabs.onActivated.addListener(onTabs);
chrome.tabs.onUpdated.addListener(onTabs);
chrome.tabs.onCreated.addListener(onTabs);

chrome.commands.onCommand.addListener(function (command) {
    if (command === 'show_or_hide_badge') {
        toggleShowPlugin();
    } else if (command === 'minimize_maximize_badge') {
        toggleMinMaxPlugin();
    }
});

chrome.windows.onCreated.addListener(onCreateNewWindow);