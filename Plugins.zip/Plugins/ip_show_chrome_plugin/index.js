// Get Config from LocalStorage
function getConfig() {
    return new Promise((resolve) => {
        // Get Profile
        chrome.storage.local.get(['fkIPConfig'], (elems) => {
            if (!chrome.runtime.lastError) {
                SetFkbrConfig(elems['fkIPConfig']);
                resolve(elems['fkIPConfig']);
            }
        });
    });
}

function getPlgConfig() {
    // Get Plugin Settings
    chrome.storage.local.get(['fkIPSettingsPlugin'], (elems) => {
        if (!chrome.runtime.lastError) {
            SetFkbrPlgConfig(elems['fkIPSettingsPlugin']);
        }
    });
}

function SetFkbrConfig(config) {
    document.documentElement.dataset.IP = config['ip'];
    document.documentElement.dataset.Country = config['country'];
    document.documentElement.dataset.cc = config['countryCode'];
    document.documentElement.dataset.DC = config['isDC'];
    document.documentElement.dataset.PRX = config['isProxy'];
    document.documentElement.dataset.MLW = config['isMalware'];
    document.documentElement.dataset.CRW = config['isCrawler'];
    document.documentElement.dataset.ct = config['connectionType'];
    document.documentElement.dataset.prjname = Profile['name'];
}

function SetFkbrPlgConfig(config) {
    try {
        isPlgOn = config['on'];
        isPlgBlock = config['block'];
        isPlgMinimzed = config['minimized'];
        isPlgShow = config['show'];
    } catch (e) {
        isPlgOn = '1';
        isPlgBlock = '0';
        isPlgMinimzed = '0';
        isPlgShow = '1';
    }
    document.documentElement.dataset.ismin = isPlgMinimzed;
}

// Change IP
chrome.storage.onChanged.addListener(function () {
    getConfig();
    getPlgConfig();
});

getPlgConfig();

// Inject to page
getConfig().then(function () {

    const pluginID = chrome.runtime.id;

    // let ipInfo = document.documentElement.dataset.DC;
    // ipInfo += document.documentElement.dataset.PRX;
    // ipInfo += document.documentElement.dataset.MLW;
    // ipInfo += document.documentElement.dataset.CRW;

    let IP = document.documentElement.dataset.IP;
    let isMin = document.documentElement.dataset.ismin;

    function hideIPWindow() {
        let el = document.getElementById("showIPJS2020");
        if (typeof el !== 'undefined' && el !== null) {
            el.parentNode.removeChild(el);
        }
    }

    function showIPWindow() {

        let el = document.getElementById("showIPJS2020");

        if (typeof el !== 'undefined' && el !== null) {
            el.parentNode.removeChild(el);
        }

        try {
            // let colorBgRed = 'rgba(209, 97, 97, 0.6)';
            let colorBgGreen = 'rgba(142, 185, 121, 0.6)';
            let imgURL = 'chrome-extension://' + pluginID + '/flags/' + document.documentElement.dataset.cc.toLowerCase() + '.png';
            let flag = '<img alt="" style="width:18px; vertical-align: middle; border-style: none;" src="' + imgURL + '">';

            let ipInfo = document.documentElement.dataset.DC;
            ipInfo += document.documentElement.dataset.PRX;
            ipInfo += document.documentElement.dataset.MLW;
            ipInfo += document.documentElement.dataset.CRW;

            let textDisplayParam = '`<div style="all: unset;"><strong>' + document.documentElement.dataset.prjname + '</strong><br /><br />' + document.documentElement.dataset.IP + '<br /> ' + document.documentElement.dataset.Country + '&nbsp;' + flag + '<br /><span style="color: red; "><b>' + ipInfo + '</span></div>`, `#323232`, `' + colorBgGreen + '`';

            if (document.documentElement.dataset.ismin === '1') {
                textDisplayParam = '`<div style="all: unset;"><strong>' + document.documentElement.dataset.prjname + '</strong>&nbsp;' + flag + '</div>`';
            }

            const script_display = document.createElement('script');
            script_display.textContent = '(' + _display + ')(' + textDisplayParam + ')';
            (document.head || document.documentElement).appendChild(script_display);
            script_display.remove();
        } catch (e) {
            console.debug(e);
        }
    }

    const _display = (html, textColor = '#000000', bgColor = 'rgba(142, 185, 121, 0.6)') => {

        // let ipInfo = document.documentElement.dataset.DC;
        // ipInfo += document.documentElement.dataset.PRX;
        // ipInfo += document.documentElement.dataset.MLW;
        // ipInfo += document.documentElement.dataset.CRW;

        // No iFrame
        try {
            if (window.self !== window.top) {
                return;
            }
        } catch (e) {
            return;
        }

        const el = document.createElement('div');
        el.id = "showIPJS2020";
        el.innerHTML = html;

        el.style.display = 'flex';
        el.style.width = '140px';
        el.style.height = '80px';
        el.style.fontSize = '12px';
        el.style.fontFamily = 'arial';
        el.style.justifyContent = 'center';
        el.style.verticalAlign = 'center';
        el.style.alignItems = 'center';
        el.style.textAlign = 'center';
        // el.style.padding = '20px';
        el.style.position = 'fixed';
        el.style.bottom = '20px';
        el.style.right = '20px';
        el.style.borderRadius = '5px';
        el.style.zIndex = '99999999';
        el.style.lineHeight = '1';
        el.style.overflow = 'hidden';
        el.style.cursor = 'move';
        el.style.boxSizing = 'content-box';

        el.style.color = textColor;
        el.style.backgroundColor = bgColor;

        if (document.documentElement.dataset.ismin === '0') {
            // el.style.padding = '20px';
            // el.style.width = '200px'

            el.style.height = '80px';
            el.style.width = '140px';

            // if (ipInfo.length > 0 && ipInfo.length <= 15) {
            //     el.style.height = '80px';
            //     el.style.width = '140px';
            // } else if (ipInfo.length > 15 && ipInfo.length <= 20) {
            //     el.style.height = '80px';
            //     el.style.width = '140px';
            // } else if (ipInfo.length > 20) {
            //     el.style.height = '70px';
            //     el.style.width = '140px';
            // } else {
            //     el.style.height = '50px';
            // }
            //
            // el.style.height = '70px';
            // el.style.width = '140px';

        } else {
            // el.style.padding = '5px';
            el.style.width = '140px'
            el.style.height = '35px';
        }

        const dragElement = (elmnt) => {
            let pos1 = 0,
                pos2 = 0,
                pos3 = 0,
                pos4 = 0;
            if (document.getElementById(elmnt.id + "header")) {
                document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
            } else {
                elmnt.onmousedown = dragMouseDown;
            }

            // elmnt.ondblclick = elementClick;

            function dragMouseDown(e) {
                e = e || window.event;
                e.preventDefault();
                pos3 = e.clientX;
                pos4 = e.clientY;
                document.onmouseup = closeDragElement;
                document.onmousemove = elementDrag;
            }

            // function elementClick(e) {
            //     e = e || window.event;
            //     e.preventDefault();
            //     if (document.documentElement.dataset.ismin === '0') {
            //         document.documentElement.dataset.ismin = '1';
            //     } else {
            //         document.documentElement.dataset.ismin = '0';
            //     }
            // }

            function elementDrag(e) {
                e = e || window.event;
                e.preventDefault();
                pos1 = pos3 - e.clientX;
                pos2 = pos4 - e.clientY;
                pos3 = e.clientX;
                pos4 = e.clientY;
                elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
                elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
            }

            function closeDragElement() {
                document.onmouseup = null;
                document.onmousemove = null;
            }
        };

        dragElement(el);
        (document.body || document.documentElement.body || document.documentElement || document.head).appendChild(el);

    };

    if (isPlgOn === '1') {
        showIPWindow();
    }

    let isPlgOnPrev = isPlgOn;
    let isPlgShowPrev = isPlgShow;
    let prevStatePlgShow = isPlgShow;
    setInterval(function () {

        if (isPlgOnPrev !== isPlgOn || isPlgShowPrev !== isPlgShow) {
            if (isPlgOn === '1' && isPlgShow === '1') {
                showIPWindow();
            } else {
                hideIPWindow();
            }
            isPlgOnPrev = isPlgOn;
            isPlgShowPrev = isPlgShow;
        }

        if (isPlgOn === '1') {
            if (IP !== document.documentElement.dataset.IP || isMin !== document.documentElement.dataset.ismin) {
                showIPWindow();
                IP = document.documentElement.dataset.IP;
                isMin = document.documentElement.dataset.ismin;
            }
        }
    }, 100);

    document.addEventListener("fullscreenchange", function () {
        if (document.fullscreenElement) {
            prevStatePlgShow = isPlgShow;
            isPlgShow = '0';
        } else {
            isPlgShow = prevStatePlgShow;
        }
    });
});