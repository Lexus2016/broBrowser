
const fetchPeriod = 2000; //msec
const fetchPeriodCycle = 500; //msec

let ipMismatchAlert = true;
let goodJob = true;

let globalIP = '0.0.0.0';
let globalLang = '';
let globalCountry = '';
let globalCountryCode = '';
let globalLangs = {};
let globalTimeZone = '';
let globalTimeShift = '';

let startTimer = new Date().getTime();
let endTimer = startTimer * 10;

function getPlgSettings() {
    chrome.storage.local.get(['fkIPSettingsPlugin'], (elems) => {
        if (!chrome.runtime.lastError) {
            try {
                isPlgOn = elems['fkIPSettingsPlugin']['on'].toString();
                isPlgMinimzed = elems['fkIPSettingsPlugin']['minimized'].toString();
                isPlgBlock = elems['fkIPSettingsPlugin']['block'].toString();
                isPlgShow = elems['fkIPSettingsPlugin']['show'].toString();
            } catch (e) {

                let config = {
                    on: isPlgOn,
                    minimized: isPlgMinimzed,
                    block: isPlgBlock,
                    show: isPlgShow
                }

                chrome.storage.local.set({
                    'fkIPSettingsPlugin': config
                });
            }
        }

    });
}

function toggleShowPlugin(show = '') {

    if (show === '') {
        isPlgShow = (isPlgShow === '1') ? '0' : '1';
    } else {
        isPlgShow = show;
    }

    let config = {
        on: isPlgOn,
        minimized: isPlgMinimzed,
        block: isPlgBlock,
        show: isPlgShow
    }

    chrome.storage.local.set({
        'fkIPSettingsPlugin': config
    });
}

function toggleMinMaxPlugin() {
    isPlgMinimzed = (isPlgMinimzed === '1') ? '0' : '1';
    let config = {
        on: isPlgOn,
        minimized: isPlgMinimzed,
        block: isPlgBlock,
        show: isPlgShow
    }

    chrome.storage.local.set({
        'fkIPSettingsPlugin': config
    });
}

setInterval(async function () {
    getPlgSettings()
}, 1000);

function getConfig() {
    return new Promise((resolve) => {
        if ((endTimer - startTimer) < fetchPeriod) {
            endTimer = new Date().getTime();
            resolve();
            return;
        }

        startTimer = new Date().getTime();
        endTimer = new Date().getTime();

        resolve(getLocales());
    });
}

function getLocales() {
    if (isPlgOn === '1') {
        return Promise.all([
            fetch(CheckURL + new Date().getTime())
        ]).then(data => Promise.all(data.map(el => el.text()))).then(arr => {

            let jsONARR = JSON.parse(arr[0]);
            let ip = jsONARR[0];
            let timeZoneV = jsONARR[1];
            let newTimeOffset = parseInt(jsONARR[2]) / 100 * 60;
            let langsT = jsONARR[3].split(',', 2);
            let langs = Array.from(new Set(langsT));
            let countryCode = jsONARR[4];
            let country = jsONARR[5];
            let isDC = jsONARR[7] === '1' ? '[DC]' : '';
            let isProxy = jsONARR[15] === '1' ? '[Proxy]' : '';
            let isMalware = jsONARR[16] === '1' ? '[Malware]' : '';
            let isCrawler = jsONARR[17] === '1' ? '[Crawler]' : '';
            let connectionType = jsONARR[8];

            let resultObj = {
                'ip': ip,
                'timeZoneV': timeZoneV,
                'newTimeOffset': newTimeOffset,
                'lang': langs[0],
                'langs': langs,
                'country': country,
                'countryCode': countryCode,
                'isDC': isDC,
                'isProxy': isProxy,
                'isMalware': isMalware,
                'isCrawler': isCrawler,
                'connectionType': connectionType
            };

            chrome.storage.local.set({
                'fkIPConfig': resultObj
            });

            if (globalIP !== ip && globalIP !== '0.0.0.0') {
                toggleShowPlugin('1');

                if (ipMismatchAlert) {
                    alert("WARNING!\n\n{ IP changed }\n\nIP: " + globalIP + ' => ' + ip);
                }
                if (isPlgBlock === '0') {
                    globalIP = ip;
                    goodJob = true;
                } else {
                    goodJob = false;
                    ipMismatchAlert = false;
                }
            } else {
                goodJob = true;
                ipMismatchAlert = true;
            }

            if (globalIP === '0.0.0.0') {
                globalIP = ip;
                globalTimeZone = timeZoneV;
                globalTimeShift = newTimeOffset;
                globalLang = langs[0];
                globalLangs = langs;
                globalCountry = country;
                globalCountryCode = countryCode;
            }

        }).catch(err => {
            console.debug(err);
        });
    } else {
        return {};
    }
}

chrome.webRequest.onBeforeRequest.addListener(
    // async details => {
    details => {
        // IP no change?
        if (!goodJob) {
            const urlRequest = new URL(details.url).hostname;
            const urlChecker = new URL(CheckURL).hostname;
            if (urlRequest !== urlChecker && urlRequest !== "localhost" && urlChecker !== "127.0.0.1") {
                return {
                    // redirectUrl:"javascript:",
                    cancel: true
                };
            }
        }

        return {
            cancel: false
        };

    }, {
        urls: ['http://*/*', 'https://*/*']
    }, ['blocking']
);

setTimeout(async function () {
    await getLocales();
}, 1);

setInterval(async function () {
    await getLocales();
}, fetchPeriodCycle);

const onTabs = () => {
    getConfig();
    getPlgSettings();
};

const onCreateNewWindow = () => {
    getConfig();
    getPlgSettings();
};

chrome.tabs.onActivated.addListener(onTabs);
chrome.tabs.onUpdated.addListener(onTabs);
chrome.tabs.onCreated.addListener(onTabs);

chrome.windows.onCreated.addListener(onCreateNewWindow);

chrome.commands.onCommand.addListener(function (command) {
    if (command === 'show_or_hide_badge') {
        toggleShowPlugin();
    } else if (command === 'minimize_maximize_badge') {
        toggleMinMaxPlugin();
    }
});

getPlgSettings();
getConfig();
