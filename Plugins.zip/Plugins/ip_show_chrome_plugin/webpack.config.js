const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin');
const TerserPlugin = require("terser-webpack-plugin");

module.exports = {
    mode: 'production',
    output: {
        path: __dirname,
        filename: '[name].js'
    },
    externals: {
        "ramda": "R"
    },
    module: {
        rules: [{
            test: /.js$/,
            loader: 'babel-loader'
        }, {
            test: /\.css$/i,
            use: [{
                loader: MiniCssExtractPlugin.loader
            }, {
                loader: 'css-loader'
            }],
        }]
    },
    optimization: {
        minimize: true,
        minimizer: [
            // For webpack@5 you can use the `...` syntax to extend existing minimizers (i.e. `terser-webpack-plugin`), uncomment the next line
            // `...`
            new CssMinimizerPlugin(),
            new TerserPlugin(),
            // new HtmlMinimizerPlugin(),
            // new TerserPlugin()
        ],
    },
    plugins: [
            new MiniCssExtractPlugin(),
            // new HtmlWebpackPlugin()
        ]
        // presets: [
        //     [
        //         '@babel/preset-env', {
        //             targets: {
        //                 esmodules: true,
        //             },
        //         },
        //     ],
        // ],
        // devtool: 'source-map'
};