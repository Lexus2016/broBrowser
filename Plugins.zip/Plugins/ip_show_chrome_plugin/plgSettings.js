isPlgOn = '1';
isPlgMinimzed = '0';
isPlgBlock = '1';
isPlgShow = '1';

CheckURL = 'http://ip.address.put.here:81/?token=skjdh8b38bx82b&tz=';
